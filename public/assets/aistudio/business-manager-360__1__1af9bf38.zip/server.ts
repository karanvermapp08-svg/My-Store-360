import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { defaultWhatsAppOtpManager } from './server/whatsappOtp';
import { defaultSyncLedger, SyncMutationInput } from './server/syncStore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  // Health endpoint for standalone preview runtime (no external DB or API keys active)
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'Business Manager 360 Customer Shopping App',
      mode: 'offline-first-indexeddb-pwa',
      futureBackendProxyReady: true,
      whatsappVerificationReady: true,
      syncReady: true,
    });
  });

  // Conflict-safe Offline-First Sync API (idempotency deduplication + timestamp conflict protection)
  app.get('/api/v1/sync/status', (_req, res) => {
    res.json(defaultSyncLedger.getStatus());
  });

  app.get('/api/v1/sync/records', (req, res) => {
    const since = typeof req.query?.since === 'string' ? req.query.since : undefined;
    res.json(defaultSyncLedger.getRecordsSince(since));
  });

  app.post('/api/v1/sync', (req, res) => {
    const rawMutations = Array.isArray(req.body?.mutations)
      ? (req.body.mutations as SyncMutationInput[])
      : [];
    const result = defaultSyncLedger.applyBatch(rawMutations);
    res.json(result);
  });

  // Official WhatsApp Business Platform OTP Verification API (credentials strictly backend-only)
  app.get('/api/v1/verification/whatsapp/status', (_req, res) => {
    res.json(defaultWhatsAppOtpManager.getPlatformStatus());
  });

  app.post('/api/v1/verification/whatsapp/send-otp', async (req, res) => {
    const mobileNumber = typeof req.body?.mobileNumber === 'string' ? req.body.mobileNumber : '';
    const outcome = await defaultWhatsAppOtpManager.sendOtp(mobileNumber);
    const { httpStatus, ...payload } = outcome;
    res.status(httpStatus).json(payload);
  });

  app.post('/api/v1/verification/whatsapp/verify-otp', (req, res) => {
    const mobileNumber = typeof req.body?.mobileNumber === 'string' ? req.body.mobileNumber : '';
    const otpCode = typeof req.body?.otpCode === 'string' ? req.body.otpCode : '';
    const outcome = defaultWhatsAppOtpManager.verifyOtp(mobileNumber, otpCode);
    const { httpStatus, ...payload } = outcome;
    res.status(httpStatus).json(payload);
  });

  // Note: Future Secure Backend API proxy routes (/api/v1/*) to the separate Admin Billing App
  // will be added here only when explicitly requested and configured with backend-only credentials.

  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        watch: null,
        ws: {
          server: httpServer,
        },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Business Manager 360 standalone server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
