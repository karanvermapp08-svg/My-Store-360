export type MembershipTier = 'Basic' | 'Silver' | 'Gold' | 'Premium';

export interface CustomerUser {
  uid: string;
  displayName: string;
  email: string;
  phone?: string;
  phoneVerified?: boolean;
  isDemo: boolean;
}

export type OrderStatus =
  | 'Order Placed'
  | 'Accepted'
  | 'Processing'
  | 'Packed'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled'
  | 'Return Requested';

export interface Category {
  id: string;
  name: string;
  slug: string;
  color: string;
  bgTint: string;
  iconName: string;
  image: string;
  sortOrder: number;
  active: boolean;
  updatedAt?: string;
}

export interface ProductVariant {
  label: string;
  mrp: number;
  price: number;
  stock: number;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  brand: string;
  categoryId: string;
  categoryName: string;
  description: string;
  unit: string;
  variants?: ProductVariant[];
  mrp: number;
  price: number;
  discountPercent: number;
  gstPercent: number;
  stock: number;
  inStock: boolean;
  images: string[];
  tags?: string[];
  specifications?: Record<string, string>;
  rating: number;
  reviewCount: number;
  isBestSeller?: boolean;
  isTrending?: boolean;
  isTodaysDeal?: boolean;
  isGrocerySpecial?: boolean;
  isComboPack?: boolean;
  bundleItems?: string[];
  frequentlyBoughtIds?: string[];
  hyperlocalExpress?: boolean;
  active: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface CartItem {
  productId: string;
  name: string;
  brand: string;
  unit: string;
  mrp: number;
  price: number;
  gstPercent: number;
  image: string;
  quantity: number;
  maxStock: number;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  membershipTier: MembershipTier;
  rewardPoints: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface UserPrivateInfo {
  uid: string;
  email: string;
  phone?: string;
  phoneVerified?: boolean;
  phoneVerifiedAt?: string;
  phoneVerificationMethod?: 'WHATSAPP_OTP';
  preferredPincode?: string;
  preferredCity?: string;
  gstin?: string;
  updatedAt?: string;
}

export interface Address {
  id: string;
  userId: string;
  label: 'Home' | 'Office' | 'Other';
  fullName: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
  isDefault: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface OrderTimelineEvent {
  status: OrderStatus;
  label: string;
  timestamp: string;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerPhone: string;
  shippingSummary: string;
  pincode: string;
  deliverySlot?: string;
  deliveryInstructions?: string;
  paymentMethod: 'COD' | 'ONLINE_PENDING';
  paymentStatus: 'Pending' | 'Confirmed' | 'Refunded';
  subtotal: number;
  discountAmount: number;
  couponCode?: string;
  rewardPointsUsed?: number;
  rewardDiscount?: number;
  gstAmount: number;
  deliveryCharge: number;
  totalAmount: number;
  status: OrderStatus;
  timeline?: OrderTimelineEvent[];
  itemCount: number;
  cancelReason?: string;
  returnReason?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface OrderItem {
  id: string;
  orderId: string;
  userId: string;
  productId: string;
  productName: string;
  brand?: string;
  unit?: string;
  quantity: number;
  mrp?: number;
  unitPrice: number;
  gstPercent?: number;
  lineTotal: number;
  image?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  orderId: string;
  userId: string;
  customerName: string;
  customerAddress?: string;
  itemsCount?: number;
  subtotal: number;
  gstAmount: number;
  discountAmount?: number;
  deliveryCharge?: number;
  grandTotal: number;
  issuedAt: string;
}

export interface Offer {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  categorySlug: string;
  discountText: string;
  bgGradient?: string;
  minMembership?: MembershipTier;
  active: boolean;
  updatedAt?: string;
}

export interface Coupon {
  code: string;
  title: string;
  description: string;
  discountType: 'percent' | 'flat';
  discountValue: number;
  minOrderAmount: number;
  maxDiscount?: number;
  minMembership?: MembershipTier;
  active: boolean;
  updatedAt?: string;
}

export interface RewardTransaction {
  id: string;
  userId: string;
  points: number;
  type: 'earned' | 'redeemed' | 'cashback' | 'bonus' | 'expired';
  description: string;
  orderId?: string;
  createdAt?: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'order' | 'offer' | 'reward' | 'system';
  read: boolean;
  orderId?: string;
  createdAt?: string;
}

export interface ProductReview {
  id: string;
  productId: string;
  userId: string;
  orderId?: string;
  authorName: string;
  rating: number;
  title?: string;
  comment: string;
  photos?: string[];
  verifiedPurchase?: boolean;
  helpfulCount?: number;
  helpfulUserIds?: string[];
  reportedByUserIds?: string[];
  lastReportReason?: string;
  createdAt?: string;
}

export interface ReviewEligibilityResult {
  canSubmit: boolean;
  hasVerifiedPurchase: boolean;
  eligibleOrderId?: string;
  alreadyReviewed: boolean;
  reason?: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  orderId?: string;
  category: 'Order Issue' | 'Return Request' | 'Payment' | 'Product Query' | 'General';
  subject: string;
  message: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  createdAt?: string;
  updatedAt?: string;
}

export interface MembershipPlan {
  tier: MembershipTier;
  monthlyPrice: number;
  pointsMultiplier: number;
  freeDeliveryAllOrders: boolean;
  exclusiveDeals: boolean;
  perks: string[];
}

export interface StoreSettings {
  rewardsEarnRate: number;
  pointValueInr: number;
  maxRedeemPercent: number;
  freeDeliveryThreshold: number;
  deliveryFee: number;
  codEnabled: boolean;
  onlinePaymentEnabled: boolean;
  whatsappNumber: string;
  supportEmail: string;
  serviceablePincodes: string[];
  deliverySlots: string[];
  membershipPlans?: MembershipPlan[];
  updatedAt?: string;
}

export interface PincodeServiceabilityResult {
  serviceable: boolean;
  pincode: string;
  city?: string;
  state?: string;
  hub?: string;
  areaName?: string;
  expressAvailable?: boolean;
  estimatedDeliveryText?: string;
  message: string;
}

export interface ServiceableLocationSuggestion {
  pincode: string;
  city: string;
  state: string;
  areaName: string;
  hub: string;
  expressAvailable: boolean;
  estimatedDeliveryText?: string;
}

export interface CheckoutValidationResult {
  valid: boolean;
  subtotal: number;
  mrpTotal: number;
  catalogSavings: number;
  couponDiscount: number;
  couponMessage?: string;
  approvedRewardPoints: number;
  maxRedeemablePoints: number;
  rewardDiscount: number;
  totalDiscount: number;
  gstAmount: number;
  deliveryCharge: number;
  totalAmount: number;
  estimatedEarnedPoints: number;
  error?: string;
}

export interface WhatsAppPlatformStatus {
  provider: 'Meta WhatsApp Business Platform';
  defaultMethod: 'WHATSAPP_OTP';
  smsFallbackEnabled: false;
  liveSendingEnabled: boolean;
  credentialsConfigured: boolean;
  otpLength: 6;
  otpExpirySeconds: number;
  resendCooldownSeconds: number;
  maxAttempts: number;
  maxSendsPerWindow: number;
  statusMessage: string;
}

export interface WhatsAppSendOtpResult {
  sent: boolean;
  code:
    | 'OTP_SENT'
    | 'INVALID_MOBILE_NUMBER'
    | 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED'
    | 'RESEND_COOLDOWN_ACTIVE'
    | 'RATE_LIMIT_EXCEEDED'
    | 'WHATSAPP_GATEWAY_ERROR'
    | 'NETWORK_ERROR'
    | 'OFFLINE_MODE';
  message: string;
  liveSendingEnabled: boolean;
  credentialsConfigured: boolean;
  maskedPhone?: string;
  e164?: string;
  expiresInSeconds?: number;
  expiresAt?: string;
  resendCooldownSeconds?: number;
  retryAfterSeconds?: number;
  maxAttempts?: number;
}

export interface WhatsAppVerifyOtpResult {
  verified: boolean;
  code:
    | 'VERIFIED'
    | 'INVALID_MOBILE_NUMBER'
    | 'INVALID_OTP_FORMAT'
    | 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED'
    | 'OTP_NOT_FOUND'
    | 'OTP_EXPIRED'
    | 'INVALID_OTP'
    | 'MAX_ATTEMPTS_EXCEEDED'
    | 'NETWORK_ERROR'
    | 'OFFLINE_MODE';
  message: string;
  e164?: string;
  national10?: string;
  formattedDisplay?: string;
  maskedPhone?: string;
  verifiedAt?: string;
  method?: 'WHATSAPP_OTP';
  verificationId?: string;
  remainingAttempts?: number;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  variant?: 'success' | 'info' | 'warning' | 'error';
}

export type AppView =
  | 'home'
  | 'catalog'
  | 'product'
  | 'cart'
  | 'checkout'
  | 'account';

export type AccountSection =
  | 'profile'
  | 'orders'
  | 'wishlist'
  | 'addresses'
  | 'rewards'
  | 'membership'
  | 'invoices'
  | 'notifications'
  | 'support'
  | 'settings';
