import React, { useState } from 'react';
import { ChevronDown, Menu } from 'lucide-react';
import { Category } from '../types/store';

interface DesktopNavigationProps {
  categories: Category[];
  activeCategorySlug: string;
  onSelectCategory: (slug: string) => void;
  onSelectOffers: () => void;
}

const PRIMARY_NAV_SLUGS = [
  'grocery',
  'daily-essentials',
  'dairy-products',
  'fruits-vegetables',
  'food-beverages',
  'personal-care',
  'home-kitchen',
];

export const DesktopNavigation: React.FC<DesktopNavigationProps> = ({
  categories,
  activeCategorySlug,
  onSelectCategory,
  onSelectOffers,
}) => {
  const [megaOpen, setMegaOpen] = useState(false);

  const primaryCategories = PRIMARY_NAV_SLUGS.map((slug) =>
    categories.find((c) => c.slug === slug)
  ).filter((c): c is Category => Boolean(c));

  return (
    <nav
      aria-label="Primary Store Categories"
      className="hidden lg:block bg-[#2874F0] text-white shadow-xs relative z-30"
    >
      <div className="max-w-[1440px] mx-auto px-6 h-11 flex items-center gap-5">
        <div
          className="relative"
          onMouseEnter={() => setMegaOpen(true)}
          onMouseLeave={() => setMegaOpen(false)}
        >
          <button
            type="button"
            onClick={() => setMegaOpen((o) => !o)}
            className="flex items-center gap-2 rounded-lg bg-white/15 hover:bg-white/25 px-3.5 py-1.5 text-xs font-semibold tracking-wide whitespace-nowrap shrink-0 transition-colors cursor-pointer"
          >
            <Menu className="w-4 h-4" />
            <span>All Categories</span>
            <ChevronDown className="w-3.5 h-3.5" />
          </button>

          {megaOpen && (
            <div className="absolute left-0 top-full pt-1 w-[560px] z-50">
              <div className="rounded-2xl bg-white text-[#202433] border border-slate-200 shadow-xl p-4 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setMegaOpen(false);
                    onSelectCategory('all');
                  }}
                  className="col-span-2 flex items-center justify-between rounded-xl bg-[#EAF2FF] px-3.5 py-2.5 text-sm font-semibold text-[#2874F0] hover:bg-[#D8E8FF] cursor-pointer"
                >
                  <span>Browse Full Storefront Catalog</span>
                  <span>→</span>
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setMegaOpen(false);
                      onSelectCategory(cat.slug);
                    }}
                    className="flex items-center gap-3 rounded-xl p-2 hover:bg-slate-50 text-left transition-colors cursor-pointer"
                  >
                    <span
                      className="w-8 h-8 rounded-lg shrink-0 flex items-center justify-center text-xs font-bold"
                      style={{ backgroundColor: cat.bgTint, color: cat.color }}
                    >
                      {cat.name.slice(0, 2).toUpperCase()}
                    </span>
                    <span className="text-sm font-medium text-[#202433] truncate">{cat.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-5 overflow-x-auto no-scrollbar">
          {primaryCategories.map((cat) => {
            const active = activeCategorySlug === cat.slug;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => onSelectCategory(cat.slug)}
                className={`text-[13px] font-medium whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  active
                    ? 'border-[#FFC83D] text-white font-semibold'
                    : 'border-transparent text-white/90 hover:text-white hover:border-white/50'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => onSelectCategory('combos')}
            className={`text-[13px] font-medium whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeCategorySlug === 'combos'
                ? 'border-[#FFC83D] text-white font-semibold'
                : 'border-transparent text-white/90 hover:text-white hover:border-white/50'
            }`}
          >
            Combo Packs
          </button>
          <button
            type="button"
            onClick={onSelectOffers}
            className={`text-[13px] font-semibold whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeCategorySlug === 'offers'
                ? 'border-[#FFC83D] text-[#FFC83D]'
                : 'border-transparent text-[#FFC83D] hover:border-[#FFC83D]'
            }`}
          >
            Offers
          </button>
        </div>
      </div>
    </nav>
  );
};
