import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  CreditCard,
  MapPin,
  Plus,
  ShieldCheck,
  Sparkles,
  Truck,
  Wallet,
} from 'lucide-react';
import {
  Address,
  CartItem,
  CheckoutValidationResult,
  Coupon,
  CustomerUser,
  Order,
  Product,
  StoreSettings,
  UserPrivateInfo,
  UserProfile,
} from '../types/store';
import {
  cartService,
  customerService,
  inventoryAvailabilityService,
  orderService,
} from '../services/serviceContainer';
import { WhatsAppOtpVerification } from './WhatsAppOtpVerification';

interface ResponsiveCheckoutProps {
  user: CustomerUser | null;
  profile: UserProfile | null;
  privateInfo: UserPrivateInfo | null;
  items: CartItem[];
  allProducts: Product[];
  addresses: Address[];
  coupons: Coupon[];
  initialCouponCode: string;
  settings: StoreSettings;
  onRequireSignIn: () => void;
  onOrderSuccess: (order: Order) => void;
  onBackToCart: () => void;
  onToast: (title: string, description?: string, variant?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const ResponsiveCheckout: React.FC<ResponsiveCheckoutProps> = ({
  user,
  profile,
  privateInfo,
  items,
  allProducts,
  addresses,
  coupons,
  initialCouponCode,
  settings,
  onRequireSignIn,
  onOrderSuccess,
  onBackToCart,
  onToast,
}) => {
  const [showWhatsAppVerify, setShowWhatsAppVerify] = useState(false);
  const [selectedAddressId, setSelectedAddressId] = useState<string>(addresses[0]?.id || '');
  const [addingAddress, setAddingAddress] = useState(addresses.length === 0);
  const [addrForm, setAddrForm] = useState({
    label: 'Home' as Address['label'],
    fullName: user?.displayName || '',
    phone: '',
    line1: '',
    line2: '',
    city: 'Mumbai',
    state: 'Maharashtra',
    pincode: '400001',
  });

  const [deliverySlot, setDeliverySlot] = useState(settings.deliverySlots[0] || 'Standard Delivery');
  const [deliveryInstructions, setDeliveryInstructions] = useState('');
  const [couponInput, setCouponInput] = useState(initialCouponCode);
  const [appliedCouponCode, setAppliedCouponCode] = useState(initialCouponCode);
  const [useRewards, setUseRewards] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'ONLINE_PENDING'>('COD');

  const [pincodeStatus, setPincodeStatus] = useState<{ serviceable: boolean; message: string } | null>(null);
  const [validation, setValidation] = useState<CheckoutValidationResult | null>(null);
  const [validating, setValidating] = useState(false);
  const [placingOrder, setPlacingOrder] = useState(false);

  useEffect(() => {
    if (!selectedAddressId && addresses.length > 0) {
      const def = addresses.find((a) => a.isDefault) || addresses[0];
      setSelectedAddressId(def.id);
      setAddingAddress(false);
    }
  }, [addresses, selectedAddressId]);

  const selectedAddress = addresses.find((a) => a.id === selectedAddressId) || null;
  const activePincode = selectedAddress?.pincode || addrForm.pincode;

  // Verify pincode serviceability via local InventoryAvailabilityService
  useEffect(() => {
    if (!/^\d{6}$/.test(activePincode)) {
      setPincodeStatus(null);
      return;
    }
    let cancelled = false;
    inventoryAvailabilityService
      .checkPincodeServiceability(activePincode)
      .then((data) => {
        if (!cancelled) setPincodeStatus(data);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [activePincode, settings.serviceablePincodes]);

  // Checkout calculation via CartService (LocalDemoService)
  useEffect(() => {
    if (!user || items.length === 0) return;
    let cancelled = false;
    const runValidation = async () => {
      setValidating(true);
      try {
        const data = await cartService.calculateCheckoutTotals({
          items,
          couponCode: appliedCouponCode.toUpperCase(),
          membershipTier: profile?.membershipTier || 'Basic',
          availableRewardPoints: profile?.rewardPoints ?? 0,
          useRewardPoints: useRewards,
        });
        if (!cancelled) setValidation(data);
      } catch {
        if (!cancelled) setValidation(null);
      } finally {
        if (!cancelled) setValidating(false);
      }
    };
    runValidation();
  }, [user, items, allProducts, coupons, appliedCouponCode, useRewards, profile, settings]);

  if (!user) {
    return (
      <div className="rounded-2xl bg-white border border-slate-200 p-8 text-center max-w-lg mx-auto space-y-4">
        <ShieldCheck className="w-10 h-10 text-[#2874F0] mx-auto" />
        <h2 className="font-display text-xl font-bold text-[#202433]">Sign In to Complete Checkout</h2>
        <p className="text-sm text-slate-500">
          Your cart is preserved. Sign in to the Demo Customer Account to verify your delivery address, coupons, reward wallet, and GST invoice.
        </p>
        <div className="flex items-center justify-center gap-3">
          <button
            type="button"
            onClick={onBackToCart}
            className="rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-700 cursor-pointer"
          >
            Back to Cart
          </button>
          <button
            type="button"
            onClick={onRequireSignIn}
            className="rounded-xl bg-[#2874F0] px-6 py-2.5 text-sm font-semibold text-white cursor-pointer"
          >
            Sign In to Demo Account
          </button>
        </div>
      </div>
    );
  }

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addrForm.fullName || !addrForm.phone || !addrForm.line1 || !addrForm.pincode) {
      onToast('Missing fields', 'Please fill full name, phone, address line, and pincode.', 'warning');
      return;
    }
    const id = `addr_${Date.now()}`;
    await customerService.saveAddress(user.uid, {
      id,
      userId: user.uid,
      label: addrForm.label,
      fullName: addrForm.fullName.trim(),
      phone: addrForm.phone.trim(),
      line1: addrForm.line1.trim(),
      line2: addrForm.line2.trim(),
      city: addrForm.city.trim(),
      state: addrForm.state.trim(),
      pincode: addrForm.pincode.trim(),
      isDefault: addresses.length === 0,
    });
    setSelectedAddressId(id);
    setAddingAddress(false);
    onToast('Address saved', 'Delivery address added to your local account.');
  };

  const handleConfirmOrder = async () => {
    if (!selectedAddress) {
      onToast('Select delivery address', 'Please select or save a delivery address.', 'warning');
      return;
    }
    if (pincodeStatus && !pincodeStatus.serviceable) {
      onToast('Pincode not serviceable', pincodeStatus.message, 'error');
      return;
    }
    if (!validation || !validation.valid) {
      onToast('Validation incomplete', validation?.error || 'Please wait for price calculation.', 'warning');
      return;
    }
    if (paymentMethod === 'ONLINE_PENDING') {
      onToast(
        'Online Gateway Unavailable in Demo Mode',
        'Select Cash / UPI on Delivery to place this order in Local Demo Mode.',
        'info'
      );
      return;
    }

    setPlacingOrder(true);
    try {
      const order = await orderService.placeOrder({
        userId: user.uid,
        customerName: selectedAddress.fullName,
        customerPhone: selectedAddress.phone,
        address: selectedAddress,
        deliverySlot,
        deliveryInstructions: deliveryInstructions.trim(),
        paymentMethod,
        items,
        subtotal: validation.subtotal,
        discountAmount: validation.totalDiscount,
        couponCode: validation.couponDiscount > 0 ? appliedCouponCode.toUpperCase() : '',
        rewardPointsUsed: validation.approvedRewardPoints,
        rewardDiscount: validation.rewardDiscount,
        gstAmount: validation.gstAmount,
        deliveryCharge: validation.deliveryCharge,
        totalAmount: validation.totalAmount,
      });
      onOrderSuccess(order);
    } catch (err) {
      onToast(
        'Order could not be placed',
        err instanceof Error ? err.message : 'Please verify stock and try again.',
        'error'
      );
    } finally {
      setPlacingOrder(false);
    }
  };

  return (
    <div className="space-y-6 pb-28 lg:pb-8">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-xl sm:text-2xl font-bold text-[#202433]">Secure Checkout</h1>
        <button
          type="button"
          onClick={onBackToCart}
          className="text-xs sm:text-sm font-semibold text-[#2874F0] hover:underline cursor-pointer"
        >
          ← Back to Cart
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Delivery Address, Slot, Payment */}
        <div className="lg:col-span-8 space-y-5">
          {/* WhatsApp Contact Verification Status Bar */}
          <section className="rounded-2xl bg-white border border-slate-200 p-4 sm:p-5 shadow-xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                {privateInfo?.phoneVerified ? (
                  <CheckCircle2 className="w-5 h-5 text-[#16A879] shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                )}
                <div>
                  <p className="text-xs sm:text-sm font-bold text-[#202433]">
                    Customer Mobile:{' '}
                    <span className="font-mono-num">
                      {privateInfo?.phone || selectedAddress?.phone || 'Not set'}
                    </span>{' '}
                    <span
                      className={`ml-1.5 inline-block rounded-full px-2 py-0.5 text-[10px] font-bold ${
                        privateInfo?.phoneVerified
                          ? 'bg-emerald-50 text-[#128C63] border border-emerald-200'
                          : 'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {privateInfo?.phoneVerified ? 'WHATSAPP VERIFIED' : 'UNVERIFIED'}
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-500">
                    {privateInfo?.phoneVerified
                      ? 'Verified via official WhatsApp Business Platform OTP.'
                      : 'Verify your Indian mobile number with WhatsApp OTP (no SMS default).'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowWhatsAppVerify((v) => !v)}
                className="rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 px-3.5 py-1.5 text-xs font-bold text-[#128C63] cursor-pointer"
              >
                {showWhatsAppVerify
                  ? 'Hide WhatsApp OTP'
                  : privateInfo?.phoneVerified
                  ? 'Change / Re-verify'
                  : 'Verify via WhatsApp'}
              </button>
            </div>

            {showWhatsAppVerify && (
              <WhatsAppOtpVerification
                compact
                initialPhone={privateInfo?.phone || selectedAddress?.phone}
                verifiedPhone={privateInfo?.phone}
                isPhoneVerified={Boolean(
                  privateInfo?.phoneVerified && privateInfo?.phoneVerificationMethod === 'WHATSAPP_OTP'
                )}
                verifiedAt={privateInfo?.phoneVerifiedAt}
                onVerified={async (receipt) => {
                  await customerService.markPhoneVerified(user.uid, receipt);
                  setShowWhatsAppVerify(false);
                }}
                onToast={onToast}
              />
            )}
          </section>

          {/* 1. Delivery Address */}
          <section className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-bold text-[#202433] flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#2874F0]" />
                <span>1. Delivery Address</span>
              </h2>
              {addresses.length > 0 && (
                <button
                  type="button"
                  onClick={() => setAddingAddress((v) => !v)}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#2874F0] cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{addingAddress ? 'Cancel' : 'Add New'}</span>
                </button>
              )}
            </div>

            {!addingAddress && addresses.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {addresses.map((addr) => {
                  const selected = addr.id === selectedAddressId;
                  return (
                    <button
                      key={addr.id}
                      type="button"
                      onClick={() => setSelectedAddressId(addr.id)}
                      className={`rounded-xl border p-3.5 text-left transition-all cursor-pointer ${
                        selected
                          ? 'border-[#2874F0] bg-[#EAF2FF]/60 ring-2 ring-[#2874F0]/15'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[#2874F0]">{addr.label}</span>
                        <span className="text-xs font-mono-num text-slate-500">{addr.pincode}</span>
                      </div>
                      <p className="text-sm font-bold text-[#202433] mt-1">{addr.fullName}</p>
                      <p className="text-xs text-slate-600 mt-0.5 line-clamp-2">
                        {addr.line1}
                        {addr.line2 ? `, ${addr.line2}` : ''}, {addr.city}, {addr.state}
                      </p>
                      <p className="text-xs text-slate-500 mt-1 font-mono-num">{addr.phone}</p>
                    </button>
                  );
                })}
              </div>
            )}

            {addingAddress && (
              <form onSubmit={handleSaveAddress} className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="sm:col-span-2 flex gap-2">
                  {(['Home', 'Office', 'Other'] as const).map((lbl) => (
                    <button
                      key={lbl}
                      type="button"
                      onClick={() => setAddrForm((f) => ({ ...f, label: lbl }))}
                      className={`rounded-xl border px-3 py-1.5 text-xs font-semibold cursor-pointer ${
                        addrForm.label === lbl
                          ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                          : 'border-slate-200 text-slate-600'
                      }`}
                    >
                      {lbl}
                    </button>
                  ))}
                </div>
                <input
                  required
                  value={addrForm.fullName}
                  onChange={(e) => setAddrForm((f) => ({ ...f, fullName: e.target.value }))}
                  placeholder="Full Name *"
                  className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:border-[#2874F0] focus:outline-none"
                />
                <input
                  required
                  value={addrForm.phone}
                  onChange={(e) => setAddrForm((f) => ({ ...f, phone: e.target.value }))}
                  placeholder="10-digit Mobile Number *"
                  className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm font-mono-num focus:border-[#2874F0] focus:outline-none"
                />
                <input
                  required
                  value={addrForm.line1}
                  onChange={(e) => setAddrForm((f) => ({ ...f, line1: e.target.value }))}
                  placeholder="House / Flat / Street *"
                  className="sm:col-span-2 rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:border-[#2874F0] focus:outline-none"
                />
                <input
                  value={addrForm.line2}
                  onChange={(e) => setAddrForm((f) => ({ ...f, line2: e.target.value }))}
                  placeholder="Landmark / Area (optional)"
                  className="sm:col-span-2 rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:border-[#2874F0] focus:outline-none"
                />
                <input
                  required
                  value={addrForm.city}
                  onChange={(e) => setAddrForm((f) => ({ ...f, city: e.target.value }))}
                  placeholder="City *"
                  className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:border-[#2874F0] focus:outline-none"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    required
                    value={addrForm.state}
                    onChange={(e) => setAddrForm((f) => ({ ...f, state: e.target.value }))}
                    placeholder="State *"
                    className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:border-[#2874F0] focus:outline-none"
                  />
                  <input
                    required
                    maxLength={6}
                    value={addrForm.pincode}
                    onChange={(e) =>
                      setAddrForm((f) => ({ ...f, pincode: e.target.value.replace(/\D/g, '').slice(0, 6) }))
                    }
                    placeholder="Pincode *"
                    className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm font-mono-num focus:border-[#2874F0] focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="sm:col-span-2 rounded-xl bg-[#2874F0] py-2.5 text-sm font-semibold text-white hover:bg-[#1A56C4] cursor-pointer"
                >
                  Save &amp; Deliver Here
                </button>
              </form>
            )}

            {pincodeStatus && (
              <div
                className={`flex items-center gap-2 rounded-xl p-3 text-xs ${
                  pincodeStatus.serviceable ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-700'
                }`}
              >
                {pincodeStatus.serviceable ? (
                  <CheckCircle2 className="w-4 h-4 text-[#16A879] shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                )}
                <span>{pincodeStatus.message}</span>
              </div>
            )}
          </section>

          {/* 2. Delivery Slot & Instructions */}
          <section className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs space-y-4">
            <h2 className="font-display text-base font-bold text-[#202433] flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#16A879]" />
              <span>2. Grocery &amp; Order Delivery Slot</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {settings.deliverySlots.map((slot) => (
                <button
                  key={slot}
                  type="button"
                  onClick={() => setDeliverySlot(slot)}
                  className={`rounded-xl border p-3 text-left text-xs sm:text-sm font-medium cursor-pointer ${
                    deliverySlot === slot
                      ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0] font-semibold'
                      : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {slot}
                </button>
              ))}
            </div>

            <input
              type="text"
              maxLength={250}
              value={deliveryInstructions}
              onChange={(e) => setDeliveryInstructions(e.target.value)}
              placeholder="Delivery instructions (e.g., Ring bell twice, leave with security)"
              className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm focus:border-[#2874F0] focus:outline-none"
            />
          </section>

          {/* 3. Payment Method */}
          <section className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs space-y-3">
            <h2 className="font-display text-base font-bold text-[#202433] flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[#FF7A30]" />
              <span>3. Payment Method</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                disabled={!settings.codEnabled}
                onClick={() => setPaymentMethod('COD')}
                className={`rounded-xl border p-3.5 text-left cursor-pointer ${
                  paymentMethod === 'COD'
                    ? 'border-[#2874F0] bg-[#EAF2FF]'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <p className="text-sm font-bold text-[#202433]">Cash / UPI on Delivery</p>
                <p className="text-xs text-slate-500 mt-0.5">Pay directly when your order arrives</p>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('ONLINE_PENDING')}
                className={`rounded-xl border p-3.5 text-left cursor-pointer ${
                  paymentMethod === 'ONLINE_PENDING'
                    ? 'border-[#2874F0] bg-[#EAF2FF]'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <p className="text-sm font-bold text-[#202433]">Online Payment (UPI / Cards)</p>
                <p className="text-xs text-slate-500 mt-0.5">Requires merchant gateway keys in deployment</p>
              </button>
            </div>
          </section>
        </div>

        {/* Right: Server-Validated Order Summary */}
        <aside className="lg:col-span-4 lg:sticky lg:top-28">
          <div className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs space-y-4">
            <h2 className="font-display text-base font-bold text-[#202433] pb-3 border-b border-slate-100">
              Verified Order Summary
            </h2>

            {/* Coupon Apply */}
            <div className="flex gap-2">
              <input
                type="text"
                value={couponInput}
                onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                placeholder="Coupon code"
                className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-xs font-mono-num uppercase focus:border-[#2874F0] focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setAppliedCouponCode(couponInput.trim().toUpperCase())}
                className="rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
              >
                Apply
              </button>
            </div>
            {validation?.couponMessage && (
              <p className="text-xs text-[#2874F0] font-medium">{validation.couponMessage}</p>
            )}

            {/* Reward Points Toggle */}
            <label className="flex items-center justify-between rounded-xl bg-[#F7F8FC] border border-slate-200 p-3 cursor-pointer">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-[#7B4DDB]" />
                <div>
                  <p className="text-xs font-bold text-[#202433]">Use Reward Points</p>
                  <p className="text-[11px] text-slate-500">
                    Available: {profile?.rewardPoints ?? 0} pts
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={useRewards}
                disabled={(profile?.rewardPoints ?? 0) <= 0}
                onChange={(e) => setUseRewards(e.target.checked)}
                className="w-4 h-4 accent-[#7B4DDB]"
              />
            </label>

            {/* Totals */}
            {validating || !validation ? (
              <div className="space-y-2 py-2 animate-pulse">
                <div className="h-4 bg-slate-100 rounded" />
                <div className="h-4 bg-slate-100 rounded w-2/3" />
                <div className="h-6 bg-slate-100 rounded" />
              </div>
            ) : (
              <div className="space-y-2 text-sm pt-2 border-t border-slate-100">
                <div className="flex justify-between text-slate-600">
                  <span>Items Subtotal</span>
                  <span className="font-semibold text-[#202433] tabular-nums">
                    ₹{validation.subtotal.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between text-slate-500 text-xs">
                  <span>Included GST Breakdown</span>
                  <span className="tabular-nums">₹{validation.gstAmount.toLocaleString('en-IN')}</span>
                </div>
                {validation.couponDiscount > 0 && (
                  <div className="flex justify-between text-[#16A879]">
                    <span>Coupon Discount</span>
                    <span className="font-semibold tabular-nums">
                      -₹{validation.couponDiscount.toLocaleString('en-IN')}
                    </span>
                  </div>
                )}
                {validation.rewardDiscount > 0 && (
                  <div className="flex justify-between text-[#7B4DDB]">
                    <span>Reward Wallet ({validation.approvedRewardPoints} pts)</span>
                    <span className="font-semibold tabular-nums">
                      -₹{validation.rewardDiscount.toLocaleString('en-IN')}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Delivery Charge</span>
                  <span className="font-semibold tabular-nums">
                    {validation.deliveryCharge === 0 ? (
                      <span className="text-[#16A879]">FREE</span>
                    ) : (
                      `₹${validation.deliveryCharge}`
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-base font-extrabold text-[#202433] pt-3 border-t border-slate-200">
                  <span>Total Payable</span>
                  <span className="tabular-nums">₹{validation.totalAmount.toLocaleString('en-IN')}</span>
                </div>
                <p className="text-[11px] text-[#7B4DDB] flex items-center gap-1 pt-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  You will earn ~{validation.estimatedEarnedPoints} Reward Points upon delivery.
                </p>
              </div>
            )}

            <button
              type="button"
              disabled={placingOrder || !selectedAddress || !validation?.valid}
              onClick={handleConfirmOrder}
              className="hidden lg:flex w-full min-h-[48px] rounded-xl bg-[#16A879] hover:bg-[#129168] disabled:bg-slate-300 text-white font-bold text-sm items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{placingOrder ? 'Placing Verified Order...' : 'Confirm Order'}</span>
            </button>
          </div>
        </aside>
      </div>

      {/* Mobile Fixed Bottom Place Order Bar */}
      <div className="lg:hidden fixed bottom-15 left-0 right-0 z-30 bg-white border-t border-slate-200 px-4 py-3 flex items-center justify-between gap-4 shadow-[0_-4px_12px_rgba(0,0,0,0.06)]">
        <div>
          <p className="text-[11px] text-slate-500">Total Payable</p>
          <p className="text-lg font-extrabold text-[#202433] tabular-nums">
            ₹{(validation?.totalAmount ?? 0).toLocaleString('en-IN')}
          </p>
        </div>
        <button
          type="button"
          disabled={placingOrder || !selectedAddress || !validation?.valid}
          onClick={handleConfirmOrder}
          className="rounded-xl bg-[#16A879] disabled:bg-slate-300 text-white font-bold text-sm px-6 py-3"
        >
          {placingOrder ? 'Placing...' : 'Confirm Order'}
        </button>
      </div>
    </div>
  );
};
