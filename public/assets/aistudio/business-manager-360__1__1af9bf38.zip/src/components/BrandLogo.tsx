import React from 'react';

interface BrandLogoProps {
  variant?: 'desktop' | 'mobile';
  onClick?: () => void;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ variant = 'desktop', onClick }) => {
  const isMobile = variant === 'mobile';

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-2.5 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF9F00] rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
      aria-label="Business Manager 360 Home"
    >
      <div
        className={`flex items-center justify-center rounded-xl shrink-0 ${
          isMobile ? 'w-8 h-8 bg-white/15' : 'w-10 h-10 bg-[#EAF2FF]'
        }`}
      >
        <svg
          viewBox="0 0 36 36"
          className={isMobile ? 'w-6 h-6' : 'w-7 h-7'}
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M4 9h4.5l3.6 14.5h14.4l2.8-10H10.2"
            stroke={isMobile ? '#FFFFFF' : '#2874F0'}
            strokeWidth="2.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M12.5 17.5h13M14 21h10.5"
            stroke="#FF9F00"
            strokeWidth="2.1"
            strokeLinecap="round"
          />
          <circle cx="13.5" cy="27.5" r="2.2" fill={isMobile ? '#FFC83D' : '#2874F0'} />
          <circle cx="24.5" cy="27.5" r="2.2" fill={isMobile ? '#FFC83D' : '#2874F0'} />
        </svg>
      </div>
      <div className="leading-tight whitespace-nowrap">
        <span
          className={`block font-display font-bold tracking-tight ${
            isMobile ? 'text-sm text-white' : 'text-[17px] text-[#2874F0]'
          }`}
        >
          Business Manager{' '}
          <span className={isMobile ? 'text-[#FFC83D]' : 'text-[#FF7A30]'}>360</span>
        </span>
      </div>
    </button>
  );
};
