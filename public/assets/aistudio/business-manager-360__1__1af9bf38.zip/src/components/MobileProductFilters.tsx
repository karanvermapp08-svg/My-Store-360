import React from 'react';
import { SlidersHorizontal, X } from 'lucide-react';
import { Category } from '../types/store';
import { FilterState } from './DesktopProductFilters';

interface MobileProductFiltersProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  availableBrands: string[];
  filters: FilterState;
  onChange: (next: FilterState) => void;
  onReset: () => void;
}

export const MobileProductFilters: React.FC<MobileProductFiltersProps> = ({
  isOpen,
  onClose,
  categories,
  availableBrands,
  filters,
  onChange,
  onReset,
}) => {
  if (!isOpen) return null;

  const toggleBrand = (brand: string) => {
    const exists = filters.selectedBrands.includes(brand);
    onChange({
      ...filters,
      selectedBrands: exists
        ? filters.selectedBrands.filter((b) => b !== brand)
        : [...filters.selectedBrands, brand],
    });
  };

  return (
    <div className="lg:hidden fixed inset-0 z-50 flex items-end bg-black/50 backdrop-blur-xs">
      <div className="w-full max-h-[82vh] rounded-t-3xl bg-white flex flex-col overflow-hidden shadow-2xl">
        <div className="w-10 h-1.5 bg-slate-300 rounded-full mx-auto mt-3" />
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-100">
          <div className="flex items-center gap-2 font-display text-base font-bold text-[#202433]">
            <SlidersHorizontal className="w-4 h-4 text-[#2874F0]" />
            <span>Filter &amp; Sort</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500"
            aria-label="Close filters"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-5">
          <div>
            <p className="text-xs font-bold text-[#202433] mb-2">Sort By</p>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  ['popular', 'Popularity'],
                  ['price-asc', 'Price: Low to High'],
                  ['price-desc', 'Price: High to Low'],
                  ['discount', 'Best Discount'],
                ] as [FilterState['sortBy'], string][]
              ).map(([val, label]) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => onChange({ ...filters, sortBy: val })}
                  className={`rounded-xl border px-3 py-2 text-xs font-semibold text-left ${
                    filters.sortBy === val
                      ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                      : 'border-slate-200 text-slate-700'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs font-bold text-[#202433] mb-2">Category</p>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => onChange({ ...filters, categorySlug: 'all' })}
                className={`rounded-xl px-3 py-1.5 text-xs font-medium border ${
                  filters.categorySlug === 'all'
                    ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                    : 'border-slate-200 text-slate-700'
                }`}
              >
                All
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => onChange({ ...filters, categorySlug: c.slug })}
                  className={`rounded-xl px-3 py-1.5 text-xs font-medium border ${
                    filters.categorySlug === c.slug
                      ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                      : 'border-slate-200 text-slate-700'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs font-bold mb-2">
              <span>Max Price</span>
              <span className="text-[#2874F0] tabular-nums">₹{filters.maxPrice}</span>
            </div>
            <input
              type="range"
              min={50}
              max={5000}
              step={50}
              value={filters.maxPrice}
              onChange={(e) => onChange({ ...filters, maxPrice: Number(e.target.value) })}
              className="w-full accent-[#2874F0]"
            />
          </div>

          <div>
            <p className="text-xs font-bold text-[#202433] mb-2">Brands</p>
            <div className="flex flex-wrap gap-2">
              {availableBrands.map((b) => {
                const selected = filters.selectedBrands.includes(b);
                return (
                  <button
                    key={b}
                    type="button"
                    onClick={() => toggleBrand(b)}
                    className={`rounded-xl px-3 py-1.5 text-xs font-medium border ${
                      selected
                        ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    {b}
                  </button>
                );
              })}
            </div>
          </div>

          <label className="flex items-center justify-between py-2">
            <span className="text-sm font-semibold text-[#202433]">Show In-Stock Products Only</span>
            <input
              type="checkbox"
              checked={filters.inStockOnly}
              onChange={(e) => onChange({ ...filters, inStockOnly: e.target.checked })}
              className="w-5 h-5 accent-[#2874F0]"
            />
          </label>
        </div>

        <div className="p-4 border-t border-slate-100 flex items-center gap-3 bg-white">
          <button
            type="button"
            onClick={() => {
              onReset();
              onClose();
            }}
            className="flex-1 rounded-xl border border-slate-300 py-3 text-sm font-semibold text-slate-700"
          >
            Reset
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-2 rounded-xl bg-[#2874F0] py-3 px-6 text-sm font-semibold text-white"
          >
            Apply Filters
          </button>
        </div>
      </div>
    </div>
  );
};
