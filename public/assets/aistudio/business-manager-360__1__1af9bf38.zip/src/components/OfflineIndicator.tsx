import React, { useEffect, useState } from 'react';
import { RefreshCw, WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import {
  SyncStatusSnapshot,
  getSyncStatusSnapshot,
  subscribeSyncStatus,
} from '../db/syncManager';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const [syncStatus, setSyncStatus] = useState<SyncStatusSnapshot>(() => getSyncStatusSnapshot());

  useEffect(() => {
    setSyncStatus(getSyncStatusSnapshot());
    return subscribeSyncStatus(() => {
      setSyncStatus(getSyncStatusSnapshot());
    });
  }, []);

  if (!isOnline) {
    return (
      <div
        role="status"
        aria-live="polite"
        className="fixed bottom-20 lg:bottom-5 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-medium text-white shadow-lg"
      >
        <WifiOff className="w-3.5 h-3.5 shrink-0" />
        <span>
          Offline Mode — Saved locally in IndexedDB
          {syncStatus.pendingCount > 0 ? ` (${syncStatus.pendingCount} pending sync)` : ''}
        </span>
      </div>
    );
  }

  if (syncStatus.isSyncing) {
    return (
      <div
        role="status"
        aria-live="polite"
        className="fixed bottom-20 lg:bottom-5 left-4 z-50 flex items-center gap-2 rounded-xl bg-[#2874F0] px-3.5 py-2 text-xs font-medium text-white shadow-lg"
      >
        <RefreshCw className="w-3.5 h-3.5 shrink-0 animate-spin" />
        <span>Syncing {syncStatus.pendingCount} offline changes...</span>
      </div>
    );
  }

  return null;
};
