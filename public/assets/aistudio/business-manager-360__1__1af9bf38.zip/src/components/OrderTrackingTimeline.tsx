import React, { useState } from 'react';
import {
  CheckCircle2,
  FileText,
  Package,
  Printer,
  RotateCcw,
  Truck,
  X,
  XCircle,
} from 'lucide-react';
import { Invoice, Order, OrderItem, OrderStatus } from '../types/store';
import { orderService } from '../services/serviceContainer';

const STANDARD_STEPS: OrderStatus[] = [
  'Order Placed',
  'Accepted',
  'Processing',
  'Packed',
  'Out for Delivery',
  'Delivered',
];

interface OrderTrackingTimelineProps {
  order: Order;
  invoice?: Invoice;
  onReorder: (items: OrderItem[]) => void;
  onToast: (title: string, description?: string, variant?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const OrderTrackingTimeline: React.FC<OrderTrackingTimelineProps> = ({
  order,
  invoice,
  onReorder,
  onToast,
}) => {
  const [expanded, setExpanded] = useState(false);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [loadingItems, setLoadingItems] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [actionBusy, setActionBusy] = useState(false);

  const stepIndex = STANDARD_STEPS.indexOf(order.status);
  const canCancel = order.status === 'Order Placed' || order.status === 'Accepted';
  const canReturn = order.status === 'Delivered';

  const loadItems = async () => {
    if (items.length > 0) return items;
    setLoadingItems(true);
    try {
      const loaded = await orderService.getOrderItems(order.id);
      setItems(loaded);
      return loaded;
    } finally {
      setLoadingItems(false);
    }
  };

  const handleToggleExpand = async () => {
    const next = !expanded;
    setExpanded(next);
    if (next) await loadItems();
  };

  const handleReorder = async () => {
    const loaded = await loadItems();
    if (loaded.length === 0) {
      onToast('No items found', 'Order line items could not be loaded.', 'warning');
      return;
    }
    onReorder(loaded);
  };

  const handleCancel = async () => {
    setActionBusy(true);
    try {
      await orderService.cancelOrder(order.id, 'Cancelled by customer prior to packing.');
      onToast('Order cancelled', `Order ${order.orderNumber} has been cancelled.`, 'info');
    } catch {
      onToast('Unable to cancel', 'Order may already be processing.', 'error');
    } finally {
      setActionBusy(false);
    }
  };

  const handleReturn = async () => {
    setActionBusy(true);
    try {
      await orderService.requestReturn(order.id, 'Customer requested return after delivery.');
      onToast('Return requested', `Return initiated for ${order.orderNumber}.`, 'info');
    } catch {
      onToast('Unable to request return', 'Please contact customer support.', 'error');
    } finally {
      setActionBusy(false);
    }
  };

  const statusColor =
    order.status === 'Delivered'
      ? 'bg-emerald-50 text-[#16A879]'
      : order.status === 'Cancelled'
      ? 'bg-red-50 text-red-600'
      : order.status === 'Return Requested'
      ? 'bg-amber-50 text-amber-700'
      : 'bg-[#EAF2FF] text-[#2874F0]';

  return (
    <div className="rounded-2xl bg-white border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="font-mono-num text-sm font-bold text-[#202433]">{order.orderNumber}</span>
            <span className={`rounded-lg px-2.5 py-0.5 text-xs font-bold ${statusColor}`}>
              {order.status}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {order.itemCount} items · {order.paymentMethod === 'COD' ? 'Cash on Delivery' : 'Online'} ·{' '}
            {order.deliverySlot || 'Standard Slot'}
          </p>
        </div>

        <div className="text-right">
          <p className="font-display text-base font-extrabold text-[#202433] tabular-nums">
            ₹{order.totalAmount.toLocaleString('en-IN')}
          </p>
          <button
            type="button"
            onClick={handleToggleExpand}
            className="text-xs font-semibold text-[#2874F0] hover:underline mt-0.5 cursor-pointer"
          >
            {expanded ? 'Hide Details' : 'View Details & Items'}
          </button>
        </div>
      </div>

      {/* 6-Step Colorful Visual Timeline */}
      {order.status !== 'Cancelled' && order.status !== 'Return Requested' ? (
        <div className="pt-2 overflow-x-auto">
          <div className="grid grid-cols-6 gap-1 min-w-[520px]">
            {STANDARD_STEPS.map((step, idx) => {
              const completed = stepIndex >= idx;
              const current = stepIndex === idx;
              return (
                <div key={step} className="flex flex-col items-center text-center relative">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold z-10 ${
                      completed
                        ? current
                          ? 'bg-[#FF9F00] text-[#202433] ring-4 ring-[#FF9F00]/20'
                          : 'bg-[#16A879] text-white'
                        : 'bg-slate-100 text-slate-400'
                    }`}
                  >
                    {completed ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                  </div>
                  <span
                    className={`mt-1.5 text-[11px] leading-tight ${
                      completed ? 'font-bold text-[#202433]' : 'text-slate-400'
                    }`}
                  >
                    {step}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-2 rounded-xl bg-slate-50 p-3 text-xs text-slate-700">
          {order.status === 'Cancelled' ? (
            <XCircle className="w-4 h-4 text-red-600 shrink-0" />
          ) : (
            <RotateCcw className="w-4 h-4 text-amber-600 shrink-0" />
          )}
          <span>{order.cancelReason || order.returnReason || `Order status: ${order.status}`}</span>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
        <button
          type="button"
          onClick={handleReorder}
          className="inline-flex items-center gap-1.5 rounded-xl bg-[#EAF2FF] hover:bg-[#D8E8FF] px-3.5 py-2 text-xs font-bold text-[#2874F0] cursor-pointer"
        >
          <Package className="w-3.5 h-3.5" />
          <span>Reorder</span>
        </button>

        <button
          type="button"
          onClick={async () => {
            await loadItems();
            setShowInvoiceModal(true);
          }}
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 px-3.5 py-2 text-xs font-semibold text-[#202433] cursor-pointer"
        >
          <FileText className="w-3.5 h-3.5 text-[#7B4DDB]" />
          <span>{invoice ? 'GST Invoice' : 'Order Receipt'}</span>
        </button>

        {canCancel && (
          <button
            type="button"
            disabled={actionBusy}
            onClick={handleCancel}
            className="inline-flex items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 px-3.5 py-2 text-xs font-semibold text-red-700 cursor-pointer"
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>Cancel Order</span>
          </button>
        )}

        {canReturn && (
          <button
            type="button"
            disabled={actionBusy}
            onClick={handleReturn}
            className="inline-flex items-center gap-1.5 rounded-xl border border-amber-200 bg-amber-50 hover:bg-amber-100 px-3.5 py-2 text-xs font-semibold text-amber-800 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Request Return</span>
          </button>
        )}
      </div>

      {/* Expanded Line Items */}
      {expanded && (
        <div className="pt-3 border-t border-slate-100 space-y-2">
          <p className="text-xs text-slate-500">
            <Truck className="w-3.5 h-3.5 inline mr-1 text-[#2874F0]" />
            Deliver to: <strong className="text-[#202433]">{order.customerName}</strong> — {order.shippingSummary}
          </p>
          {loadingItems ? (
            <p className="text-xs text-slate-400">Loading items...</p>
          ) : (
            <div className="divide-y divide-slate-100 rounded-xl border border-slate-100 bg-[#F7F8FC]">
              {items.map((it) => (
                <div key={it.id} className="p-2.5 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-semibold text-[#202433]">{it.productName}</p>
                    <p className="text-slate-500">
                      Qty {it.quantity} × ₹{it.unitPrice}
                    </p>
                  </div>
                  <span className="font-bold text-[#202433] tabular-nums">₹{it.lineTotal}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Printable Invoice Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <p className="text-xs font-bold text-[#2874F0]">BUSINESS MANAGER 360</p>
                <h3 className="font-display text-lg font-bold text-[#202433]">
                  {invoice ? `Tax Invoice ${invoice.invoiceNumber}` : `Order Receipt ${order.orderNumber}`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowInvoiceModal(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 no-print cursor-pointer"
                aria-label="Close invoice"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-600 space-y-1">
              <p>
                <strong>Billed To:</strong> {order.customerName} ({order.customerPhone})
              </p>
              <p>
                <strong>Address:</strong> {order.shippingSummary}
              </p>
              <p>
                <strong>Order Number:</strong>{' '}
                <span className="font-mono-num">{order.orderNumber}</span>
              </p>
            </div>

            <div className="border-t border-b border-slate-200 py-2 divide-y divide-slate-100 text-xs">
              {items.map((it) => (
                <div key={it.id} className="py-1.5 flex justify-between">
                  <span>
                    {it.productName} × {it.quantity}
                  </span>
                  <span className="font-mono-num font-semibold">₹{it.lineTotal.toFixed(2)}</span>
                </div>
              ))}
            </div>

            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono-num">₹{order.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Included GST</span>
                <span className="font-mono-num">₹{order.gstAmount.toFixed(2)}</span>
              </div>
              {order.discountAmount > 0 && (
                <div className="flex justify-between text-[#16A879]">
                  <span>Discount</span>
                  <span className="font-mono-num">-₹{order.discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Delivery</span>
                <span className="font-mono-num">₹{order.deliveryCharge.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-[#202433] pt-2 border-t border-slate-200">
                <span>Grand Total</span>
                <span className="font-mono-num">₹{order.totalAmount.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 no-print">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 rounded-xl bg-[#2874F0] px-4 py-2 text-xs font-semibold text-white cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Save PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
