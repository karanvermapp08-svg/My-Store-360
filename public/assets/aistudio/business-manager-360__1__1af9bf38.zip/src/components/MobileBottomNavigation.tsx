import React from 'react';
import { Heart, Home, LayoutGrid, Package, User } from 'lucide-react';
import { AccountSection, AppView } from '../types/store';

interface MobileBottomNavigationProps {
  currentView: AppView;
  accountSection: AccountSection;
  wishlistCount: number;
  onSelectHome: () => void;
  onSelectCategories: () => void;
  onSelectWishlist: () => void;
  onSelectOrders: () => void;
  onSelectAccount: () => void;
}

export const MobileBottomNavigation: React.FC<MobileBottomNavigationProps> = ({
  currentView,
  accountSection,
  wishlistCount,
  onSelectHome,
  onSelectCategories,
  onSelectWishlist,
  onSelectOrders,
  onSelectAccount,
}) => {
  const activeTab =
    currentView === 'home'
      ? 'home'
      : currentView === 'catalog'
      ? 'categories'
      : currentView === 'account' && accountSection === 'wishlist'
      ? 'wishlist'
      : currentView === 'account' && accountSection === 'orders'
      ? 'orders'
      : currentView === 'account'
      ? 'account'
      : 'home';

  const tabs = [
    { id: 'home', label: 'Home', icon: Home, onClick: onSelectHome },
    { id: 'categories', label: 'Categories', icon: LayoutGrid, onClick: onSelectCategories },
    { id: 'wishlist', label: 'Wishlist', icon: Heart, badge: wishlistCount, onClick: onSelectWishlist },
    { id: 'orders', label: 'Orders', icon: Package, onClick: onSelectOrders },
    { id: 'account', label: 'Account', icon: User, onClick: onSelectAccount },
  ];

  return (
    <nav
      aria-label="Mobile Bottom Navigation"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-[0_-4px_16px_rgba(0,0,0,0.06)] pb-[env(safe-area-inset-bottom)]"
    >
      <div className="grid grid-cols-5 h-15">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={tab.onClick}
              className={`relative flex flex-col items-center justify-center min-h-[44px] transition-colors cursor-pointer ${
                isActive ? 'text-[#2874F0]' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" strokeWidth={isActive ? 2.4 : 1.9} />
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1.5 -right-2 inline-flex items-center justify-center rounded-full bg-[#E83E8C] px-1 min-w-[15px] h-[15px] text-[9px] font-bold text-white tabular-nums">
                    {tab.badge}
                  </span>
                ) : null}
              </div>
              <span className={`text-[10px] mt-0.5 leading-none ${isActive ? 'font-bold' : 'font-medium'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
