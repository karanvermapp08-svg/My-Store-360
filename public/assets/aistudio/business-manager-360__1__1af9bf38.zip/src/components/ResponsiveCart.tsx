import React from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Bookmark,
  MapPin,
  Minus,
  Plus,
  ShoppingBag,
  Tag,
  Trash2,
} from 'lucide-react';
import { CartItem, Coupon, MembershipTier, Product, StoreSettings } from '../types/store';
import { SelectedLocationState } from './LocationModal';
import { SafeImage } from './SafeImage';

interface ResponsiveCartProps {
  items: CartItem[];
  savedForLater: CartItem[];
  coupons: Coupon[];
  selectedCouponCode: string;
  settings: StoreSettings;
  membershipTier: MembershipTier;
  location: SelectedLocationState;
  suggestedProducts: Product[];
  onUpdateQuantity: (productId: string, qty: number) => void;
  onRemoveItem: (productId: string) => void;
  onSaveForLater: (item: CartItem) => void;
  onMoveSavedToCart: (item: CartItem) => void;
  onRemoveSaved: (productId: string) => void;
  onApplyCoupon: (code: string) => void;
  onAddSuggested: (product: Product) => void;
  onOpenLocation: () => void;
  onProceedCheckout: () => void;
  onContinueShopping: () => void;
}

export const ResponsiveCart: React.FC<ResponsiveCartProps> = ({
  items,
  savedForLater,
  coupons,
  selectedCouponCode,
  settings,
  membershipTier,
  location,
  suggestedProducts,
  onUpdateQuantity,
  onRemoveItem,
  onSaveForLater,
  onMoveSavedToCart,
  onRemoveSaved,
  onApplyCoupon,
  onAddSuggested,
  onOpenLocation,
  onProceedCheckout,
  onContinueShopping,
}) => {
  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const mrpTotal = items.reduce((sum, i) => sum + i.mrp * i.quantity, 0);
  const catalogSavings = Math.max(0, mrpTotal - subtotal);

  const activeCoupon = coupons.find((c) => c.code === selectedCouponCode);
  let couponDiscount = 0;
  if (activeCoupon && subtotal >= activeCoupon.minOrderAmount) {
    couponDiscount =
      activeCoupon.discountType === 'percent'
        ? Math.min(
            activeCoupon.maxDiscount || Infinity,
            (subtotal * activeCoupon.discountValue) / 100
          )
        : activeCoupon.discountValue;
    couponDiscount = Math.min(subtotal, Math.round(couponDiscount));
  }

  const isFreeMember = membershipTier === 'Gold' || membershipTier === 'Premium';
  const deliveryCharge =
    items.length === 0 || isFreeMember || subtotal >= settings.freeDeliveryThreshold
      ? 0
      : settings.deliveryFee;

  const estimatedTotal = Math.max(0, subtotal - couponDiscount + deliveryCharge);
  const freeThresholdLeft = Math.max(0, settings.freeDeliveryThreshold - subtotal);

  const SavedItemsSection =
    savedForLater.length > 0 ? (
      <div className="rounded-2xl bg-white border border-slate-200 p-4 sm:p-5 shadow-xs space-y-3">
        <h2 className="font-display text-base font-bold text-[#202433]">
          Saved for Later ({savedForLater.length})
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {savedForLater.map((item) => (
            <div
              key={item.productId}
              className="flex items-center gap-3 rounded-xl border border-slate-200 p-3"
            >
              <div className="w-14 h-14 rounded-lg bg-slate-50 p-1 shrink-0">
                <SafeImage src={item.image} alt={item.name} className="w-full h-full object-contain" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-[#202433] truncate">{item.name}</p>
                <p className="text-[11px] text-slate-500">{item.unit}</p>
                <p className="text-xs font-extrabold text-[#202433] tabular-nums mt-0.5">
                  ₹{item.price.toLocaleString('en-IN')}
                </p>
                <div className="flex items-center gap-2 mt-1.5">
                  <button
                    type="button"
                    onClick={() => onMoveSavedToCart(item)}
                    className="rounded-lg bg-[#EAF2FF] px-2.5 py-1 text-[11px] font-bold text-[#2874F0] hover:bg-[#D8E8FF] cursor-pointer"
                  >
                    Move to Cart
                  </button>
                  <button
                    type="button"
                    onClick={() => onRemoveSaved(item.productId)}
                    className="text-[11px] font-semibold text-red-600 hover:underline cursor-pointer"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    ) : null;

  if (items.length === 0) {
    return (
      <div className="space-y-6 max-w-3xl mx-auto pb-24 lg:pb-8">
        <div className="rounded-2xl bg-white border border-slate-200 p-8 sm:p-14 text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#EAF2FF] text-[#2874F0] flex items-center justify-center mx-auto">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h2 className="mt-4 font-display text-xl font-bold text-[#202433]">Your shopping cart is empty</h2>
          <p className="mt-1.5 text-sm text-slate-500">
            Explore fresh groceries, dairy, daily essentials, and electronics curated for you.
          </p>
          <button
            type="button"
            onClick={onContinueShopping}
            className="mt-5 rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] px-6 py-3 text-sm font-semibold text-white cursor-pointer"
          >
            Start Shopping
          </button>
        </div>
        {SavedItemsSection}
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-28 lg:pb-8">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-xl sm:text-2xl font-bold text-[#202433]">
          Shopping Cart ({items.reduce((s, i) => s + i.quantity, 0)} items)
        </h1>
        <button
          type="button"
          onClick={onContinueShopping}
          className="text-xs sm:text-sm font-semibold text-[#2874F0] hover:underline cursor-pointer"
        >
          + Add More Items
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Cart Items */}
        <div className="lg:col-span-8 space-y-4">
          {location.serviceable === false ? (
            <div className="rounded-xl bg-red-50 border border-red-200 px-4 py-3 flex items-center justify-between gap-3 text-xs sm:text-sm text-red-800">
              <span className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>
                  Delivery is unavailable for PIN code <strong>{location.pincode}</strong>.
                </span>
              </span>
              <button
                type="button"
                onClick={onOpenLocation}
                className="rounded-lg bg-white border border-red-200 px-3 py-1 text-xs font-bold text-red-700 cursor-pointer shrink-0"
              >
                Change Location
              </button>
            </div>
          ) : (
            <div className="rounded-xl bg-emerald-50/70 border border-emerald-200 px-4 py-2.5 flex items-center justify-between gap-2 text-xs text-emerald-900">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#16A879] shrink-0" />
                <span>
                  Delivering to <strong>{location.city}</strong> ({location.pincode})
                  {location.estimatedDeliveryText ? ` · Est. ${location.estimatedDeliveryText}` : ''}
                </span>
              </span>
              <button
                type="button"
                onClick={onOpenLocation}
                className="font-bold text-[#2874F0] hover:underline cursor-pointer shrink-0"
              >
                Change
              </button>
            </div>
          )}

          {!isFreeMember && freeThresholdLeft > 0 && (
            <div className="rounded-xl bg-[#EAF2FF] border border-blue-200 px-4 py-3 text-xs sm:text-sm text-[#202433]">
              Add <strong className="text-[#2874F0] tabular-nums">₹{freeThresholdLeft}</strong> more for{' '}
              <strong>FREE Delivery</strong> (or upgrade to Gold/Premium).
            </div>
          )}

          <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100 shadow-xs">
            {items.map((item) => (
              <div key={item.productId} className="p-4 flex gap-3.5 sm:gap-4 items-start">
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl border border-slate-100 bg-white p-2 shrink-0">
                  <SafeImage src={item.image} alt={item.name} className="w-full h-full object-contain" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-[11px] font-medium text-slate-500">{item.brand}</p>
                      <h3 className="font-display text-sm sm:text-base font-semibold text-[#202433] line-clamp-2">
                        {item.name}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">{item.unit}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onSaveForLater(item)}
                        title="Save for later"
                        className="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-[11px] font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                      >
                        <Bookmark className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Save for later</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.productId)}
                        aria-label={`Remove ${item.name}`}
                        className="p-2 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-baseline gap-2">
                      <span className="text-base font-extrabold text-[#202433] tabular-nums">
                        ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                      </span>
                      {item.mrp > item.price && (
                        <span className="text-xs text-slate-400 line-through tabular-nums">
                          ₹{(item.mrp * item.quantity).toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center rounded-xl border border-slate-300 bg-white">
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.productId, item.quantity - 1)}
                        className="min-w-[36px] min-h-[36px] flex items-center justify-center text-slate-600 hover:bg-slate-50 cursor-pointer"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 text-xs sm:text-sm font-bold tabular-nums">{item.quantity}</span>
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.productId, Math.min(item.maxStock, item.quantity + 1))}
                        className="min-w-[36px] min-h-[36px] flex items-center justify-center text-slate-600 hover:bg-slate-50 cursor-pointer"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {SavedItemsSection}

          {/* Quick Add-ons */}
          {suggestedProducts.length > 0 && (
            <div className="rounded-2xl bg-white border border-slate-200 p-4 shadow-xs">
              <h3 className="font-display text-sm font-bold text-[#202433] mb-3">
                Frequently Added With Your Basket
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {suggestedProducts.slice(0, 3).map((sp) => (
                  <div key={sp.id} className="flex items-center gap-2.5 rounded-xl border border-slate-200 p-2.5">
                    <div className="w-12 h-12 rounded-lg bg-white p-1 shrink-0">
                      <SafeImage src={sp.images[0]} alt={sp.name} className="w-full h-full object-contain" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-[#202433] truncate">{sp.name}</p>
                      <p className="text-xs font-bold text-[#202433] tabular-nums">₹{sp.price}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onAddSuggested(sp)}
                      className="rounded-lg bg-[#EAF2FF] px-2.5 py-1.5 text-xs font-bold text-[#2874F0] hover:bg-[#D8E8FF] cursor-pointer"
                    >
                      + Add
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right: Price Summary + Coupons */}
        <aside className="lg:col-span-4 lg:sticky lg:top-28 space-y-4">
          <div className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs space-y-4">
            <h2 className="font-display text-base font-bold text-[#202433] pb-3 border-b border-slate-100">
              Price Summary
            </h2>

            {/* Coupon Picker */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-600 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-[#FF7A30]" /> Available Coupons
              </p>
              <div className="flex flex-wrap gap-1.5">
                {coupons.map((c) => {
                  const applied = selectedCouponCode === c.code;
                  return (
                    <button
                      key={c.code}
                      type="button"
                      onClick={() => onApplyCoupon(applied ? '' : c.code)}
                      className={`rounded-lg border px-2.5 py-1.5 text-xs font-mono-num font-bold cursor-pointer ${
                        applied
                          ? 'border-[#16A879] bg-emerald-50 text-[#16A879]'
                          : 'border-slate-200 bg-slate-50 text-[#202433] hover:border-[#2874F0]'
                      }`}
                    >
                      {c.code} {applied ? '✓' : ''}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-2.5 text-sm pt-2 border-t border-slate-100">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal ({items.length} items)</span>
                <span className="font-semibold text-[#202433] tabular-nums">
                  ₹{subtotal.toLocaleString('en-IN')}
                </span>
              </div>
              {catalogSavings > 0 && (
                <div className="flex justify-between text-[#16A879]">
                  <span>Catalog Discount</span>
                  <span className="font-semibold tabular-nums">-₹{catalogSavings.toLocaleString('en-IN')}</span>
                </div>
              )}
              {couponDiscount > 0 && (
                <div className="flex justify-between text-[#16A879]">
                  <span>Coupon ({selectedCouponCode})</span>
                  <span className="font-semibold tabular-nums">-₹{couponDiscount.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Delivery Charge</span>
                <span className="font-semibold tabular-nums">
                  {deliveryCharge === 0 ? (
                    <span className="text-[#16A879]">FREE</span>
                  ) : (
                    `₹${deliveryCharge}`
                  )}
                </span>
              </div>
              <div className="flex justify-between text-base font-extrabold text-[#202433] pt-3 border-t border-slate-200">
                <span>Estimated Total</span>
                <span className="tabular-nums">₹{estimatedTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={onProceedCheckout}
              className="hidden lg:flex w-full min-h-[48px] rounded-xl bg-[#FF9F00] hover:bg-[#F09200] text-[#202433] font-bold text-sm items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </aside>
      </div>

      {/* Mobile Fixed Bottom Checkout Bar */}
      <div className="lg:hidden fixed bottom-15 left-0 right-0 z-30 bg-white border-t border-slate-200 px-4 py-3 flex items-center justify-between gap-4 shadow-[0_-4px_12px_rgba(0,0,0,0.06)]">
        <div>
          <p className="text-[11px] text-slate-500">Estimated Total</p>
          <p className="text-lg font-extrabold text-[#202433] tabular-nums">
            ₹{estimatedTotal.toLocaleString('en-IN')}
          </p>
        </div>
        <button
          type="button"
          onClick={onProceedCheckout}
          className="rounded-xl bg-[#FF9F00] text-[#202433] font-bold text-sm px-6 py-3 flex items-center gap-1.5 shadow-xs"
        >
          <span>Checkout</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
