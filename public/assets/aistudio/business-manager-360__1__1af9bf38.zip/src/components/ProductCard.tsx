import React, { useState } from 'react';
import { Check, CheckCircle2, GitCompareArrows, Heart, ShoppingCart, Star, XCircle } from 'lucide-react';
import { Product } from '../types/store';
import { SafeImage } from './SafeImage';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  isCompared?: boolean;
  onOpenProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  onToggleCompare?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  isCompared = false,
  onOpenProduct,
  onAddToCart,
  onToggleWishlist,
  onToggleCompare,
}) => {
  const [justAdded, setJustAdded] = useState(false);

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.inStock || product.stock <= 0) return;
    onAddToCart(product);
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 900);
  };

  return (
    <article className="group flex flex-col justify-between rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-md hover:-translate-y-0.5 transition-all overflow-hidden">
      {/* Image + Top Discount Badge */}
      <div
        role="button"
        tabIndex={0}
        onClick={() => onOpenProduct(product)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onOpenProduct(product);
          }
        }}
        className="relative cursor-pointer focus-visible:outline-2 focus-visible:outline-[#2874F0]"
      >
        {product.discountPercent > 0 && (
          <span className="absolute top-2.5 left-2.5 z-10 rounded-md bg-[#E83E8C] px-2 py-0.5 text-[11px] font-bold text-white shadow-xs">
            {product.discountPercent}% OFF
          </span>
        )}

        {onToggleCompare && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleCompare(product);
            }}
            title={isCompared ? 'Remove from comparison' : 'Compare product'}
            aria-label={isCompared ? 'Remove from comparison' : 'Compare product'}
            className={`absolute top-2 right-2 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
              isCompared
                ? 'bg-[#2874F0] text-white'
                : 'bg-white/90 text-slate-500 hover:text-[#2874F0] border border-slate-200'
            }`}
          >
            <GitCompareArrows className="w-3.5 h-3.5" />
          </button>
        )}

        <div className="aspect-[4/3] w-full bg-white p-3 sm:p-4 overflow-hidden flex items-center justify-center">
          <SafeImage
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-200"
          />
        </div>
      </div>

      {/* Product Details */}
      <div className="p-3 sm:p-3.5 pt-0 flex flex-col flex-1 justify-between gap-2.5">
        <div
          onClick={() => onOpenProduct(product)}
          className="cursor-pointer space-y-1"
        >
          <div className="flex items-center justify-between gap-1 text-[11px] text-slate-500">
            <span className="truncate font-medium">{product.brand}</span>
            <span className="inline-flex items-center gap-0.5 text-amber-600 font-semibold shrink-0 tabular-nums">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              {product.rating.toFixed(1)}
            </span>
          </div>

          <h3 className="font-display text-xs sm:text-sm font-semibold text-[#202433] leading-snug line-clamp-2 min-h-[2.4em]">
            {product.name}
          </h3>

          <p className="text-[11px] sm:text-xs text-slate-500">{product.unit}</p>

          <div className="flex items-baseline gap-2 pt-0.5">
            <span className="text-sm sm:text-base font-extrabold text-[#202433] tabular-nums">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            {product.mrp > product.price && (
              <span className="text-[11px] sm:text-xs text-slate-400 line-through tabular-nums">
                ₹{product.mrp.toLocaleString('en-IN')}
              </span>
            )}
          </div>

          <div className="pt-0.5">
            {product.inStock && product.stock > 0 ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#16A879]">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>{product.stock <= 5 ? `Only ${product.stock} left` : 'In Stock'}</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-600">
                <XCircle className="w-3.5 h-3.5 shrink-0" />
                <span>Out of Stock</span>
              </span>
            )}
          </div>
        </div>

        {/* Action Bar */}
        <div className="flex items-center gap-1.5 pt-1">
          <button
            type="button"
            disabled={!product.inStock || product.stock <= 0}
            onClick={handleAdd}
            className={`flex-1 min-h-[38px] rounded-xl px-2.5 py-2 text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] whitespace-nowrap cursor-pointer disabled:bg-slate-300 disabled:cursor-not-allowed ${
              justAdded ? 'bg-[#16A879]' : 'bg-[#2874F0] hover:bg-[#1A56C4]'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added</span>
              </>
            ) : (
              <>
                <ShoppingCart className="w-3.5 h-3.5 hidden sm:inline" />
                <span>{product.inStock && product.stock > 0 ? 'Add to Cart' : 'Sold Out'}</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(product);
            }}
            aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
            className={`min-w-[38px] min-h-[38px] rounded-xl border flex items-center justify-center transition-colors cursor-pointer ${
              isWishlisted
                ? 'border-pink-200 bg-pink-50 text-[#E83E8C]'
                : 'border-slate-200 bg-white text-slate-500 hover:text-[#E83E8C] hover:border-pink-200'
            }`}
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-[#E83E8C]' : ''}`} />
          </button>
        </div>
      </div>
    </article>
  );
};
