import React, { useEffect, useState } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { HERO_BANNERS } from '../data/catalogSeed';
import { SafeImage } from './SafeImage';

interface HeroCarouselProps {
  onSelectCategory: (slug: string) => void;
}

export const HeroCarousel: React.FC<HeroCarouselProps> = ({ onSelectCategory }) => {
  const [index, setIndex] = useState(0);
  const [touchStartX, setTouchStartX] = useState<number | null>(null);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setIndex((prev) => (prev + 1) % HERO_BANNERS.length);
    }, 6500);
    return () => window.clearInterval(timer);
  }, []);

  const current = HERO_BANNERS[index];

  return (
    <section aria-label="Featured Promotions" className="relative">
      <div
        className={`relative overflow-hidden rounded-2xl lg:rounded-3xl bg-gradient-to-r ${current.gradient} text-white shadow-md`}
        onTouchStart={(e) => setTouchStartX(e.touches[0].clientX)}
        onTouchEnd={(e) => {
          if (touchStartX === null) return;
          const diff = e.changedTouches[0].clientX - touchStartX;
          if (diff > 45) setIndex((prev) => (prev - 1 + HERO_BANNERS.length) % HERO_BANNERS.length);
          else if (diff < -45) setIndex((prev) => (prev + 1) % HERO_BANNERS.length);
          setTouchStartX(null);
        }}
      >
        <div className="grid grid-cols-1 md:grid-cols-12 items-stretch min-h-[210px] sm:min-h-[260px] lg:min-h-[340px]">
          {/* Copy Column */}
          <div className="md:col-span-6 p-5 sm:p-8 lg:p-12 flex flex-col justify-center relative z-10">
            <span className="text-xs font-semibold text-white/85 tracking-wide">
              {current.eyebrow}
            </span>
            <h1 className="mt-1.5 font-display text-2xl sm:text-3xl lg:text-[42px] font-extrabold leading-[1.12] tracking-tight text-balance">
              {current.title}
            </h1>
            <p className="mt-2.5 text-xs sm:text-sm lg:text-base text-white/90 max-w-md leading-relaxed">
              {current.subtitle}
            </p>
            <div className="mt-4 sm:mt-6 flex items-center gap-3">
              <button
                type="button"
                onClick={() => onSelectCategory(current.targetCategory)}
                className="inline-flex items-center gap-2 rounded-full bg-[#FF9F00] hover:bg-[#F59200] px-5 py-2.5 text-xs sm:text-sm font-bold text-[#202433] shadow-sm transition-transform active:scale-[0.98] whitespace-nowrap cursor-pointer"
              >
                <span>{current.ctaLabel}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <span className="inline-flex items-center justify-center rounded-full bg-[#FFC83D] px-3 py-1.5 text-xs font-extrabold text-[#202433] whitespace-nowrap">
                {current.badge}
              </span>
            </div>
          </div>

          {/* Visual Column */}
          <div className="md:col-span-6 relative min-h-[160px] sm:min-h-[220px] lg:min-h-[340px] overflow-hidden">
            <SafeImage
              src={current.image}
              alt={current.title}
              eager
              className="w-full h-full object-cover object-center"
            />
            <div className="hidden md:block absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-black/15 to-transparent pointer-events-none" />
          </div>
        </div>

        {/* Desktop Carousel Controls */}
        <button
          type="button"
          onClick={() => setIndex((prev) => (prev - 1 + HERO_BANNERS.length) % HERO_BANNERS.length)}
          aria-label="Previous promotional banner"
          className="hidden sm:flex absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-[#202433] items-center justify-center shadow-md transition-transform hover:scale-105 cursor-pointer z-20"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          type="button"
          onClick={() => setIndex((prev) => (prev + 1) % HERO_BANNERS.length)}
          aria-label="Next promotional banner"
          className="hidden sm:flex absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-[#202433] items-center justify-center shadow-md transition-transform hover:scale-105 cursor-pointer z-20"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Dots */}
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
          {HERO_BANNERS.map((b, i) => (
            <button
              key={b.id}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Show banner ${i + 1}`}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                i === index ? 'w-6 bg-[#FFC83D]' : 'w-2 bg-white/60 hover:bg-white'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
