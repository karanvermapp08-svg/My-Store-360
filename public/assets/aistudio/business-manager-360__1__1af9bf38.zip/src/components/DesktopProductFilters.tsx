import React from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { Category } from '../types/store';

export interface FilterState {
  categorySlug: string;
  maxPrice: number;
  selectedBrands: string[];
  minDiscount: number;
  inStockOnly: boolean;
  sortBy: 'popular' | 'price-asc' | 'price-desc' | 'discount';
}

interface DesktopProductFiltersProps {
  categories: Category[];
  availableBrands: string[];
  filters: FilterState;
  onChange: (next: FilterState) => void;
  onReset: () => void;
}

export const DesktopProductFilters: React.FC<DesktopProductFiltersProps> = ({
  categories,
  availableBrands,
  filters,
  onChange,
  onReset,
}) => {
  const toggleBrand = (brand: string) => {
    const exists = filters.selectedBrands.includes(brand);
    onChange({
      ...filters,
      selectedBrands: exists
        ? filters.selectedBrands.filter((b) => b !== brand)
        : [...filters.selectedBrands, brand],
    });
  };

  return (
    <aside className="hidden lg:block w-64 shrink-0">
      <div className="sticky top-28 rounded-2xl bg-white border border-slate-200/80 p-4 space-y-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2 font-display text-sm font-bold text-[#202433]">
            <SlidersHorizontal className="w-4 h-4 text-[#2874F0]" />
            <span>Filters</span>
          </div>
          <button
            type="button"
            onClick={onReset}
            className="text-xs font-semibold text-[#2874F0] hover:underline cursor-pointer"
          >
            Clear All
          </button>
        </div>

        {/* Category */}
        <div>
          <p className="text-xs font-bold text-[#202433] mb-2">Category</p>
          <div className="space-y-1 max-h-52 overflow-y-auto pr-1">
            <button
              type="button"
              onClick={() => onChange({ ...filters, categorySlug: 'all' })}
              className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                filters.categorySlug === 'all'
                  ? 'bg-[#EAF2FF] text-[#2874F0] font-semibold'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              All Categories
            </button>
            {categories.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => onChange({ ...filters, categorySlug: c.slug })}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                  filters.categorySlug === c.slug
                    ? 'bg-[#EAF2FF] text-[#2874F0] font-semibold'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Price Slider */}
        <div>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-bold text-[#202433]">Max Price</span>
            <span className="font-semibold text-[#2874F0] tabular-nums">
              ₹{filters.maxPrice.toLocaleString('en-IN')}
            </span>
          </div>
          <input
            type="range"
            min={50}
            max={5000}
            step={50}
            value={filters.maxPrice}
            onChange={(e) => onChange({ ...filters, maxPrice: Number(e.target.value) })}
            className="w-full accent-[#2874F0] cursor-pointer"
          />
          <div className="flex justify-between text-[11px] text-slate-400 tabular-nums mt-1">
            <span>₹50</span>
            <span>₹5,000+</span>
          </div>
        </div>

        {/* Discount */}
        <div>
          <p className="text-xs font-bold text-[#202433] mb-2">Minimum Discount</p>
          <div className="grid grid-cols-2 gap-1.5">
            {[0, 15, 25, 35].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => onChange({ ...filters, minDiscount: d })}
                className={`rounded-lg border px-2.5 py-1.5 text-xs font-medium cursor-pointer ${
                  filters.minDiscount === d
                    ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {d === 0 ? 'Any' : `${d}%+ OFF`}
              </button>
            ))}
          </div>
        </div>

        {/* Brands */}
        <div>
          <p className="text-xs font-bold text-[#202433] mb-2">Brand</p>
          <div className="space-y-1.5 max-h-40 overflow-y-auto">
            {availableBrands.map((brand) => (
              <label key={brand} className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={filters.selectedBrands.includes(brand)}
                  onChange={() => toggleBrand(brand)}
                  className="rounded border-slate-300 accent-[#2874F0]"
                />
                <span className="truncate">{brand}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Availability */}
        <label className="flex items-center justify-between pt-2 border-t border-slate-100 cursor-pointer">
          <span className="text-xs font-semibold text-[#202433]">In Stock Only</span>
          <input
            type="checkbox"
            checked={filters.inStockOnly}
            onChange={(e) => onChange({ ...filters, inStockOnly: e.target.checked })}
            className="rounded border-slate-300 accent-[#2874F0] w-4 h-4"
          />
        </label>
      </div>
    </aside>
  );
};
