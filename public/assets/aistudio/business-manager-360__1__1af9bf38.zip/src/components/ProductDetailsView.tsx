import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Camera,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Flag,
  GitCompareArrows,
  Heart,
  MapPin,
  Minus,
  PackageCheck,
  Plus,
  RotateCcw,
  ShieldCheck,
  ShoppingCart,
  Star,
  Tag,
  ThumbsUp,
  Truck,
  X,
  XCircle,
  Zap,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { TransformComponent, TransformWrapper, ReactZoomPanPinchRef } from 'react-zoom-pan-pinch';
import {
  Coupon,
  CustomerUser,
  Product,
  ProductReview,
  ReviewEligibilityResult,
  StoreSettings,
} from '../types/store';
import { productService } from '../services/serviceContainer';
import { SelectedLocationState } from './LocationModal';
import { SafeImage } from './SafeImage';
import { ProductCard } from './ProductCard';

interface ProductDetailsViewProps {
  product: Product;
  allProducts: Product[];
  recentlyViewedProducts?: Product[];
  coupons: Coupon[];
  settings: StoreSettings;
  user: CustomerUser | null;
  location: SelectedLocationState;
  wishlistIds: string[];
  compareIds: string[];
  onBack: () => void;
  onOpenLocation: () => void;
  onAddToCart: (
    product: Product,
    quantity: number,
    variantLabel?: string,
    variantPrice?: number,
    variantMrp?: number
  ) => void;
  onBuyNow: (
    product: Product,
    quantity: number,
    variantLabel?: string,
    variantPrice?: number,
    variantMrp?: number
  ) => void;
  onToggleWishlist: (product: Product) => void;
  onToggleCompare: (product: Product) => void;
  onOpenProduct: (product: Product) => void;
  onRequireSignIn: () => void;
  onToast: (
    title: string,
    description?: string,
    variant?: 'success' | 'info' | 'warning' | 'error'
  ) => void;
}

function resizeImageToDataUrl(file: File, maxDim = 480): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result || ''));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.78));
      };
      img.onerror = () => reject(new Error('Invalid image file'));
      img.src = String(reader.result || '');
    };
    reader.onerror = () => reject(new Error('Could not read file'));
    reader.readAsDataURL(file);
  });
}

export const ProductDetailsView: React.FC<ProductDetailsViewProps> = ({
  product,
  allProducts,
  recentlyViewedProducts = [],
  coupons,
  settings,
  user,
  location,
  wishlistIds,
  compareIds,
  onBack,
  onOpenLocation,
  onAddToCart,
  onBuyNow,
  onToggleWishlist,
  onToggleCompare,
  onOpenProduct,
  onRequireSignIn,
  onToast,
}) => {
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [desktopZoomOrigin, setDesktopZoomOrigin] = useState({ x: 50, y: 50 });
  const [desktopHovering, setDesktopHovering] = useState(false);
  const [mobileZoomScale, setMobileZoomScale] = useState(1);
  const mobileTransformRef = useRef<ReactZoomPanPinchRef | null>(null);

  const [selectedVariantIdx, setSelectedVariantIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);

  // Discovery & Reviews State
  const [alsoBoughtProducts, setAlsoBoughtProducts] = useState<Product[]>([]);
  const [fbtSelectedIds, setFbtSelectedIds] = useState<string[]>([]);
  const [reviews, setReviews] = useState<ProductReview[]>([]);
  const [eligibility, setEligibility] = useState<ReviewEligibilityResult | null>(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [reviewPhotos, setReviewPhotos] = useState<string[]>([]);
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewSort, setReviewSort] = useState<'helpful' | 'newest' | 'highest' | 'lowest'>('helpful');
  const [reviewFilter, setReviewFilter] = useState<'all' | 'verified' | 'photos' | '5' | '4' | '3' | '2' | '1'>('all');
  const [reportingReviewId, setReportingReviewId] = useState<string | null>(null);
  const [lightboxPhoto, setLightboxPhoto] = useState<string | null>(null);

  const fbtProducts = useMemo(() => {
    const preferred = (product.frequentlyBoughtIds || [])
      .map((id) => allProducts.find((p) => p.id === id && p.inStock && p.stock > 0))
      .filter((p): p is Product => Boolean(p));
    if (preferred.length >= 2) return preferred.slice(0, 2);
    const fallback = allProducts.filter(
      (p) => p.id !== product.id && p.inStock && p.stock > 0 && !preferred.some((x) => x.id === p.id)
    );
    return [...preferred, ...fallback].slice(0, 2);
  }, [product.id, product.frequentlyBoughtIds, allProducts]);

  const similarProducts = useMemo(() => {
    const sameCategory = allProducts.filter(
      (p) => p.id !== product.id && p.categoryId === product.categoryId
    );
    if (sameCategory.length >= 4) return sameCategory.slice(0, 4);
    const sameTag = allProducts.filter(
      (p) =>
        p.id !== product.id &&
        p.categoryId !== product.categoryId &&
        (p.tags || []).some((t) => (product.tags || []).includes(t))
    );
    return [...sameCategory, ...sameTag].slice(0, 4);
  }, [product.id, product.categoryId, product.tags, allProducts]);

  useEffect(() => {
    setSelectedImageIdx(0);
    setSelectedVariantIdx(0);
    setQuantity(1);
    setDesktopHovering(false);
    setMobileZoomScale(1);
    setReviewTitle('');
    setReviewComment('');
    setReviewPhotos([]);
    setReportingReviewId(null);
    mobileTransformRef.current?.resetTransform(0);

    productService.getProductReviews(product.id).then(setReviews).catch(() => setReviews([]));
    productService.getCustomersAlsoBought(product.id).then(setAlsoBoughtProducts).catch(() => setAlsoBoughtProducts([]));
  }, [product.id]);

  useEffect(() => {
    productService
      .getReviewEligibility(user?.uid || null, product.id)
      .then(setEligibility)
      .catch(() => setEligibility(null));
  }, [user?.uid, product.id, reviews.length]);

  useEffect(() => {
    setFbtSelectedIds([product.id, ...fbtProducts.map((p) => p.id)]);
  }, [product.id, fbtProducts]);

  useEffect(() => {
    setMobileZoomScale(1);
    mobileTransformRef.current?.resetTransform(0);
  }, [selectedImageIdx]);

  const variants = product.variants && product.variants.length > 0 ? product.variants : null;
  const activeVariant = variants ? variants[selectedVariantIdx] || variants[0] : null;
  const activePrice = activeVariant ? activeVariant.price : product.price;
  const activeMrp = activeVariant ? activeVariant.mrp : product.mrp;
  const activeUnit = activeVariant ? activeVariant.label : product.unit;
  const activeStock = activeVariant ? activeVariant.stock : product.stock;
  const discountPct = activeMrp > 0 ? Math.max(0, Math.round(((activeMrp - activePrice) / activeMrp) * 100)) : 0;
  const inStock = product.inStock && activeStock > 0;
  const locationAvailable = location.serviceable !== false;
  const canPurchase = inStock && locationAvailable;

  const isWishlisted = wishlistIds.includes(product.id);
  const isCompared = compareIds.includes(product.id);
  const currentImage = product.images[selectedImageIdx] || product.images[0];

  // Bundle calculation for Frequently Bought Together
  const fbtBundleItems = useMemo(() => {
    const items: { id: string; price: number; mrp: number; product?: Product; isPrimary?: boolean }[] = [];
    if (fbtSelectedIds.includes(product.id)) {
      items.push({ id: product.id, price: activePrice, mrp: activeMrp, isPrimary: true });
    }
    fbtProducts.forEach((fp) => {
      if (fbtSelectedIds.includes(fp.id)) {
        items.push({ id: fp.id, price: fp.price, mrp: fp.mrp, product: fp });
      }
    });
    return items;
  }, [fbtSelectedIds, product.id, activePrice, activeMrp, fbtProducts]);

  const fbtTotalPrice = fbtBundleItems.reduce((s, i) => s + i.price, 0);
  const fbtTotalMrp = fbtBundleItems.reduce((s, i) => s + i.mrp, 0);

  // Review Rating Distribution & Photo Gallery
  const ratingDistribution = useMemo(() => {
    const counts: Record<number, number> = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    if (reviews.length > 0) {
      reviews.forEach((r) => {
        const star = Math.max(1, Math.min(5, Math.round(r.rating)));
        counts[star] += 1;
      });
    }
    const total = reviews.length || 1;
    return [5, 4, 3, 2, 1].map((star) => ({
      star,
      count: counts[star],
      percent: reviews.length > 0 ? Math.round((counts[star] / total) * 100) : star === Math.round(product.rating) ? 70 : 10,
    }));
  }, [reviews, product.rating]);

  const allCustomerPhotos = useMemo(() => {
    const urls: string[] = [];
    reviews.forEach((r) => {
      (r.photos || []).forEach((p) => urls.push(p));
    });
    return urls;
  }, [reviews]);

  const displayedReviews = useMemo(() => {
    const filtered = reviews.filter((r) => {
      if (reviewFilter === 'verified') return Boolean(r.verifiedPurchase);
      if (reviewFilter === 'photos') return Boolean(r.photos && r.photos.length > 0);
      if (['5', '4', '3', '2', '1'].includes(reviewFilter)) {
        return Math.round(r.rating) === Number(reviewFilter);
      }
      return true;
    });

    return [...filtered].sort((a, b) => {
      if (reviewSort === 'helpful') return (b.helpfulCount || 0) - (a.helpfulCount || 0);
      if (reviewSort === 'highest') return b.rating - a.rating;
      if (reviewSort === 'lowest') return a.rating - b.rating;
      return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
    });
  }, [reviews, reviewFilter, reviewSort]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []).slice(0, 3 - reviewPhotos.length);
    if (files.length === 0) return;
    try {
      const encoded = await Promise.all(files.map((f) => resizeImageToDataUrl(f)));
      setReviewPhotos((prev) => [...prev, ...encoded].slice(0, 3));
    } catch {
      onToast('Photo upload failed', 'Please choose a valid JPG/PNG image.', 'error');
    }
    e.target.value = '';
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onRequireSignIn();
      return;
    }
    if (eligibility && !eligibility.canSubmit) {
      onToast('Review already submitted', eligibility.reason, 'info');
      return;
    }
    if (reviewComment.trim().length < 3) return;
    setSubmittingReview(true);
    try {
      const created = await productService.addProductReview({
        productId: product.id,
        userId: user.uid,
        authorName: user.displayName || 'Customer',
        rating: reviewRating,
        title: reviewTitle.trim(),
        comment: reviewComment.trim(),
        photos: reviewPhotos,
      });
      setReviews((prev) => [created, ...prev]);
      setReviewTitle('');
      setReviewComment('');
      setReviewPhotos([]);
      onToast(
        created.verifiedPurchase ? 'Verified Purchase review posted' : 'Review posted',
        'Thank you for sharing feedback with Business Manager 360 shoppers.'
      );
    } catch (err) {
      onToast(
        'Could not submit review',
        err instanceof Error ? err.message : 'Please check your review text and try again.',
        'warning'
      );
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleHelpfulVote = async (reviewId: string) => {
    if (!user) {
      onRequireSignIn();
      return;
    }
    const updated = await productService.toggleReviewHelpful(reviewId, user.uid);
    setReviews((prev) => prev.map((r) => (r.id === reviewId ? updated : r)));
  };

  const handleReportReview = async (reviewId: string, reason: string) => {
    if (!user) {
      onRequireSignIn();
      return;
    }
    const updated = await productService.reportReview(reviewId, user.uid, reason);
    setReviews((prev) => prev.map((r) => (r.id === reviewId ? updated : r)));
    setReportingReviewId(null);
    onToast('Review reported', 'Our customer trust team will inspect this review.', 'info');
  };

  const otherRecentlyViewed = recentlyViewedProducts.filter((p) => p.id !== product.id).slice(0, 4);

  return (
    <div className="space-y-8 pb-24 lg:pb-8">
      {/* Breadcrumb / Back */}
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 rounded-xl bg-white border border-slate-200 px-3.5 py-2 text-xs sm:text-sm font-semibold text-[#202433] hover:bg-slate-50 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Shopping</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span className="hidden sm:inline">{product.categoryName}</span>
          <span className="hidden sm:inline" aria-hidden="true">·</span>
          <span className="font-mono-num">SKU: {product.sku}</span>
        </div>
      </div>

      {/* Main 2-Column PDP */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
        {/* Left: Image Gallery */}
        <div className="lg:col-span-5 lg:sticky lg:top-28 space-y-3">
          {/* MOBILE / TABLET GALLERY: react-zoom-pan-pinch Pinch-to-Zoom */}
          <div className="lg:hidden relative aspect-[4/3] rounded-2xl bg-white border border-slate-200 overflow-hidden select-none">
            {discountPct > 0 && (
              <span className="absolute top-3 left-3 z-20 rounded-lg bg-[#E83E8C] px-2.5 py-1 text-xs font-bold text-white pointer-events-none">
                {discountPct}% OFF
              </span>
            )}
            {product.isComboPack && (
              <span className="absolute top-3 right-3 z-20 rounded-lg bg-[#7B4DDB] px-2.5 py-1 text-xs font-bold text-white pointer-events-none">
                Combo Pack
              </span>
            )}

            <TransformWrapper
              ref={mobileTransformRef}
              initialScale={1}
              minScale={1}
              maxScale={3.5}
              centerOnInit
              wheel={{ disabled: true }}
              pinch={{ step: 5 }}
              doubleClick={{ mode: 'toggle', step: 1.2 }}
              panning={{ disabled: mobileZoomScale <= 1.02 }}
              onTransform={(_ref, state) => setMobileZoomScale(state.scale)}
            >
              {({ zoomIn, zoomOut, resetTransform }) => (
                <>
                  <TransformComponent
                    wrapperClass="!w-full !h-full"
                    contentClass="!w-full !h-full flex items-center justify-center p-5"
                  >
                    <SafeImage
                      src={currentImage}
                      alt={product.name}
                      eager
                      className="w-full h-full max-h-[320px] object-contain"
                    />
                  </TransformComponent>

                  {product.images.length > 1 && mobileZoomScale <= 1.02 && (
                    <>
                      <button
                        type="button"
                        onClick={() =>
                          setSelectedImageIdx((i) => (i - 1 + product.images.length) % product.images.length)
                        }
                        aria-label="Previous image"
                        className="absolute left-2 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full bg-white/90 border border-slate-200 flex items-center justify-center text-slate-700 shadow-xs"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedImageIdx((i) => (i + 1) % product.images.length)}
                        aria-label="Next image"
                        className="absolute right-2 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full bg-white/90 border border-slate-200 flex items-center justify-center text-slate-700 shadow-xs"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </>
                  )}

                  <div className="absolute bottom-2.5 right-2.5 z-20 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => zoomOut(0.4)}
                      disabled={mobileZoomScale <= 1.02}
                      aria-label="Zoom out"
                      className="w-7 h-7 rounded-lg bg-slate-900/75 text-white flex items-center justify-center disabled:opacity-40"
                    >
                      <ZoomOut className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => zoomIn(0.4)}
                      disabled={mobileZoomScale >= 3.4}
                      aria-label="Zoom in"
                      className="w-7 h-7 rounded-lg bg-slate-900/75 text-white flex items-center justify-center disabled:opacity-40"
                    >
                      <ZoomIn className="w-3.5 h-3.5" />
                    </button>
                    {mobileZoomScale > 1.02 ? (
                      <button
                        type="button"
                        onClick={() => resetTransform()}
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-900/85 px-2.5 py-1 text-[11px] font-semibold text-white"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>{mobileZoomScale.toFixed(1)}× · Reset</span>
                      </button>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-lg bg-slate-900/70 px-2.5 py-1 text-[11px] font-medium text-white pointer-events-none">
                        Pinch to zoom
                      </span>
                    )}
                  </div>
                </>
              )}
            </TransformWrapper>
          </div>

          {/* DESKTOP GALLERY: CSS Hover-to-Zoom Effect */}
          <div
            className="hidden lg:flex group relative aspect-[4/3] rounded-2xl bg-white border border-slate-200 overflow-hidden items-center justify-center p-6 cursor-crosshair select-none"
            onMouseEnter={() => setDesktopHovering(true)}
            onMouseLeave={() => setDesktopHovering(false)}
            onMouseMove={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const x = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
              const y = Math.max(0, Math.min(100, ((e.clientY - rect.top) / rect.height) * 100));
              setDesktopZoomOrigin({ x, y });
            }}
          >
            {discountPct > 0 && (
              <span className="absolute top-3 left-3 z-10 rounded-lg bg-[#E83E8C] px-2.5 py-1 text-xs font-bold text-white pointer-events-none">
                {discountPct}% OFF
              </span>
            )}
            {product.isComboPack && (
              <span className="absolute top-3 right-3 z-10 rounded-lg bg-[#7B4DDB] px-2.5 py-1 text-xs font-bold text-white pointer-events-none">
                Value Combo Pack
              </span>
            )}

            <span className="inline-flex items-center gap-1 absolute bottom-3 right-3 z-10 rounded-lg bg-slate-900/75 px-2.5 py-1 text-[11px] font-medium text-white pointer-events-none">
              <ZoomIn className="w-3.5 h-3.5" /> {desktopHovering ? 'Zooming 1.9×' : 'Hover to zoom'}
            </span>

            {desktopHovering && (
              <div
                aria-hidden="true"
                className="absolute z-10 w-24 h-24 -translate-x-1/2 -translate-y-1/2 rounded-xl border-2 border-[#2874F0]/60 bg-[#2874F0]/10 pointer-events-none shadow-xs"
                style={{ left: `${desktopZoomOrigin.x}%`, top: `${desktopZoomOrigin.y}%` }}
              />
            )}

            <div
              className="w-full h-full transition-transform duration-200 ease-out group-hover:scale-[1.9] will-change-transform"
              style={{ transformOrigin: `${desktopZoomOrigin.x}% ${desktopZoomOrigin.y}%` }}
            >
              <SafeImage
                src={currentImage}
                alt={product.name}
                eager
                className="w-full h-full object-contain pointer-events-none"
              />
            </div>
          </div>

          {product.images.length > 1 && (
            <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setSelectedImageIdx(i)}
                  className={`w-16 h-16 rounded-xl border bg-white p-1.5 shrink-0 cursor-pointer ${
                    i === selectedImageIdx ? 'border-[#2874F0] ring-2 ring-[#2874F0]/20' : 'border-slate-200'
                  }`}
                >
                  <SafeImage src={img} alt={`${product.name} view ${i + 1}`} className="w-full h-full object-contain" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Contiguous Purchase & Spec Module */}
        <div className="lg:col-span-7 space-y-5">
          <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-semibold text-[#2874F0] tracking-wide uppercase">
                  {product.brand} · {product.categoryName}
                </p>
                <h1 className="mt-1 font-display text-xl sm:text-2xl lg:text-3xl font-bold text-[#202433] leading-tight">
                  {product.name}
                </h1>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onToggleCompare(product)}
                  aria-label="Compare product"
                  className={`min-w-[40px] min-h-[40px] rounded-xl border flex items-center justify-center cursor-pointer ${
                    isCompared
                      ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                      : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  <GitCompareArrows className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onToggleWishlist(product)}
                  aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
                  className={`min-w-[40px] min-h-[40px] rounded-xl border flex items-center justify-center cursor-pointer ${
                    isWishlisted
                      ? 'border-pink-200 bg-pink-50 text-[#E83E8C]'
                      : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-[#E83E8C]' : ''}`} />
                </button>
              </div>
            </div>

            {/* Rating & Stock */}
            <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm">
              <span className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 px-2.5 py-1 font-bold text-[#16A879] tabular-nums">
                <span>{product.rating.toFixed(1)}</span>
                <Star className="w-3.5 h-3.5 fill-[#16A879]" />
              </span>
              <span className="text-slate-500 tabular-nums">
                {product.reviewCount + reviews.length} ratings &amp; {reviews.length} customer reviews
              </span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              {inStock ? (
                <span className="inline-flex items-center gap-1 font-semibold text-[#16A879]">
                  <CheckCircle2 className="w-4 h-4" />
                  In Stock ({activeStock} available)
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 font-semibold text-red-600">
                  <XCircle className="w-4 h-4" />
                  Out of Stock
                </span>
              )}
            </div>

            {/* Price Block */}
            <div className="rounded-xl bg-[#F7F8FC] p-4 flex flex-wrap items-baseline gap-3">
              <span className="font-display text-2xl sm:text-3xl font-extrabold text-[#202433] tabular-nums">
                ₹{activePrice.toLocaleString('en-IN')}
              </span>
              {activeMrp > activePrice && (
                <span className="text-sm sm:text-base text-slate-400 line-through tabular-nums">
                  MRP ₹{activeMrp.toLocaleString('en-IN')}
                </span>
              )}
              {discountPct > 0 && (
                <span className="text-sm font-bold text-[#16A879] tabular-nums">
                  Save ₹{(activeMrp - activePrice).toLocaleString('en-IN')} ({discountPct}% off)
                </span>
              )}
              <span className="w-full text-xs text-slate-500">
                Inclusive of all taxes ({product.gstPercent}% GST invoice supported)
              </span>
            </div>

            {/* Combo Contents Breakdown */}
            {product.isComboPack && product.bundleItems && product.bundleItems.length > 0 && (
              <div className="rounded-xl border border-purple-200 bg-purple-50/50 p-3.5 space-y-1.5">
                <p className="text-xs font-bold text-[#7B4DDB] flex items-center gap-1.5">
                  <PackageCheck className="w-4 h-4" /> Included in this Value Combo Pack
                </p>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-xs text-[#202433]">
                  {product.bundleItems.map((b) => (
                    <li key={b} className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-[#16A879] shrink-0" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Hyperlocal Location Delivery Availability Card */}
            <div
              className={`rounded-xl border p-3.5 flex flex-wrap items-center justify-between gap-3 ${
                locationAvailable
                  ? 'border-emerald-200 bg-emerald-50/50'
                  : 'border-red-200 bg-red-50'
              }`}
            >
              <div className="flex items-start gap-2.5 text-xs">
                {locationAvailable ? (
                  <MapPin className="w-4 h-4 text-[#16A879] shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                )}
                <div>
                  {locationAvailable ? (
                    <>
                      <p className="font-bold text-[#202433]">
                        Available for delivery to {location.city} ({location.pincode})
                      </p>
                      <p className="text-slate-600 mt-0.5 flex items-center gap-1.5">
                        {location.estimatedDeliveryText ? (
                          <>
                            <Clock className="w-3.5 h-3.5 text-[#16A879]" />
                            <span>
                              Estimated delivery:{' '}
                              <strong className="text-[#128C63]">
                                {product.hyperlocalExpress && location.expressAvailable
                                  ? location.estimatedDeliveryText
                                  : location.estimatedDeliveryText}
                              </strong>
                              {location.hub ? ` · via ${location.hub}` : ''}
                            </span>
                          </>
                        ) : (
                          <span>Serviceable PIN code — delivery slot selected at checkout.</span>
                        )}
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="font-bold text-red-800">
                        Currently unavailable for PIN code {location.pincode}
                      </p>
                      <p className="text-red-700 mt-0.5">
                        Switch to a serviceable PIN code or saved address to order this product.
                      </p>
                    </>
                  )}
                </div>
              </div>
              <button
                type="button"
                onClick={onOpenLocation}
                className="rounded-lg bg-white border border-slate-200 px-3 py-1.5 text-xs font-bold text-[#2874F0] hover:bg-slate-50 cursor-pointer shrink-0"
              >
                Change
              </button>
            </div>

            {/* Unit / Variant Selection (kg, g, litre, ml, pieces) */}
            {variants && (
              <div>
                <p className="text-xs font-bold text-[#202433] mb-2">Select Pack / Unit ({activeUnit})</p>
                <div className="flex flex-wrap gap-2">
                  {variants.map((v, idx) => (
                    <button
                      key={v.label}
                      type="button"
                      onClick={() => setSelectedVariantIdx(idx)}
                      className={`rounded-xl border px-3.5 py-2 text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                        idx === selectedVariantIdx
                          ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                          : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <span>{v.label}</span>
                      <span className="ml-1.5 text-xs opacity-75 tabular-nums">₹{v.price}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity + Desktop Purchase Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <div className="flex items-center rounded-xl border border-slate-300 bg-white">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="min-w-[40px] min-h-[42px] flex items-center justify-center text-slate-600 hover:bg-slate-50 rounded-l-xl cursor-pointer"
                  aria-label="Decrease quantity"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-4 text-sm font-bold tabular-nums">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.min(Math.max(1, activeStock), q + 1))}
                  className="min-w-[40px] min-h-[42px] flex items-center justify-center text-slate-600 hover:bg-slate-50 rounded-r-xl cursor-pointer"
                  aria-label="Increase quantity"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              <div className="hidden lg:flex flex-1 items-center gap-3">
                <button
                  type="button"
                  disabled={!canPurchase}
                  onClick={() => onAddToCart(product, quantity, activeUnit, activePrice, activeMrp)}
                  className="flex-1 min-h-[46px] rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] disabled:bg-slate-300 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>{locationAvailable ? 'Add to Cart' : 'Unavailable in Area'}</span>
                </button>
                <button
                  type="button"
                  disabled={!canPurchase}
                  onClick={() => onBuyNow(product, quantity, activeUnit, activePrice, activeMrp)}
                  className="flex-1 min-h-[46px] rounded-xl bg-[#FF9F00] hover:bg-[#F09200] disabled:bg-slate-300 text-[#202433] font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>Buy Now</span>
                </button>
              </div>
            </div>

            {/* Delivery & Offer Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
              <div className="flex items-start gap-2.5 text-xs text-slate-600">
                <Truck className="w-4 h-4 text-[#2874F0] shrink-0 mt-0.5" />
                <span>
                  Free delivery on orders ₹{settings.freeDeliveryThreshold}+ (or free for Gold/Premium members).
                </span>
              </div>
              <div className="flex items-start gap-2.5 text-xs text-slate-600">
                <ShieldCheck className="w-4 h-4 text-[#16A879] shrink-0 mt-0.5" />
                <span>Verified catalog &amp; digital GST invoice on every order.</span>
              </div>
            </div>

            {coupons.length > 0 && (
              <div className="pt-2 border-t border-slate-100 space-y-1.5">
                <p className="text-xs font-bold text-[#202433] flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-[#FF7A30]" /> Available Offers
                </p>
                {coupons.slice(0, 2).map((c) => (
                  <p key={c.code} className="text-xs text-slate-600">
                    <span className="font-mono-num font-bold text-[#2874F0]">{c.code}</span> — {c.description}
                  </p>
                ))}
              </div>
            )}
          </div>

          {/* Description & Specifications */}
          <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
            <div>
              <h2 className="font-display text-base font-bold text-[#202433]">Product Description</h2>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed">{product.description}</p>
            </div>

            {product.specifications && (
              <div className="pt-3 border-t border-slate-100">
                <h3 className="font-display text-sm font-bold text-[#202433] mb-3">Specifications</h3>
                <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 overflow-hidden">
                  {Object.entries(product.specifications).map(([key, val]) => (
                    <div key={key} className="grid grid-cols-3 text-xs sm:text-sm">
                      <div className="col-span-1 bg-[#F7F8FC] px-3.5 py-2.5 font-medium text-slate-500">
                        {key}
                      </div>
                      <div className="col-span-2 bg-white px-3.5 py-2.5 font-medium text-[#202433]">
                        {val}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Interactive Frequently Bought Together */}
          {fbtProducts.length > 0 && (
            <div className="rounded-2xl bg-white border border-slate-200 p-5 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="font-display text-base font-bold text-[#202433]">Frequently Bought Together</h2>
                  <p className="text-xs text-slate-500">Select items to add together as a bundle</p>
                </div>
                {fbtBundleItems.length > 0 && (
                  <div className="text-right">
                    <p className="text-xs text-slate-500">
                      Bundle Total:{' '}
                      <strong className="text-sm text-[#202433] tabular-nums">
                        ₹{fbtTotalPrice.toLocaleString('en-IN')}
                      </strong>
                      {fbtTotalMrp > fbtTotalPrice && (
                        <span className="ml-1.5 text-[11px] text-[#16A879] font-bold">
                          Save ₹{(fbtTotalMrp - fbtTotalPrice).toLocaleString('en-IN')}
                        </span>
                      )}
                    </p>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Primary Product Toggle */}
                <label className="flex items-center gap-2.5 rounded-xl border border-[#2874F0]/40 bg-[#EAF2FF]/40 p-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={fbtSelectedIds.includes(product.id)}
                    onChange={(e) =>
                      setFbtSelectedIds((prev) =>
                        e.target.checked ? [...prev, product.id] : prev.filter((id) => id !== product.id)
                      )
                    }
                    className="w-4 h-4 accent-[#2874F0]"
                  />
                  <div className="w-12 h-12 rounded-lg bg-white p-1 shrink-0">
                    <SafeImage src={product.images[0]} alt={product.name} className="w-full h-full object-contain" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-bold text-[#2874F0]">This item</p>
                    <p className="text-xs font-semibold text-[#202433] truncate">{product.name}</p>
                    <p className="text-xs font-bold text-[#202433] tabular-nums">₹{activePrice}</p>
                  </div>
                </label>

                {fbtProducts.map((fp) => {
                  const checked = fbtSelectedIds.includes(fp.id);
                  return (
                    <div
                      key={fp.id}
                      className={`flex items-center gap-2.5 rounded-xl border p-2.5 transition-colors ${
                        checked ? 'border-[#2874F0] bg-[#EAF2FF]/20' : 'border-slate-200'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(e) =>
                          setFbtSelectedIds((prev) =>
                            e.target.checked ? [...prev, fp.id] : prev.filter((id) => id !== fp.id)
                          )
                        }
                        aria-label={`Include ${fp.name}`}
                        className="w-4 h-4 accent-[#2874F0] cursor-pointer"
                      />
                      <button
                        type="button"
                        onClick={() => onOpenProduct(fp)}
                        className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer"
                      >
                        <div className="w-12 h-12 rounded-lg bg-slate-50 p-1 shrink-0">
                          <SafeImage src={fp.images[0]} alt={fp.name} className="w-full h-full object-contain" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold text-[#202433] truncate">{fp.name}</p>
                          <p className="text-[11px] text-slate-500">{fp.unit}</p>
                          <p className="text-xs font-bold text-[#202433] tabular-nums">₹{fp.price}</p>
                        </div>
                      </button>
                    </div>
                  );
                })}
              </div>

              <button
                type="button"
                disabled={!locationAvailable || fbtBundleItems.length === 0}
                onClick={() => {
                  if (fbtSelectedIds.includes(product.id)) {
                    onAddToCart(product, 1, activeUnit, activePrice, activeMrp);
                  }
                  fbtProducts.forEach((fp) => {
                    if (fbtSelectedIds.includes(fp.id)) onAddToCart(fp, 1);
                  });
                  onToast(
                    'Bundle added to cart',
                    `${fbtBundleItems.length} selected item(s) added to your cart.`
                  );
                }}
                className="w-full sm:w-auto rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] disabled:bg-slate-300 px-5 py-2.5 text-xs font-bold text-white cursor-pointer"
              >
                Add Selected ({fbtBundleItems.length}) to Cart · ₹{fbtTotalPrice.toLocaleString('en-IN')}
              </button>
            </div>
          )}

          {/* Amazon-Style Ratings & Customer Reviews */}
          <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6 shadow-xs space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-lg font-bold text-[#202433]">
                Customer Ratings &amp; Reviews
              </h2>
              <span className="text-xs text-slate-500">
                Verified Purchase badges are granted only after confirmed delivery
              </span>
            </div>

            {/* Rating Distribution Summary */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 rounded-xl bg-[#F7F8FC] p-4 items-center">
              <div className="sm:col-span-4 text-center sm:text-left space-y-1">
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <span className="font-display text-3xl font-extrabold text-[#202433] tabular-nums">
                    {product.rating.toFixed(1)}
                  </span>
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`w-4 h-4 ${
                          s <= Math.round(product.rating)
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  {product.reviewCount + reviews.length} ratings · {reviews.length} written reviews
                </p>
              </div>

              <div className="sm:col-span-8 space-y-1.5">
                {ratingDistribution.map((row) => (
                  <button
                    key={row.star}
                    type="button"
                    onClick={() =>
                      setReviewFilter((prev) =>
                        prev === String(row.star) ? 'all' : (String(row.star) as typeof reviewFilter)
                      )
                    }
                    className="w-full flex items-center gap-2.5 text-xs hover:opacity-80 cursor-pointer"
                  >
                    <span className="w-8 text-right font-semibold text-[#202433] tabular-nums">
                      {row.star} ★
                    </span>
                    <div className="flex-1 h-2 rounded-full bg-slate-200 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#FF9F00]"
                        style={{ width: `${row.percent}%` }}
                      />
                    </div>
                    <span className="w-10 text-right text-slate-500 tabular-nums">{row.percent}%</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Customer Uploaded Photos Strip */}
            {allCustomerPhotos.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-bold text-[#202433]">
                  Customer Photos ({allCustomerPhotos.length})
                </p>
                <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
                  {allCustomerPhotos.map((photo, idx) => (
                    <button
                      key={`${photo}_${idx}`}
                      type="button"
                      onClick={() => setLightboxPhoto(photo)}
                      className="w-16 h-16 rounded-xl border border-slate-200 overflow-hidden bg-slate-50 shrink-0 hover:ring-2 hover:ring-[#2874F0] cursor-pointer"
                    >
                      <SafeImage src={photo} alt={`Customer photo ${idx + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Write a Review Form (with genuine Verified Purchase & Duplicate Prevention) */}
            {eligibility && eligibility.alreadyReviewed ? (
              <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-4 flex items-center gap-2.5 text-xs text-emerald-900">
                <CheckCircle2 className="w-4 h-4 text-[#16A879] shrink-0" />
                <span>
                  {eligibility.reason || 'You have already submitted a review for this purchase.'}
                </span>
              </div>
            ) : (
              <form onSubmit={handleSubmitReview} className="rounded-xl bg-[#F7F8FC] p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-bold text-[#202433]">Write a Review</span>
                    {user && (
                      <span
                        className={`ml-2 inline-block rounded-md px-2 py-0.5 text-[10px] font-bold ${
                          eligibility?.hasVerifiedPurchase
                            ? 'bg-emerald-100 text-[#128C63]'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {eligibility?.hasVerifiedPurchase
                          ? 'Eligible for Verified Purchase Badge'
                          : 'Unverified Reviewer (No Delivered Order Found)'}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewRating(star)}
                        className="p-0.5 cursor-pointer"
                        aria-label={`Rate ${star} stars`}
                      >
                        <Star
                          className={`w-4 h-4 ${
                            star <= reviewRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <input
                  type="text"
                  maxLength={120}
                  value={reviewTitle}
                  onChange={(e) => setReviewTitle(e.target.value)}
                  placeholder="Review headline (optional)"
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs sm:text-sm focus:border-[#2874F0] focus:outline-none"
                />
                <textarea
                  rows={2}
                  maxLength={1000}
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  placeholder={
                    user
                      ? 'Share product quality, freshness, packaging, or delivery experience...'
                      : 'Sign in to Demo Account to submit a review'
                  }
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs sm:text-sm focus:border-[#2874F0] focus:outline-none"
                />

                {/* Customer Photo Upload */}
                <div className="flex flex-wrap items-center gap-2.5">
                  <label className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-[#202433] hover:bg-slate-50 cursor-pointer">
                    <Camera className="w-3.5 h-3.5 text-[#2874F0]" />
                    <span>Add Photos ({reviewPhotos.length}/3)</span>
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      disabled={reviewPhotos.length >= 3}
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </label>
                  {reviewPhotos.map((photo, idx) => (
                    <div key={idx} className="relative w-11 h-11 rounded-lg border border-slate-200 overflow-hidden">
                      <img src={photo} alt={`Upload ${idx + 1}`} className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setReviewPhotos((prev) => prev.filter((_, i) => i !== idx))}
                        className="absolute top-0 right-0 bg-black/70 text-white w-4 h-4 flex items-center justify-center text-[10px]"
                        aria-label="Remove uploaded photo"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>

                <button
                  type="submit"
                  disabled={submittingReview || (Boolean(user) && reviewComment.trim().length < 3)}
                  className="rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] disabled:opacity-50 px-4 py-2 text-xs font-semibold text-white cursor-pointer"
                >
                  {user ? (submittingReview ? 'Submitting...' : 'Post Review') : 'Sign In to Review'}
                </button>
              </form>
            )}

            {/* Review Sort & Filter Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-100">
              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    ['all', 'All'],
                    ['verified', 'Verified Purchase'],
                    ['photos', 'With Photos'],
                  ] as const
                ).map(([key, label]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setReviewFilter(key)}
                    className={`rounded-lg px-2.5 py-1 text-xs font-semibold cursor-pointer ${
                      reviewFilter === key
                        ? 'bg-[#2874F0] text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {label}
                  </button>
                ))}
                {['5', '4', '3', '2', '1'].includes(reviewFilter) && (
                  <button
                    type="button"
                    onClick={() => setReviewFilter('all')}
                    className="rounded-lg bg-[#FF9F00]/20 px-2.5 py-1 text-xs font-bold text-[#202433] cursor-pointer"
                  >
                    {reviewFilter}★ Only ×
                  </button>
                )}
              </div>

              <select
                aria-label="Sort reviews"
                value={reviewSort}
                onChange={(e) => setReviewSort(e.target.value as typeof reviewSort)}
                className="rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-semibold text-[#202433] cursor-pointer"
              >
                <option value="helpful">Sort: Most Helpful</option>
                <option value="newest">Sort: Newest First</option>
                <option value="highest">Sort: Highest Rating</option>
                <option value="lowest">Sort: Lowest Rating</option>
              </select>
            </div>

            {displayedReviews.length === 0 ? (
              <p className="text-xs text-slate-500">
                No customer reviews match the selected filter yet.
              </p>
            ) : (
              <div className="divide-y divide-slate-100">
                {displayedReviews.map((r) => {
                  const hasVotedHelpful = Boolean(user && (r.helpfulUserIds || []).includes(user.uid));
                  const hasReported = Boolean(user && (r.reportedByUserIds || []).includes(user.uid));
                  return (
                    <div key={r.id} className="py-3.5 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-bold text-[#202433]">{r.authorName}</span>
                          {r.verifiedPurchase && (
                            <span className="inline-flex items-center gap-1 rounded-md bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] font-bold text-[#128C63]">
                              <CheckCircle2 className="w-3 h-3" /> Verified Purchase
                            </span>
                          )}
                        </div>
                        <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-amber-600">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          {r.rating}
                        </span>
                      </div>

                      {r.title && <p className="text-xs sm:text-sm font-semibold text-slate-900">{r.title}</p>}
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{r.comment}</p>

                      {r.photos && r.photos.length > 0 && (
                        <div className="flex flex-wrap gap-2 pt-1">
                          {r.photos.map((photo, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => setLightboxPhoto(photo)}
                              className="w-14 h-14 rounded-lg border border-slate-200 overflow-hidden bg-slate-50 cursor-pointer"
                            >
                              <SafeImage src={photo} alt={`Review attachment ${idx + 1}`} className="w-full h-full object-cover" />
                            </button>
                          ))}
                        </div>
                      )}

                      <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-slate-500">
                        <button
                          type="button"
                          onClick={() => handleHelpfulVote(r.id)}
                          className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 font-semibold cursor-pointer ${
                            hasVotedHelpful
                              ? 'border-[#2874F0] bg-[#EAF2FF] text-[#2874F0]'
                              : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <ThumbsUp className="w-3 h-3" />
                          <span>Helpful ({r.helpfulCount || 0})</span>
                        </button>

                        {hasReported ? (
                          <span className="text-amber-700 font-semibold">Reported</span>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              setReportingReviewId((curr) => (curr === r.id ? null : r.id))
                            }
                            className="inline-flex items-center gap-1 text-slate-500 hover:text-red-600 cursor-pointer"
                          >
                            <Flag className="w-3 h-3" />
                            <span>Report</span>
                          </button>
                        )}
                      </div>

                      {reportingReviewId === r.id && !hasReported && (
                        <div className="flex flex-wrap items-center gap-1.5 pt-1">
                          <span className="text-[11px] font-semibold text-slate-600">Reason:</span>
                          {['Spam or promotional', 'Inappropriate content', 'Misleading info'].map(
                            (reason) => (
                              <button
                                key={reason}
                                type="button"
                                onClick={() => handleReportReview(r.id, reason)}
                                className="rounded-lg border border-red-200 bg-red-50 px-2.5 py-1 text-[11px] font-semibold text-red-700 hover:bg-red-100 cursor-pointer"
                              >
                                {reason}
                              </button>
                            )
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Similar Products */}
      {similarProducts.length > 0 && (
        <section className="space-y-3 pt-2">
          <h2 className="font-display text-lg font-bold text-[#202433]">Similar &amp; Related Products</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {similarProducts.map((rp) => (
              <ProductCard
                key={rp.id}
                product={rp}
                isWishlisted={wishlistIds.includes(rp.id)}
                isCompared={compareIds.includes(rp.id)}
                onOpenProduct={onOpenProduct}
                onAddToCart={(p) => onAddToCart(p, 1)}
                onToggleWishlist={onToggleWishlist}
                onToggleCompare={onToggleCompare}
              />
            ))}
          </div>
        </section>
      )}

      {/* Customers Also Bought (derived from real order item co-occurrence) */}
      {alsoBoughtProducts.length > 0 && (
        <section className="space-y-3 pt-2">
          <h2 className="font-display text-lg font-bold text-[#202433]">Customers Also Bought</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {alsoBoughtProducts.map((ap) => (
              <ProductCard
                key={ap.id}
                product={ap}
                isWishlisted={wishlistIds.includes(ap.id)}
                isCompared={compareIds.includes(ap.id)}
                onOpenProduct={onOpenProduct}
                onAddToCart={(p) => onAddToCart(p, 1)}
                onToggleWishlist={onToggleWishlist}
                onToggleCompare={onToggleCompare}
              />
            ))}
          </div>
        </section>
      )}

      {/* Recently Viewed on PDP */}
      {otherRecentlyViewed.length > 0 && (
        <section className="space-y-3 pt-2">
          <h2 className="font-display text-lg font-bold text-[#202433]">Recently Viewed</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {otherRecentlyViewed.map((rv) => (
              <ProductCard
                key={rv.id}
                product={rv}
                isWishlisted={wishlistIds.includes(rv.id)}
                isCompared={compareIds.includes(rv.id)}
                onOpenProduct={onOpenProduct}
                onAddToCart={(p) => onAddToCart(p, 1)}
                onToggleWishlist={onToggleWishlist}
                onToggleCompare={onToggleCompare}
              />
            ))}
          </div>
        </section>
      )}

      {/* Customer Photo Lightbox Modal */}
      {lightboxPhoto && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={() => setLightboxPhoto(null)}
        >
          <div className="relative max-w-lg w-full rounded-2xl bg-white p-3" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              onClick={() => setLightboxPhoto(null)}
              aria-label="Close photo preview"
              className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/70 text-white flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <img src={lightboxPhoto} alt="Customer review photo" className="w-full max-h-[70vh] object-contain rounded-xl" />
          </div>
        </div>
      )}

      {/* Mobile Fixed Bottom Purchase Bar */}
      <div className="lg:hidden fixed bottom-15 left-0 right-0 z-30 bg-white border-t border-slate-200 px-3.5 py-2.5 flex items-center gap-2.5 shadow-[0_-4px_12px_rgba(0,0,0,0.06)]">
        <button
          type="button"
          disabled={!canPurchase}
          onClick={() => onAddToCart(product, quantity, activeUnit, activePrice, activeMrp)}
          className="flex-1 min-h-[44px] rounded-xl bg-[#2874F0] disabled:bg-slate-300 text-white font-semibold text-sm flex items-center justify-center gap-1.5"
        >
          <ShoppingCart className="w-4 h-4" />
          <span>{locationAvailable ? 'Add to Cart' : 'Unavailable'}</span>
        </button>
        <button
          type="button"
          disabled={!canPurchase}
          onClick={() => onBuyNow(product, quantity, activeUnit, activePrice, activeMrp)}
          className="flex-1 min-h-[44px] rounded-xl bg-[#FF9F00] disabled:bg-slate-300 text-[#202433] font-bold text-sm flex items-center justify-center gap-1.5"
        >
          <Zap className="w-4 h-4" />
          <span>Buy Now</span>
        </button>
      </div>
    </div>
  );
};
