import React, { useRef, useState } from 'react';
import {
  Award,
  Bell,
  CheckCircle2,
  ChevronRight,
  Crown,
  Database,
  Download,
  FileText,
  HeadphonesIcon,
  Heart,
  LogOut,
  MapPin,
  MessageCircle,
  Package,
  Plus,
  RefreshCw,
  RotateCcw,
  Settings as SettingsIcon,
  ShieldCheck,
  Trash2,
  Upload,
  User as UserIcon,
  Wallet,
} from 'lucide-react';
import {
  AccountSection,
  Address,
  Coupon,
  CustomerUser,
  Invoice,
  NotificationItem,
  Order,
  OrderItem,
  Product,
  RewardTransaction,
  StoreSettings,
  SupportTicket,
  UserPrivateInfo,
  UserProfile,
} from '../types/store';
import { activeServices, customerService } from '../services/serviceContainer';
import {
  exportDatabaseBackupJson,
  getOfflineDbStats,
  importDatabaseBackupJson,
} from '../db/offlineDb';
import {
  getSyncStatusSnapshot,
  subscribeSyncStatus,
  syncPendingChanges,
} from '../db/syncManager';
import { notifyLocalStoreListeners } from '../services/local/LocalDemoService';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { OrderTrackingTimeline } from './OrderTrackingTimeline';
import { ResponsiveProductGrid } from './ResponsiveProductGrid';
import { PWAInstallButton } from './PWAInstallButton';
import { WhatsAppOtpVerification } from './WhatsAppOtpVerification';

interface ResponsiveAccountDashboardProps {
  user: CustomerUser | null;
  activeSection: AccountSection;
  profile: UserProfile | null;
  privateInfo: UserPrivateInfo | null;
  addresses: Address[];
  orders: Order[];
  invoices: Invoice[];
  wishlistProducts: Product[];
  allProducts: Product[];
  coupons: Coupon[];
  notifications: NotificationItem[];
  rewardTransactions: RewardTransaction[];
  tickets: SupportTicket[];
  settings: StoreSettings;
  onSelectSection: (section: AccountSection) => void;
  onSignIn: () => void;
  onSignOut: () => void;
  onOpenProduct: (p: Product) => void;
  onAddToCart: (p: Product) => void;
  onToggleWishlist: (p: Product) => void;
  onReorder: (items: OrderItem[]) => void;
  onToast: (title: string, description?: string, variant?: 'success' | 'info' | 'warning' | 'error') => void;
}

const FAQ_ITEMS = [
  {
    q: 'How is this Customer Shopping App currently running?',
    a: 'It runs completely offline-ready in Local Demo Mode using IndexedDB as the primary local database (with JSON backup/restore and conflict-safe sync), alongside a modular service layer ready for future Backend API integration.',
  },
  {
    q: 'When can I cancel an order?',
    a: 'Orders can be cancelled directly from My Orders while their status is "Order Placed" or "Accepted". Once packed or out for delivery, contact support for assistance.',
  },
  {
    q: 'How are Reward Points calculated?',
    a: 'Reward Points are credited upon order delivery based on the configured earn rate and your membership tier multiplier, and can be redeemed during checkout.',
  },
  {
    q: 'Are GST digital invoices provided?',
    a: 'Yes. Printable GST invoices and itemized order receipts are available anytime under My Orders and GST Invoices.',
  },
];

export const ResponsiveAccountDashboard: React.FC<ResponsiveAccountDashboardProps> = ({
  user,
  activeSection,
  profile,
  privateInfo,
  addresses,
  orders,
  invoices,
  wishlistProducts,
  allProducts,
  coupons,
  notifications,
  rewardTransactions,
  tickets,
  settings,
  onSelectSection,
  onSignIn,
  onSignOut,
  onOpenProduct,
  onAddToCart,
  onToggleWishlist,
  onReorder,
  onToast,
}) => {
  const [mobileMenuMode, setMobileMenuMode] = useState(false);

  // Profile form state
  const [profileName, setProfileName] = useState(profile?.displayName || user?.displayName || '');
  const [profilePhone, setProfilePhone] = useState(privateInfo?.phone || '');
  const [profileCity, setProfileCity] = useState(privateInfo?.preferredCity || 'Mumbai, MH');
  const [profilePin, setProfilePin] = useState(privateInfo?.preferredPincode || '400001');
  const [profileGstin, setProfileGstin] = useState(privateInfo?.gstin || '');
  const [savingProfile, setSavingProfile] = useState(false);

  React.useEffect(() => {
    setProfileName(profile?.displayName || user?.displayName || '');
    setProfilePhone(privateInfo?.phone || '');
    setProfileCity(privateInfo?.preferredCity || 'Mumbai, MH');
    setProfilePin(privateInfo?.preferredPincode || '400001');
    setProfileGstin(privateInfo?.gstin || '');
  }, [profile?.displayName, user?.displayName, privateInfo]);

  // Address form state
  const [showAddAddr, setShowAddAddr] = useState(false);
  const [newAddr, setNewAddr] = useState({
    label: 'Home' as Address['label'],
    fullName: '',
    phone: '',
    line1: '',
    line2: '',
    city: 'Mumbai',
    state: 'Maharashtra',
    pincode: '400001',
  });

  // Support ticket state
  const [ticketCat, setTicketCat] = useState<SupportTicket['category']>('Order Issue');
  const [ticketOrderId, setTicketOrderId] = useState('');
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [submittingTicket, setSubmittingTicket] = useState(false);

  // Offline DB & JSON Backup/Restore state
  const isOnline = useOnlineStatus();
  const [restoreMode, setRestoreMode] = useState<'merge' | 'replace'>('merge');
  const [syncSnapshot, setSyncSnapshot] = useState(() => getSyncStatusSnapshot());
  const backupFileInputRef = useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    setSyncSnapshot(getSyncStatusSnapshot());
    return subscribeSyncStatus(() => {
      setSyncSnapshot(getSyncStatusSnapshot());
    });
  }, []);

  const navItems: { id: AccountSection; label: string; icon: React.FC<{ className?: string }>; badge?: number }[] = [
    { id: 'profile', label: 'My Profile', icon: UserIcon },
    { id: 'orders', label: 'My Orders', icon: Package, badge: orders.length },
    { id: 'wishlist', label: 'My Wishlist', icon: Heart, badge: wishlistProducts.length },
    { id: 'addresses', label: 'Saved Addresses', icon: MapPin },
    { id: 'rewards', label: 'Rewards & Wallet', icon: Wallet },
    { id: 'membership', label: 'Membership', icon: Crown },
    { id: 'invoices', label: 'GST Invoices', icon: FileText },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: notifications.filter((n) => !n.read).length },
    { id: 'support', label: 'Support & FAQ', icon: HeadphonesIcon },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  // Guest Support/FAQ/Membership view allowed without sign-in; other personal sections prompt Demo Sign-In
  if (!user && activeSection !== 'support' && activeSection !== 'membership' && activeSection !== 'settings') {
    return (
      <div className="rounded-2xl bg-white border border-slate-200 p-8 sm:p-12 text-center max-w-lg mx-auto space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-[#EAF2FF] text-[#2874F0] flex items-center justify-center mx-auto">
          <UserIcon className="w-7 h-7" />
        </div>
        <h2 className="font-display text-xl font-bold text-[#202433]">Sign In to Business Manager 360</h2>
        <p className="text-sm text-slate-500">
          Sign in to the local Demo Customer Account to access orders, GST invoices, reward wallet, saved addresses, and wishlist.
        </p>
        <div className="flex flex-wrap justify-center gap-3 pt-1">
          <button
            type="button"
            onClick={onSignIn}
            className="rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] px-6 py-3 text-sm font-semibold text-white shadow-sm cursor-pointer"
          >
            Sign In to Demo Account
          </button>
          <button
            type="button"
            onClick={() => onSelectSection('support')}
            className="rounded-xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Help &amp; FAQs
          </button>
        </div>
      </div>
    );
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSavingProfile(true);
    try {
      await customerService.updateCustomerProfile(user.uid, profileName.trim() || 'Customer', {
        email: user.email || '',
        phone: profilePhone.trim(),
        preferredCity: profileCity.trim(),
        preferredPincode: profilePin.trim(),
        gstin: profileGstin.trim().toUpperCase(),
      });
      onToast('Profile updated', 'Your customer details have been saved locally.');
    } catch {
      onToast('Update failed', 'Could not save profile changes.', 'error');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleAddAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    await customerService.saveAddress(user.uid, {
      id: `addr_${Date.now()}`,
      userId: user.uid,
      ...newAddr,
      isDefault: addresses.length === 0,
    });
    setShowAddAddr(false);
    setNewAddr({
      label: 'Home',
      fullName: '',
      phone: '',
      line1: '',
      line2: '',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
    });
    onToast('Address added', 'Saved to your local address book.');
  };

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onSignIn();
      return;
    }
    setSubmittingTicket(true);
    try {
      await customerService.createSupportTicket({
        userId: user.uid,
        orderId: ticketOrderId || undefined,
        category: ticketCat,
        subject: ticketSubject.trim(),
        message: ticketMessage.trim(),
      });
      setTicketSubject('');
      setTicketMessage('');
      onToast('Support ticket submitted', 'Saved in your local support history.');
    } catch {
      onToast('Submission failed', 'Please fill subject and message details.', 'error');
    } finally {
      setSubmittingTicket(false);
    }
  };

  return (
    <div className="pb-24 lg:pb-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Desktop Sidebar Navigation */}
        <aside className="hidden lg:block lg:col-span-3 sticky top-28">
          <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-xs">
            {user && (
              <div className="p-4 bg-gradient-to-r from-[#2874F0] to-[#1A56C4] text-white">
                <p className="text-xs text-white/80">Signed in as</p>
                <p className="font-display text-base font-bold truncate">
                  {profile?.displayName || user.displayName || 'Customer'}
                </p>
                <p className="text-xs text-[#FFC83D] font-semibold mt-0.5">
                  {profile?.membershipTier || 'Basic'} Member · {profile?.rewardPoints ?? 0} pts
                </p>
              </div>
            )}
            <div className="p-2 space-y-0.5">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectSection(item.id)}
                    className={`w-full flex items-center justify-between rounded-xl px-3 py-2.5 text-sm font-medium transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#EAF2FF] text-[#2874F0] font-bold'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </span>
                    {item.badge && item.badge > 0 ? (
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-[#202433] tabular-nums">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                );
              })}

              {user && (
                <button
                  type="button"
                  onClick={onSignOut}
                  className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50 mt-2 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              )}
            </div>
          </div>
        </aside>

        {/* Mobile Account Menu Toggle & Header */}
        <div className="lg:hidden space-y-3">
          {mobileMenuMode ? (
            <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-xs">
              {user && (
                <div className="p-4 bg-[#2874F0] text-white flex items-center justify-between">
                  <div>
                    <p className="font-display text-base font-bold">
                      {profile?.displayName || user.displayName}
                    </p>
                    <p className="text-xs text-[#FFC83D]">
                      {profile?.membershipTier || 'Basic'} · {profile?.rewardPoints ?? 0} Reward Pts
                    </p>
                  </div>
                </div>
              )}
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onSelectSection(item.id);
                      setMobileMenuMode(false);
                    }}
                    className="w-full min-h-[54px] px-4 flex items-center justify-between text-left hover:bg-slate-50"
                  >
                    <span className="flex items-center gap-3 text-sm font-semibold text-[#202433]">
                      <Icon className="w-5 h-5 text-[#2874F0]" />
                      <span>{item.label}</span>
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                );
              })}
              {user && (
                <button
                  type="button"
                  onClick={onSignOut}
                  className="w-full min-h-[54px] px-4 flex items-center gap-3 text-sm font-semibold text-red-600"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </button>
              )}
            </div>
          ) : (
            <div className="flex items-center justify-between rounded-xl bg-white border border-slate-200 px-3.5 py-2.5">
              <span className="font-display text-sm font-bold text-[#202433]">
                {navItems.find((n) => n.id === activeSection)?.label || 'Account'}
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuMode(true)}
                className="rounded-lg bg-[#EAF2FF] px-3 py-1.5 text-xs font-bold text-[#2874F0]"
              >
                All Account Menus
              </button>
            </div>
          )}
        </div>

        {/* Main Content Panel */}
        <div className={`lg:col-span-9 space-y-6 ${mobileMenuMode ? 'hidden lg:block' : ''}`}>
          {/* PROFILE */}
          {activeSection === 'profile' && user && (
            <div className="space-y-5">
              <WhatsAppOtpVerification
                initialPhone={privateInfo?.phone || user.phone}
                verifiedPhone={privateInfo?.phone}
                isPhoneVerified={Boolean(
                  privateInfo?.phoneVerified && privateInfo?.phoneVerificationMethod === 'WHATSAPP_OTP'
                )}
                verifiedAt={privateInfo?.phoneVerifiedAt}
                onVerified={async (receipt) => {
                  await customerService.markPhoneVerified(user.uid, receipt);
                }}
                onToast={onToast}
              />

              <section className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6 shadow-xs space-y-5">
                <h2 className="font-display text-lg font-bold text-[#202433]">My Profile &amp; Billing Details</h2>
                <form onSubmit={handleSaveProfile} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Full Name</label>
                    <input
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm focus:border-[#2874F0] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Account Email</label>
                    <input
                      disabled
                      value={user.email || ''}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-500"
                    />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-semibold text-slate-600">Mobile Number</label>
                      {privateInfo?.phoneVerified ? (
                        <span className="text-[11px] font-bold text-[#128C63]">WhatsApp Verified</span>
                      ) : (
                        <span className="text-[11px] font-bold text-amber-700">Not Verified</span>
                      )}
                    </div>
                    <input
                      value={profilePhone}
                      onChange={(e) => setProfilePhone(e.target.value)}
                      placeholder="+91 98XXXXXXXX"
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm font-mono-num focus:border-[#2874F0] focus:outline-none"
                    />
                    <p className="text-[11px] text-slate-400 mt-1">
                      Changing your mobile number clears verification until confirmed via WhatsApp OTP above.
                    </p>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Business GSTIN (Optional)</label>
                    <input
                      value={profileGstin}
                      onChange={(e) => setProfileGstin(e.target.value.toUpperCase())}
                      placeholder="27ABCDE1234F1Z5"
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm font-mono-num uppercase focus:border-[#2874F0] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Preferred City</label>
                    <input
                      value={profileCity}
                      onChange={(e) => setProfileCity(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm focus:border-[#2874F0] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Default Pincode</label>
                    <input
                      maxLength={6}
                      value={profilePin}
                      onChange={(e) => setProfilePin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm font-mono-num focus:border-[#2874F0] focus:outline-none"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <button
                      type="submit"
                      disabled={savingProfile}
                      className="rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] px-6 py-2.5 text-sm font-semibold text-white cursor-pointer"
                    >
                      {savingProfile ? 'Saving...' : 'Save Profile'}
                    </button>
                  </div>
                </form>
              </section>
            </div>
          )}

          {/* ORDERS */}
          {activeSection === 'orders' && (
            <section className="space-y-4">
              <h2 className="font-display text-lg font-bold text-[#202433]">
                My Orders ({orders.length})
              </h2>
              {orders.length === 0 ? (
                <div className="rounded-2xl bg-white border border-slate-200 p-8 text-center text-sm text-slate-500">
                  You have not placed any orders yet. Your live order tracking timeline will appear here.
                </div>
              ) : (
                orders.map((ord) => (
                  <OrderTrackingTimeline
                    key={ord.id}
                    order={ord}
                    invoice={invoices.find((inv) => inv.orderId === ord.id)}
                    onReorder={onReorder}
                    onToast={onToast}
                  />
                ))
              )}
            </section>
          )}

          {/* WISHLIST */}
          {activeSection === 'wishlist' && (
            <section className="space-y-4">
              <h2 className="font-display text-lg font-bold text-[#202433]">
                My Wishlist ({wishlistProducts.length})
              </h2>
              <ResponsiveProductGrid
                products={wishlistProducts}
                wishlistIds={wishlistProducts.map((p) => p.id)}
                emptyTitle="Your wishlist is empty"
                emptyDescription="Tap the heart icon on any product to save it here for quick access."
                onOpenProduct={onOpenProduct}
                onAddToCart={onAddToCart}
                onToggleWishlist={onToggleWishlist}
              />
            </section>
          )}

          {/* ADDRESSES */}
          {activeSection === 'addresses' && user && (
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold text-[#202433]">Saved Addresses</h2>
                <button
                  type="button"
                  onClick={() => setShowAddAddr((v) => !v)}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-[#2874F0] px-4 py-2 text-xs font-semibold text-white cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{showAddAddr ? 'Cancel' : 'Add Address'}</span>
                </button>
              </div>

              {showAddAddr && (
                <form
                  onSubmit={handleAddAddress}
                  className="rounded-2xl bg-white border border-slate-200 p-5 grid grid-cols-1 sm:grid-cols-2 gap-3"
                >
                  <input
                    required
                    value={newAddr.fullName}
                    onChange={(e) => setNewAddr((a) => ({ ...a, fullName: e.target.value }))}
                    placeholder="Full Name *"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  />
                  <input
                    required
                    value={newAddr.phone}
                    onChange={(e) => setNewAddr((a) => ({ ...a, phone: e.target.value }))}
                    placeholder="Phone *"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-sm font-mono-num"
                  />
                  <input
                    required
                    value={newAddr.line1}
                    onChange={(e) => setNewAddr((a) => ({ ...a, line1: e.target.value }))}
                    placeholder="Street / Flat *"
                    className="sm:col-span-2 rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  />
                  <input
                    required
                    value={newAddr.city}
                    onChange={(e) => setNewAddr((a) => ({ ...a, city: e.target.value }))}
                    placeholder="City *"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  />
                  <input
                    required
                    maxLength={6}
                    value={newAddr.pincode}
                    onChange={(e) =>
                      setNewAddr((a) => ({ ...a, pincode: e.target.value.replace(/\D/g, '').slice(0, 6) }))
                    }
                    placeholder="Pincode *"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-sm font-mono-num"
                  />
                  <button
                    type="submit"
                    className="sm:col-span-2 rounded-xl bg-[#16A879] py-2.5 text-sm font-semibold text-white cursor-pointer"
                  >
                    Save Address
                  </button>
                </form>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {addresses.map((addr) => (
                  <div key={addr.id} className="rounded-2xl bg-white border border-slate-200 p-4 flex justify-between gap-3">
                    <div>
                      <span className="text-xs font-bold text-[#2874F0]">{addr.label}</span>
                      <p className="text-sm font-bold text-[#202433] mt-1">{addr.fullName}</p>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {addr.line1}, {addr.city}, {addr.state} - {addr.pincode}
                      </p>
                      <p className="text-xs text-slate-500 mt-1 font-mono-num">{addr.phone}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => customerService.deleteAddress(user.uid, addr.id)}
                      className="p-2 h-fit rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                      aria-label="Delete address"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* REWARDS & WALLET */}
          {activeSection === 'rewards' && (
            <section className="space-y-5">
              <div className="rounded-2xl bg-gradient-to-r from-[#7B4DDB] to-[#2874F0] text-white p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold text-white/80">Digital Reward Wallet</p>
                  <p className="font-display text-3xl font-extrabold tabular-nums mt-1">
                    {profile?.rewardPoints ?? 0} Points
                  </p>
                  <p className="text-xs text-white/90 mt-1">
                    1 Point = ₹{settings.pointValueInr} · Redeem up to {settings.maxRedeemPercent}% at checkout
                  </p>
                </div>
                <Award className="w-12 h-12 text-[#FFC83D]" />
              </div>

              <div className="rounded-2xl bg-white border border-slate-200 p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-[#202433]">Coupon Wallet</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {coupons.map((c) => (
                    <div key={c.code} className="rounded-xl border border-dashed border-[#2874F0]/50 bg-[#EAF2FF]/40 p-3.5">
                      <span className="font-mono-num text-sm font-extrabold text-[#2874F0]">{c.code}</span>
                      <p className="text-xs font-bold text-[#202433] mt-1">{c.title}</p>
                      <p className="text-[11px] text-slate-600 mt-0.5">{c.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl bg-white border border-slate-200 p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-[#202433]">Reward Transaction History</h3>
                {rewardTransactions.length === 0 ? (
                  <p className="text-xs text-slate-500">
                    Complete your first delivered order to earn verified Reward Points.
                  </p>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {rewardTransactions.map((tx) => (
                      <div key={tx.id} className="py-2.5 flex items-center justify-between text-xs sm:text-sm">
                        <div>
                          <p className="font-semibold text-[#202433]">{tx.description}</p>
                          <p className="text-[11px] text-slate-500 capitalize">{tx.type}</p>
                        </div>
                        <span
                          className={`font-bold tabular-nums ${
                            tx.type === 'redeemed' || tx.type === 'expired' ? 'text-red-600' : 'text-[#16A879]'
                          }`}
                        >
                          {tx.type === 'redeemed' ? '-' : '+'}
                          {tx.points} pts
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </section>
          )}

          {/* MEMBERSHIP */}
          {activeSection === 'membership' && (
            <section className="space-y-4">
              <div>
                <h2 className="font-display text-lg font-bold text-[#202433]">Business Manager 360 Membership</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Current Tier: <strong className="text-[#2874F0]">{profile?.membershipTier || 'Basic'}</strong> ·
                  Upgrades require verified payment confirmation via Admin Billing.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {(settings.membershipPlans || []).map((plan) => {
                  const isCurrent = (profile?.membershipTier || 'Basic') === plan.tier;
                  return (
                    <div
                      key={plan.tier}
                      className={`rounded-2xl border p-5 bg-white space-y-3 ${
                        isCurrent ? 'border-[#2874F0] ring-2 ring-[#2874F0]/15' : 'border-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-display text-base font-bold text-[#202433]">{plan.tier}</span>
                        <span className="text-sm font-extrabold text-[#2874F0] tabular-nums">
                          {plan.monthlyPrice === 0 ? 'Free' : `₹${plan.monthlyPrice}/mo`}
                        </span>
                      </div>
                      <ul className="space-y-1.5 text-xs text-slate-600">
                        {plan.perks.map((perk) => (
                          <li key={perk} className="flex items-start gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#16A879] shrink-0 mt-0.5" />
                            <span>{perk}</span>
                          </li>
                        ))}
                      </ul>
                      <button
                        type="button"
                        disabled={isCurrent}
                        onClick={async () => {
                          if (!user) {
                            onSignIn();
                            return;
                          }
                          await customerService.updateMembershipTier(user.uid, plan.tier);
                          onToast(
                            `${plan.tier} Tier Activated (Demo)`,
                            `Your local demo account now uses ${plan.tier} tier benefits and multipliers.`,
                            'success'
                          );
                        }}
                        className={`w-full rounded-xl py-2 text-xs font-bold cursor-pointer ${
                          isCurrent
                            ? 'bg-emerald-50 text-[#16A879] cursor-default'
                            : 'bg-[#2874F0] text-white hover:bg-[#1A56C4]'
                        }`}
                      >
                        {isCurrent ? 'Active Plan' : `Switch to ${plan.tier} (Demo)`}
                      </button>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {/* INVOICES */}
          {activeSection === 'invoices' && (
            <section className="space-y-4">
              <h2 className="font-display text-lg font-bold text-[#202433]">GST Digital Invoices</h2>
              {invoices.length === 0 ? (
                <div className="rounded-2xl bg-white border border-slate-200 p-8 text-center text-sm text-slate-500">
                  Authorized GST invoices appear here once your orders are accepted by Business Manager 360 Admin.
                </div>
              ) : (
                <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100">
                  {invoices.map((inv) => (
                    <div key={inv.id} className="p-4 flex items-center justify-between gap-3">
                      <div>
                        <p className="font-mono-num text-sm font-bold text-[#202433]">{inv.invoiceNumber}</p>
                        <p className="text-xs text-slate-500">
                          {inv.customerName} · GST ₹{inv.gstAmount.toFixed(2)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-extrabold text-[#202433] tabular-nums">
                          ₹{inv.grandTotal.toLocaleString('en-IN')}
                        </p>
                        <button
                          type="button"
                          onClick={() => onSelectSection('orders')}
                          className="text-xs font-semibold text-[#2874F0] hover:underline cursor-pointer"
                        >
                          Open in Orders
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}

          {/* NOTIFICATIONS */}
          {activeSection === 'notifications' && user && (
            <section className="space-y-4">
              <h2 className="font-display text-lg font-bold text-[#202433]">Notification Center</h2>
              {notifications.length === 0 ? (
                <div className="rounded-2xl bg-white border border-slate-200 p-8 text-center text-sm text-slate-500">
                  You are all caught up. Delivery alerts and offer updates appear here.
                </div>
              ) : (
                <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => !n.read && customerService.markNotificationRead(user.uid, n.id)}
                      className={`p-4 flex items-start justify-between gap-3 cursor-pointer ${
                        n.read ? 'bg-white' : 'bg-[#EAF2FF]/40'
                      }`}
                    >
                      <div>
                        <p className="text-sm font-bold text-[#202433]">{n.title}</p>
                        <p className="text-xs text-slate-600 mt-0.5">{n.message}</p>
                      </div>
                      {!n.read && (
                        <span className="text-[11px] font-bold text-[#2874F0] shrink-0">Mark Read</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}

          {/* SUPPORT & FAQ */}
          {activeSection === 'support' && (
            <section className="space-y-5">
              <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="font-display text-lg font-bold text-[#202433]">Customer Support Centre</h2>
                  <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                    Need help with delivery, GST billing, or returns? Reach us directly.
                  </p>
                </div>
                <a
                  href={`https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent(
                    'Hello Business Manager 360 Support, I need assistance with my order.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-xl bg-[#16A879] hover:bg-[#129168] px-4 py-2.5 text-xs sm:text-sm font-bold text-white"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Contact via WhatsApp</span>
                </a>
              </div>

              {/* Raise Support / Return Ticket */}
              <form
                onSubmit={handleSubmitTicket}
                className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6 shadow-xs space-y-3"
              >
                <h3 className="font-display text-base font-bold text-[#202433]">
                  Submit Return or Support Request
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <select
                    value={ticketCat}
                    onChange={(e) => setTicketCat(e.target.value as SupportTicket['category'])}
                    className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
                  >
                    <option value="Order Issue">Order Issue</option>
                    <option value="Return Request">Return Request</option>
                    <option value="Payment">Payment</option>
                    <option value="Product Query">Product Query</option>
                    <option value="General">General</option>
                  </select>
                  <select
                    value={ticketOrderId}
                    onChange={(e) => setTicketOrderId(e.target.value)}
                    className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
                  >
                    <option value="">Related Order (Optional)</option>
                    {orders.map((o) => (
                      <option key={o.id} value={o.id}>
                        {o.orderNumber} (₹{o.totalAmount})
                      </option>
                    ))}
                  </select>
                </div>
                <input
                  required
                  minLength={3}
                  maxLength={160}
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  placeholder="Subject"
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                />
                <textarea
                  required
                  minLength={5}
                  maxLength={1500}
                  rows={3}
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  placeholder="Describe your issue or return request..."
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                />
                <button
                  type="submit"
                  disabled={submittingTicket}
                  className="rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] px-5 py-2.5 text-sm font-semibold text-white cursor-pointer"
                >
                  {submittingTicket ? 'Submitting...' : 'Submit Ticket'}
                </button>
              </form>

              {tickets.length > 0 && (
                <div className="rounded-2xl bg-white border border-slate-200 p-5 space-y-2.5">
                  <h3 className="font-display text-sm font-bold text-[#202433]">Your Support Tickets</h3>
                  {tickets.map((t) => (
                    <div key={t.id} className="rounded-xl bg-[#F7F8FC] p-3 flex justify-between items-start text-xs">
                      <div>
                        <p className="font-bold text-[#202433]">{t.subject}</p>
                        <p className="text-slate-600 mt-0.5">{t.message}</p>
                      </div>
                      <span className="rounded-lg bg-[#EAF2FF] px-2 py-0.5 font-bold text-[#2874F0]">
                        {t.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* FAQ */}
              <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6 space-y-3">
                <h3 className="font-display text-base font-bold text-[#202433]">Frequently Asked Questions</h3>
                <div className="divide-y divide-slate-100">
                  {FAQ_ITEMS.map((item) => (
                    <div key={item.q} className="py-3">
                      <p className="text-sm font-bold text-[#202433]">{item.q}</p>
                      <p className="text-xs sm:text-sm text-slate-600 mt-1">{item.a}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* SETTINGS */}
          {activeSection === 'settings' && (() => {
            const dbStats = getOfflineDbStats();

            const handleDownloadBackup = () => {
              try {
                const json = exportDatabaseBackupJson();
                const blob = new Blob([json], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const anchor = document.createElement('a');
                const dateStamp = new Date().toISOString().slice(0, 10);
                anchor.href = url;
                anchor.download = `bm360-offline-backup-${dateStamp}.json`;
                document.body.appendChild(anchor);
                anchor.click();
                document.body.removeChild(anchor);
                URL.revokeObjectURL(url);
                onToast(
                  'Database backup downloaded',
                  `Saved ${dbStats.ordersCount} orders, ${dbStats.addressesCount} addresses, and ${dbStats.reviewsCount} reviews.`
                );
              } catch {
                onToast('Backup failed', 'Unable to export JSON backup.', 'error');
              }
            };

            const handleRestoreBackupFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
              const file = e.target.files?.[0];
              e.target.value = '';
              if (!file) return;
              try {
                const text = await file.text();
                const summary = await importDatabaseBackupJson(text, restoreMode);
                notifyLocalStoreListeners();
                onToast(
                  'Database restored',
                  `Loaded ${summary.restoredOrders} orders, ${summary.restoredAddresses} addresses, and ${summary.restoredCartItems} cart items.`
                );
              } catch (err) {
                onToast(
                  'Restore failed',
                  err instanceof Error ? err.message : 'Invalid backup JSON file.',
                  'error'
                );
              }
            };

            const handleManualSync = async () => {
              if (!isOnline) {
                onToast(
                  'Currently offline',
                  'Your changes are saved in IndexedDB and will synchronize automatically when online.',
                  'info'
                );
                return;
              }
              const res = await syncPendingChanges();
              notifyLocalStoreListeners();
              if (res.synced) {
                onToast(
                  'Sync completed',
                  `Applied ${res.appliedCount} updates${res.conflictCount > 0 ? ` (${res.conflictCount} newer server conflicts preserved safely)` : ''}.`
                );
              } else {
                onToast('Sync deferred', 'Pending updates remain safely queued in IndexedDB.', 'info');
              }
            };

            return (
              <section className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6 space-y-4">
                <h2 className="font-display text-lg font-bold text-[#202433]">App &amp; Offline Settings</h2>
                <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl bg-[#F7F8FC] p-4">
                  <div>
                    <p className="text-sm font-bold text-[#202433]">Install Business Manager 360 App</p>
                    <p className="text-xs text-slate-500">
                      Installable PWA for offline launch on Android, iOS, and Windows Desktop.
                    </p>
                  </div>
                  <PWAInstallButton />
                </div>

                {/* IndexedDB Primary Storage & Conflict-Safe Sync */}
                <div className="rounded-xl border border-slate-200 p-4 text-xs text-slate-600 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="font-bold text-[#202433] flex items-center gap-1.5 text-sm">
                        <Database className="w-4 h-4 text-[#2874F0]" /> IndexedDB Offline Database &amp; Sync
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Primary DB: <strong className="text-[#202433]">{dbStats.storageEngine}</strong> (
                        {dbStats.dbName}) · Connection:{' '}
                        <strong className={isOnline ? 'text-[#16A879]' : 'text-amber-600'}>
                          {isOnline ? 'Online' : 'Offline Mode'}
                        </strong>
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleManualSync}
                      disabled={syncSnapshot.isSyncing}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] disabled:opacity-60 px-3.5 py-2 text-xs font-bold text-white cursor-pointer"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${syncSnapshot.isSyncing ? 'animate-spin' : ''}`} />
                      <span>{syncSnapshot.isSyncing ? 'Syncing...' : 'Sync Now'}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                    <div className="rounded-lg bg-[#F7F8FC] px-3 py-2">
                      <span className="block text-[11px] text-slate-500">Products Cached</span>
                      <span className="font-bold text-sm text-[#202433] tabular-nums">{dbStats.productsCount}</span>
                    </div>
                    <div className="rounded-lg bg-[#F7F8FC] px-3 py-2">
                      <span className="block text-[11px] text-slate-500">Saved Orders</span>
                      <span className="font-bold text-sm text-[#202433] tabular-nums">{dbStats.ordersCount}</span>
                    </div>
                    <div className="rounded-lg bg-[#F7F8FC] px-3 py-2">
                      <span className="block text-[11px] text-slate-500">Pending Sync</span>
                      <span className="font-bold text-sm text-[#2874F0] tabular-nums">
                        {syncSnapshot.pendingCount}
                      </span>
                    </div>
                    <div className="rounded-lg bg-[#F7F8FC] px-3 py-2">
                      <span className="block text-[11px] text-slate-500">Last Synced</span>
                      <span className="font-bold text-[11px] text-[#202433]">
                        {syncSnapshot.lastSyncedAt
                          ? new Date(syncSnapshot.lastSyncedAt).toLocaleTimeString('en-IN', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })
                          : 'Pending online'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* JSON Database Backup & Restore */}
                <div className="rounded-xl border border-slate-200 p-4 space-y-3">
                  <div>
                    <p className="text-sm font-bold text-[#202433]">Database Backup &amp; Restore (JSON)</p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Export all orders, addresses, profile, cart, wishlist, and reviews to a portable JSON file,
                      or restore safely with timestamp conflict protection.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={handleDownloadBackup}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-[#16A879] hover:bg-[#128E65] px-4 py-2 text-xs font-bold text-white cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download JSON Backup</span>
                    </button>

                    <select
                      aria-label="Backup restore mode"
                      value={restoreMode}
                      onChange={(e) => setRestoreMode(e.target.value as 'merge' | 'replace')}
                      className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-[#202433]"
                    >
                      <option value="merge">Safe Merge (Keep Newer Records)</option>
                      <option value="replace">Full Restore (Replace Local DB)</option>
                    </select>

                    <button
                      type="button"
                      onClick={() => backupFileInputRef.current?.click()}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 px-4 py-2 text-xs font-bold text-[#202433] cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5 text-[#2874F0]" />
                      <span>Restore from JSON</span>
                    </button>

                    <input
                      ref={backupFileInputRef}
                      type="file"
                      accept="application/json,.json"
                      onChange={handleRestoreBackupFile}
                      className="hidden"
                    />
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 p-4 text-xs text-slate-600 space-y-2">
                  <p className="font-bold text-[#202433] flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-[#16A879]" /> Offline-First Storage &amp; Future API Ready
                  </p>
                  <p>
                    Currently active provider: <strong className="text-[#2874F0]">LocalDemoService</strong>{' '}
                    backed by <strong className="text-[#202433]">IndexedDB</strong> primary storage and automatic
                    conflict-safe background sync.
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Future connection flow: Customer Shopping App → Secure Backend API → Separate Admin Billing App
                    (API keys stored securely on backend only).
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-amber-200 bg-amber-50/60 p-4">
                  <div>
                    <p className="text-sm font-bold text-[#202433]">Reset Local Demo Store Data</p>
                    <p className="text-xs text-slate-600">
                      Restore sample products, stock counts, demo orders, addresses, and reward points to initial
                      defaults.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      activeServices.resetDemoData?.();
                      onToast(
                        'Demo store reset',
                        'All local IndexedDB demo data has been restored to initial defaults.',
                        'info'
                      );
                    }}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-white border border-amber-300 hover:bg-amber-100 px-4 py-2 text-xs font-bold text-amber-900 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset Demo Data</span>
                  </button>
                </div>
              </section>
            );
          })()}
        </div>
      </div>
    </div>
  );
};
