import React from 'react';
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';
import { ToastMessage } from '../types/store';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="fixed top-16 lg:top-20 right-3 left-3 sm:left-auto sm:right-5 z-[60] flex flex-col gap-2 sm:w-88 pointer-events-none"
    >
      {toasts.map((t) => {
        const icon =
          t.variant === 'error' ? (
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          ) : t.variant === 'warning' ? (
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          ) : t.variant === 'info' ? (
            <Info className="w-4 h-4 text-[#2874F0] shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-[#16A879] shrink-0" />
          );

        return (
          <div
            key={t.id}
            className="pointer-events-auto flex items-start gap-3 rounded-xl bg-white border border-slate-200 p-3.5 shadow-lg transition-all"
          >
            <div className="mt-0.5">{icon}</div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-[#202433]">{t.title}</p>
              {t.description && <p className="text-xs text-slate-500 mt-0.5">{t.description}</p>}
            </div>
            <button
              type="button"
              onClick={() => onDismiss(t.id)}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              aria-label="Dismiss notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
