import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronDown,
  Clock,
  HeadphonesIcon,
  Heart,
  LogOut,
  MapPin,
  Search,
  ShoppingCart,
  TrendingUp,
  User as UserIcon,
  X,
} from 'lucide-react';
import { AccountSection, Category, CustomerUser, Product, UserProfile } from '../types/store';
import { BrandLogo } from './BrandLogo';
import { PWAInstallButton } from './PWAInstallButton';
import { SafeImage } from './SafeImage';

interface DesktopHeaderProps {
  user: CustomerUser | null;
  profile: UserProfile | null;
  location: { city: string; pincode: string; serviceable?: boolean; estimatedDeliveryText?: string };
  searchQuery: string;
  recentSearches: string[];
  products: Product[];
  categories: Category[];
  wishlistCount: number;
  cartCount: number;
  onSearchChange: (val: string) => void;
  onSearchSubmit: (val: string) => void;
  onSelectProduct: (product: Product) => void;
  onSelectCategory: (slug: string) => void;
  onOpenLocation: () => void;
  onNavigateHome: () => void;
  onOpenWishlist: () => void;
  onOpenCart: () => void;
  onOpenAccount: (section: AccountSection) => void;
  onSignIn: () => void;
  onSignOut: () => void;
  onClearRecentSearches?: () => void;
}

const POPULAR_SEARCHES = ['Basmati Rice', 'Kashmiri Apples', 'Assam Tea', 'Wireless Headphones', 'Cookware Set'];

export const DesktopHeader: React.FC<DesktopHeaderProps> = ({
  user,
  profile,
  location,
  searchQuery,
  recentSearches,
  products,
  categories,
  wishlistCount,
  cartCount,
  onSearchChange,
  onSearchSubmit,
  onSelectProduct,
  onSelectCategory,
  onOpenLocation,
  onNavigateHome,
  onOpenWishlist,
  onOpenCart,
  onOpenAccount,
  onSignIn,
  onSignOut,
  onClearRecentSearches,
}) => {
  const [searchFocused, setSearchFocused] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const accountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSearchFocused(false);
      }
      if (accountRef.current && !accountRef.current.contains(e.target as Node)) {
        setAccountOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const q = searchQuery.trim().toLowerCase();
  const matchedProducts = q
    ? products
        .filter(
          (p) =>
            p.name.toLowerCase().includes(q) ||
            p.brand.toLowerCase().includes(q) ||
            p.categoryName.toLowerCase().includes(q) ||
            (p.tags || []).some((t) => t.toLowerCase().includes(q))
        )
        .slice(0, 5)
    : [];

  const matchedCategories = q
    ? categories.filter((c) => c.name.toLowerCase().includes(q)).slice(0, 3)
    : [];

  return (
    <header className="hidden lg:block sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-xs">
      <div className="max-w-[1440px] mx-auto px-6 h-[72px] flex items-center justify-between gap-5">
        {/* Left: Logo + Delivery Location */}
        <div className="flex items-center gap-5 shrink-0">
          <BrandLogo variant="desktop" onClick={onNavigateHome} />

          <button
            type="button"
            onClick={onOpenLocation}
            className="flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-left hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <MapPin
              className={`w-4 h-4 shrink-0 ${
                location.serviceable === false ? 'text-red-500' : 'text-[#2874F0]'
              }`}
            />
            <div className="leading-tight">
              <span className="block text-[11px] font-bold">
                {location.serviceable === false ? (
                  <span className="text-red-600">Area unavailable</span>
                ) : location.estimatedDeliveryText ? (
                  <span className="text-[#16A879]">Delivery in {location.estimatedDeliveryText}</span>
                ) : (
                  <span className="text-slate-500 font-normal">Deliver to</span>
                )}
              </span>
              <span className="flex items-center gap-1 text-xs font-semibold text-[#202433] whitespace-nowrap">
                <span className="max-w-[140px] truncate">
                  {location.city} ({location.pincode})
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </span>
            </div>
          </button>
        </div>

        {/* Center: Smart Search Bar with Autocomplete */}
        <div ref={searchRef} className="relative flex-1 max-w-2xl">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSearchFocused(false);
              onSearchSubmit(searchQuery);
            }}
            className="flex items-center w-full rounded-xl border border-slate-300 bg-[#F7F8FC] focus-within:bg-white focus-within:border-[#2874F0] focus-within:ring-2 focus-within:ring-[#2874F0]/15 transition-all overflow-hidden"
          >
            <input
              type="text"
              value={searchQuery}
              onFocus={() => setSearchFocused(true)}
              onChange={(e) => {
                onSearchChange(e.target.value);
                setSearchFocused(true);
              }}
              placeholder="Search for groceries, fresh apples, electronics, cookware..."
              aria-label="Search products"
              className="w-full bg-transparent px-4 py-2.5 text-sm text-[#202433] placeholder:text-slate-400 focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="p-2 text-slate-400 hover:text-slate-600 cursor-pointer"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              type="submit"
              className="bg-[#2874F0] hover:bg-[#1A56C4] text-white px-5 py-2.5 flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Submit search"
            >
              <Search className="w-4 h-4" />
            </button>
          </form>

          {searchFocused && (
            <div className="absolute left-0 right-0 top-full mt-2 rounded-2xl bg-white border border-slate-200 shadow-xl p-3 z-50">
              {q ? (
                <div className="space-y-3">
                  {matchedCategories.length > 0 && (
                    <div>
                      <p className="px-2 text-[11px] font-semibold text-slate-400 mb-1">Categories</p>
                      <div className="flex flex-wrap gap-1.5 px-2">
                        {matchedCategories.map((c) => (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => {
                              setSearchFocused(false);
                              onSelectCategory(c.slug);
                            }}
                            className="rounded-lg bg-[#EAF2FF] px-3 py-1.5 text-xs font-medium text-[#2874F0] hover:bg-[#D8E8FF] cursor-pointer"
                          >
                            in {c.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <p className="px-2 text-[11px] font-semibold text-slate-400 mb-1">Matching Products</p>
                    {matchedProducts.length > 0 ? (
                      <div className="divide-y divide-slate-100">
                        {matchedProducts.map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => {
                              setSearchFocused(false);
                              onSelectProduct(p);
                            }}
                            className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-slate-50 text-left transition-colors cursor-pointer"
                          >
                            <div className="w-10 h-10 rounded-lg overflow-hidden bg-slate-50 border border-slate-100 shrink-0">
                              <SafeImage src={p.images[0]} alt={p.name} className="w-full h-full object-contain p-1" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-[#202433] truncate">{p.name}</p>
                              <p className="text-xs text-slate-500">
                                {p.brand} · {p.categoryName} · {p.unit}
                              </p>
                            </div>
                            <span className="text-sm font-bold text-[#202433] tabular-nums">₹{p.price}</span>
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="px-2 py-2 space-y-2">
                        <p className="text-xs text-slate-500">
                          No direct matches for &ldquo;{searchQuery}&rdquo;. Try a popular search:
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {POPULAR_SEARCHES.map((term) => (
                            <button
                              key={term}
                              type="button"
                              onClick={() => {
                                onSearchChange(term);
                                setSearchFocused(false);
                                onSearchSubmit(term);
                              }}
                              className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-medium text-[#202433] hover:bg-[#EAF2FF] hover:text-[#2874F0] cursor-pointer"
                            >
                              {term}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentSearches.length > 0 && (
                    <div>
                      <div className="flex items-center justify-between px-2 mb-1.5">
                        <p className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" /> Recent Searches
                        </p>
                        {onClearRecentSearches && (
                          <button
                            type="button"
                            onClick={onClearRecentSearches}
                            className="text-[11px] font-semibold text-[#2874F0] hover:underline cursor-pointer"
                          >
                            Clear
                          </button>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-1.5 px-2">
                        {recentSearches.map((term) => (
                          <button
                            key={term}
                            type="button"
                            onClick={() => {
                              onSearchChange(term);
                              setSearchFocused(false);
                              onSearchSubmit(term);
                            }}
                            className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs text-slate-700 hover:bg-slate-50 cursor-pointer"
                          >
                            {term}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  <div>
                    <p className="px-2 text-[11px] font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
                      <TrendingUp className="w-3.5 h-3.5 text-[#FF7A30]" /> Popular Searches
                    </p>
                    <div className="flex flex-wrap gap-1.5 px-2">
                      {POPULAR_SEARCHES.map((term) => (
                        <button
                          key={term}
                          type="button"
                          onClick={() => {
                            onSearchChange(term);
                            setSearchFocused(false);
                            onSearchSubmit(term);
                          }}
                          className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-medium text-[#202433] hover:bg-[#EAF2FF] hover:text-[#2874F0] cursor-pointer"
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: Account, Wishlist, Cart, Support, PWA */}
        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton compact />

          <div ref={accountRef} className="relative">
            {user ? (
              <button
                type="button"
                onClick={() => setAccountOpen((o) => !o)}
                className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-medium text-[#202433] hover:bg-slate-100 transition-colors whitespace-nowrap cursor-pointer"
              >
                <UserIcon className="w-4 h-4 text-[#2874F0]" />
                <span className="max-w-[110px] truncate">{profile?.displayName || user.displayName || 'Account'}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>
            ) : (
              <button
                type="button"
                onClick={onSignIn}
                className="flex items-center gap-1.5 rounded-xl bg-[#EAF2FF] px-3.5 py-2 text-sm font-semibold text-[#2874F0] hover:bg-[#D8E8FF] transition-colors whitespace-nowrap cursor-pointer"
              >
                <UserIcon className="w-4 h-4" />
                <span>Login</span>
              </button>
            )}

            {accountOpen && user && (
              <div className="absolute right-0 top-full mt-2 w-60 rounded-2xl bg-white border border-slate-200 shadow-xl py-2 z-50">
                <div className="px-4 py-2 border-b border-slate-100">
                  <p className="text-sm font-bold text-[#202433] truncate">{profile?.displayName || user.displayName}</p>
                  <p className="text-xs text-slate-500">
                    {profile?.membershipTier || 'Basic'} · {profile?.rewardPoints ?? 0} pts
                  </p>
                </div>
                {(
                  [
                    ['profile', 'My Profile'],
                    ['orders', 'My Orders'],
                    ['rewards', 'Reward Wallet'],
                    ['membership', 'Membership'],
                    ['invoices', 'GST Invoices'],
                    ['addresses', 'Saved Addresses'],
                    ['notifications', 'Notifications'],
                  ] as [AccountSection, string][]
                ).map(([sec, label]) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => {
                      setAccountOpen(false);
                      onOpenAccount(sec);
                    }}
                    className="w-full px-4 py-2 text-left text-sm text-slate-700 hover:bg-slate-50 hover:text-[#2874F0] cursor-pointer"
                  >
                    {label}
                  </button>
                ))}
                <div className="border-t border-slate-100 mt-1 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setAccountOpen(false);
                      onSignOut();
                    }}
                    className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={onOpenWishlist}
            className="relative flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-medium text-[#202433] hover:bg-slate-100 transition-colors whitespace-nowrap cursor-pointer"
          >
            <Heart className="w-4 h-4 text-slate-700" />
            <span>Wishlist</span>
            {wishlistCount > 0 && (
              <span className="ml-0.5 inline-flex items-center justify-center rounded-full bg-[#E83E8C] px-1.5 min-w-[18px] h-[18px] text-[10px] font-bold text-white tabular-nums">
                {wishlistCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={onOpenCart}
            className="relative flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-medium text-[#202433] hover:bg-slate-100 transition-colors whitespace-nowrap cursor-pointer"
          >
            <div className="relative">
              <ShoppingCart className="w-4 h-4 text-slate-700" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 inline-flex items-center justify-center rounded-full bg-[#FF7A30] px-1 min-w-[17px] h-[17px] text-[10px] font-bold text-white tabular-nums">
                  {cartCount}
                </span>
              )}
            </div>
            <span>Cart</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenAccount('support')}
            className="flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-sm font-medium text-slate-600 hover:text-[#2874F0] hover:bg-slate-100 transition-colors whitespace-nowrap cursor-pointer"
          >
            <HeadphonesIcon className="w-4 h-4" />
            <span>Support</span>
          </button>
        </div>
      </div>
    </header>
  );
};
