import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Lock,
  MessageCircle,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
} from 'lucide-react';
import {
  WhatsAppPlatformStatus,
  WhatsAppVerifyOtpResult,
} from '../types/store';
import { whatsappVerificationService } from '../services/serviceContainer';

interface WhatsAppOtpVerificationProps {
  initialPhone?: string;
  verifiedPhone?: string;
  isPhoneVerified?: boolean;
  verifiedAt?: string;
  compact?: boolean;
  onVerified: (receipt: WhatsAppVerifyOtpResult) => Promise<void> | void;
  onToast?: (
    title: string,
    description?: string,
    variant?: 'success' | 'info' | 'warning' | 'error'
  ) => void;
}

function extractIndian10Digits(input?: string): string {
  const digits = String(input || '').replace(/\D/g, '');
  if (digits.length === 12 && digits.startsWith('91')) return digits.slice(2);
  if (digits.length === 11 && digits.startsWith('0')) return digits.slice(1);
  if (digits.length > 10) return digits.slice(-10);
  return digits;
}

function formatMMSS(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const WhatsAppOtpVerification: React.FC<WhatsAppOtpVerificationProps> = ({
  initialPhone,
  verifiedPhone,
  isPhoneVerified = false,
  verifiedAt,
  compact = false,
  onVerified,
  onToast,
}) => {
  const [mobileDigits, setMobileDigits] = useState<string>(() => extractIndian10Digits(initialPhone));
  const [platformStatus, setPlatformStatus] = useState<WhatsAppPlatformStatus | null>(null);
  const [statusLoading, setStatusLoading] = useState(true);

  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [otpSessionActive, setOtpSessionActive] = useState(false);
  const [maskedTarget, setMaskedTarget] = useState('');
  const [expiresAtMs, setExpiresAtMs] = useState<number | null>(null);
  const [cooldownUntilMs, setCooldownUntilMs] = useState<number | null>(null);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  const [sendingOtp, setSendingOtp] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [remainingAttempts, setRemainingAttempts] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{
    type: 'error' | 'warning' | 'info' | 'success';
    title: string;
    detail: string;
  } | null>(null);

  const otpInputRefs = useRef<Array<HTMLInputElement | null>>([]);

  useEffect(() => {
    const incoming = extractIndian10Digits(initialPhone);
    if (incoming && !mobileDigits) {
      setMobileDigits(incoming);
    }
  }, [initialPhone, mobileDigits]);

  useEffect(() => {
    let active = true;
    setStatusLoading(true);
    whatsappVerificationService
      .getPlatformStatus()
      .then((status) => {
        if (active) setPlatformStatus(status);
      })
      .finally(() => {
        if (active) setStatusLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  // Countdown tick for 5-minute OTP expiry & resend cooldown
  useEffect(() => {
    if (!expiresAtMs && !cooldownUntilMs) return;
    const timer = window.setInterval(() => {
      setNowMs(Date.now());
    }, 1000);
    return () => window.clearInterval(timer);
  }, [expiresAtMs, cooldownUntilMs]);

  const expiryRemainingSec = useMemo(() => {
    if (!expiresAtMs) return 0;
    return Math.max(0, Math.ceil((expiresAtMs - nowMs) / 1000));
  }, [expiresAtMs, nowMs]);

  const cooldownRemainingSec = useMemo(() => {
    if (!cooldownUntilMs) return 0;
    return Math.max(0, Math.ceil((cooldownUntilMs - nowMs) / 1000));
  }, [cooldownUntilMs, nowMs]);

  const isOtpExpired = otpSessionActive && expiresAtMs !== null && expiryRemainingSec <= 0;

  useEffect(() => {
    if (isOtpExpired) {
      setOtpDigits(['', '', '', '', '', '']);
      setFeedback({
        type: 'error',
        title: 'WhatsApp OTP Expired',
        detail: 'Your 6-digit OTP expired after 5 minutes. Please request a new OTP via WhatsApp.',
      });
    }
  }, [isOtpExpired]);

  const isValidIndianMobile = /^[6-9]\d{9}$/.test(mobileDigits);
  const verified10 = extractIndian10Digits(verifiedPhone);
  const currentNumberIsVerified = Boolean(
    isPhoneVerified && isValidIndianMobile && verified10 === mobileDigits
  );

  const handleMobileInputChange = (raw: string) => {
    const cleaned = extractIndian10Digits(raw).slice(0, 10);
    setMobileDigits(cleaned);
    setOtpSessionActive(false);
    setOtpDigits(['', '', '', '', '', '']);
    setExpiresAtMs(null);
    setCooldownUntilMs(null);
    setRemainingAttempts(null);
    setFeedback(null);
  };

  const handleSendOtp = async () => {
    if (!isValidIndianMobile) {
      setFeedback({
        type: 'error',
        title: 'Invalid Indian Mobile Number',
        detail: 'Enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.',
      });
      return;
    }

    setSendingOtp(true);
    setFeedback(null);

    try {
      const result = await whatsappVerificationService.sendOtpViaWhatsApp(`+91${mobileDigits}`);
      const now = Date.now();

      if (!result.sent) {
        if (result.code === 'RESEND_COOLDOWN_ACTIVE' && result.retryAfterSeconds) {
          setCooldownUntilMs(now + result.retryAfterSeconds * 1000);
          setNowMs(now);
        }

        const isDisabledConfig = result.code === 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED';
        setFeedback({
          type: isDisabledConfig ? 'warning' : 'error',
          title: isDisabledConfig
            ? 'Live WhatsApp Sending Disabled'
            : result.code === 'RESEND_COOLDOWN_ACTIVE'
            ? 'Please Wait Before Resending'
            : 'Unable to Send WhatsApp OTP',
          detail: result.message,
        });
        onToast?.(
          isDisabledConfig ? 'WhatsApp Sending Disabled' : 'WhatsApp OTP Not Sent',
          result.message,
          isDisabledConfig ? 'warning' : 'error'
        );
        return;
      }

      setOtpSessionActive(true);
      setOtpDigits(['', '', '', '', '', '']);
      setMaskedTarget(result.maskedPhone || `+91 ••••••${mobileDigits.slice(-4)}`);
      setRemainingAttempts(result.maxAttempts ?? 5);
      setExpiresAtMs(
        result.expiresAt
          ? new Date(result.expiresAt).getTime()
          : now + (result.expiresInSeconds ?? 300) * 1000
      );
      setCooldownUntilMs(now + (result.resendCooldownSeconds ?? 60) * 1000);
      setNowMs(now);
      setFeedback({
        type: 'info',
        title: 'OTP Sent via WhatsApp',
        detail: result.message,
      });
      onToast?.('WhatsApp OTP Sent', result.message, 'success');
      window.setTimeout(() => otpInputRefs.current[0]?.focus(), 80);
    } finally {
      setSendingOtp(false);
    }
  };

  const handleOtpDigitChange = (index: number, raw: string) => {
    const digitsOnly = raw.replace(/\D/g, '');
    if (digitsOnly.length > 1) {
      // Handle full 6-digit paste
      const next = ['', '', '', '', '', ''];
      for (let i = 0; i < 6; i++) {
        next[i] = digitsOnly[i] || '';
      }
      setOtpDigits(next);
      const focusIdx = Math.min(5, digitsOnly.length);
      otpInputRefs.current[focusIdx]?.focus();
      return;
    }

    const next = [...otpDigits];
    next[index] = digitsOnly;
    setOtpDigits(next);
    if (digitsOnly && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerifyOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const otpCode = otpDigits.join('');

    if (!isValidIndianMobile) {
      setFeedback({
        type: 'error',
        title: 'Invalid Mobile Number',
        detail: 'Please enter a valid 10-digit Indian mobile number first.',
      });
      return;
    }

    if (isOtpExpired) {
      setFeedback({
        type: 'error',
        title: 'OTP Expired',
        detail: 'This WhatsApp OTP expired after 5 minutes. Please request a new OTP.',
      });
      return;
    }

    if (!/^\d{6}$/.test(otpCode)) {
      setFeedback({
        type: 'error',
        title: 'Incomplete OTP',
        detail: 'Please enter all 6 digits of your WhatsApp OTP.',
      });
      return;
    }

    setVerifyingOtp(true);
    setFeedback(null);

    try {
      const result = await whatsappVerificationService.verifyWhatsAppOtp(`+91${mobileDigits}`, otpCode);
      if (!result.verified) {
        if (typeof result.remainingAttempts === 'number') {
          setRemainingAttempts(result.remainingAttempts);
        }
        if (result.code === 'OTP_EXPIRED' || result.code === 'MAX_ATTEMPTS_EXCEEDED') {
          setOtpDigits(['', '', '', '', '', '']);
          if (result.code === 'MAX_ATTEMPTS_EXCEEDED') {
            setOtpSessionActive(false);
          }
        }
        setFeedback({
          type: 'error',
          title:
            result.code === 'OTP_EXPIRED'
              ? 'OTP Expired'
              : result.code === 'MAX_ATTEMPTS_EXCEEDED'
              ? 'Attempt Limit Reached'
              : 'Verification Failed',
          detail: result.message,
        });
        onToast?.('WhatsApp Verification Failed', result.message, 'error');
        return;
      }

      // Only mark VERIFIED after backend responds verified: true
      await onVerified(result);
      setOtpSessionActive(false);
      setOtpDigits(['', '', '', '', '', '']);
      setExpiresAtMs(null);
      setCooldownUntilMs(null);
      setRemainingAttempts(null);
      setFeedback({
        type: 'success',
        title: 'Mobile Number Verified via WhatsApp',
        detail: result.message,
      });
      onToast?.('Mobile Verified', `${result.formattedDisplay || result.e164} verified via WhatsApp.`, 'success');
    } finally {
      setVerifyingOtp(false);
    }
  };

  return (
    <div
      className={`rounded-2xl border border-slate-200 bg-white ${
        compact ? 'p-4 space-y-3' : 'p-5 sm:p-6 space-y-4 shadow-xs'
      }`}
    >
      {/* Header & Verification Status Badge */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
            <MessageCircle className="w-4 h-4 text-[#16A879]" />
          </div>
          <div>
            <h3 className="font-display text-sm sm:text-base font-bold text-[#202433]">
              WhatsApp Mobile Verification
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Default verification via official Meta WhatsApp Business Platform (6-digit OTP · 5-min expiry)
            </p>
          </div>
        </div>

        {currentNumberIsVerified ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 border border-emerald-200 px-3 py-1 text-xs font-bold text-[#128C63]">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>VERIFIED</span>
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 border border-amber-200 px-3 py-1 text-xs font-bold text-amber-800">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>UNVERIFIED</span>
          </span>
        )}
      </div>

      {/* Live Sending Disabled Notice (honest, never fakes verification) */}
      {!statusLoading && platformStatus && !platformStatus.liveSendingEnabled && (
        <div className="rounded-xl border border-amber-200 bg-amber-50/80 p-3 flex items-start gap-2.5 text-xs text-amber-950">
          <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">WhatsApp Business Platform Integration Ready (Live Sending Disabled)</p>
            <p className="text-amber-900/90 leading-relaxed">
              {platformStatus.statusMessage} No API credentials are stored in the customer frontend. Once backend
              WhatsApp Cloud API credentials are configured, OTP delivery &amp; verification will activate
              automatically.
            </p>
          </div>
        </div>
      )}

      {/* Indian Mobile Input + Primary Send OTP via WhatsApp CTA */}
      <div className="space-y-2">
        <label className="block text-xs font-semibold text-slate-700">
          Indian Mobile Number (+91)
        </label>
        <div className="flex flex-col sm:flex-row gap-2.5">
          <div className="flex flex-1 items-center rounded-xl border border-slate-300 bg-white focus-within:border-[#2874F0] focus-within:ring-2 focus-within:ring-[#2874F0]/15 overflow-hidden">
            <span className="px-3 py-2.5 bg-slate-50 border-r border-slate-200 text-xs sm:text-sm font-bold text-[#202433] shrink-0 select-none">
              IN +91
            </span>
            <input
              type="tel"
              inputMode="numeric"
              autoComplete="tel-national"
              maxLength={10}
              value={mobileDigits}
              onChange={(e) => handleMobileInputChange(e.target.value)}
              placeholder="Enter 10-digit mobile (e.g. 9820451209)"
              aria-label="10-digit Indian mobile number"
              className="w-full px-3.5 py-2.5 text-sm font-mono-num text-[#202433] focus:outline-none"
            />
          </div>

          <button
            type="button"
            disabled={sendingOtp || cooldownRemainingSec > 0 || !isValidIndianMobile}
            onClick={handleSendOtp}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#16A879] hover:bg-[#128C63] disabled:bg-slate-200 disabled:text-slate-500 px-4 py-2.5 text-xs sm:text-sm font-bold text-white shadow-xs transition-colors shrink-0 cursor-pointer disabled:cursor-not-allowed"
          >
            <MessageCircle className="w-4 h-4" />
            <span>
              {sendingOtp
                ? 'Sending via WhatsApp...'
                : cooldownRemainingSec > 0
                ? `Resend in ${cooldownRemainingSec}s`
                : otpSessionActive
                ? 'Resend OTP via WhatsApp'
                : 'Send OTP via WhatsApp'}
            </span>
          </button>
        </div>

        {mobileDigits.length > 0 && !isValidIndianMobile && (
          <p className="text-[11px] text-red-600 font-medium">
            Indian mobile numbers must be 10 digits and start with 6, 7, 8, or 9.
          </p>
        )}

        {currentNumberIsVerified && verifiedAt && (
          <p className="text-[11px] text-[#128C63] flex items-center gap-1 font-medium">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>
              Verified on {new Date(verifiedAt).toLocaleString('en-IN')} via WhatsApp Business Platform
            </span>
          </p>
        )}
      </div>

      {/* Step 2: 6-digit Backend OTP Entry (only active when backend confirms OTP was sent) */}
      {otpSessionActive && (
        <form
          onSubmit={handleVerifyOtp}
          className="rounded-xl border border-slate-200 bg-[#F7F8FC] p-4 space-y-3"
        >
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="font-semibold text-[#202433]">
              Enter 6-digit OTP sent on WhatsApp to <span className="font-mono-num">{maskedTarget}</span>
            </span>
            <span
              className={`inline-flex items-center gap-1 font-mono-num font-bold ${
                isOtpExpired || expiryRemainingSec <= 45 ? 'text-red-600' : 'text-[#2874F0]'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{isOtpExpired ? 'Expired (00:00)' : `Expires in ${formatMMSS(expiryRemainingSec)}`}</span>
            </span>
          </div>

          <div className="flex items-center justify-between gap-1.5 sm:gap-2.5 max-w-sm">
            {otpDigits.map((digit, idx) => (
              <input
                key={idx}
                ref={(el) => {
                  otpInputRefs.current[idx] = el;
                }}
                type="text"
                inputMode="numeric"
                autoComplete={idx === 0 ? 'one-time-code' : 'off'}
                maxLength={6}
                disabled={isOtpExpired || verifyingOtp}
                value={digit}
                onChange={(e) => handleOtpDigitChange(idx, e.target.value)}
                onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                aria-label={`OTP digit ${idx + 1}`}
                className="w-10 h-11 sm:w-11 sm:h-12 rounded-xl border border-slate-300 bg-white text-center font-mono-num text-base sm:text-lg font-extrabold text-[#202433] focus:border-[#2874F0] focus:ring-2 focus:ring-[#2874F0]/20 focus:outline-none disabled:bg-slate-100"
              />
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-3 text-[11px] text-slate-600">
              {remainingAttempts !== null && (
                <span>
                  Attempts remaining: <strong className="text-[#202433]">{remainingAttempts}</strong>
                </span>
              )}
              <button
                type="button"
                disabled={sendingOtp || cooldownRemainingSec > 0}
                onClick={handleSendOtp}
                className="inline-flex items-center gap-1 font-bold text-[#2874F0] disabled:text-slate-400 hover:underline cursor-pointer disabled:cursor-not-allowed"
              >
                <RefreshCw className="w-3 h-3" />
                <span>
                  {cooldownRemainingSec > 0
                    ? `Resend in ${cooldownRemainingSec}s`
                    : 'Resend via WhatsApp'}
                </span>
              </button>
            </div>

            <button
              type="submit"
              disabled={verifyingOtp || isOtpExpired || otpDigits.join('').length !== 6}
              className="rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] disabled:bg-slate-300 px-5 py-2 text-xs sm:text-sm font-bold text-white cursor-pointer disabled:cursor-not-allowed"
            >
              {verifyingOtp ? 'Verifying on Backend...' : 'Verify WhatsApp OTP'}
            </button>
          </div>
        </form>
      )}

      {/* Clear Error / Status Feedback Banner */}
      {feedback && (
        <div
          role="alert"
          className={`rounded-xl border p-3 flex items-start gap-2.5 text-xs ${
            feedback.type === 'error'
              ? 'bg-red-50 border-red-200 text-red-900'
              : feedback.type === 'warning'
              ? 'bg-amber-50 border-amber-200 text-amber-900'
              : feedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-[#EAF2FF] border-[#2874F0]/30 text-[#202433]'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-[#16A879] shrink-0 mt-0.5" />
          ) : (
            <AlertCircle
              className={`w-4 h-4 shrink-0 mt-0.5 ${
                feedback.type === 'error'
                  ? 'text-red-600'
                  : feedback.type === 'warning'
                  ? 'text-amber-700'
                  : 'text-[#2874F0]'
              }`}
            />
          )}
          <div>
            <p className="font-bold">{feedback.title}</p>
            <p className="mt-0.5 leading-relaxed">{feedback.detail}</p>
          </div>
        </div>
      )}

      {/* Security Guardrail Footnote */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-slate-500 pt-1 border-t border-slate-100">
        <span>Method: WhatsApp OTP (Official Business Platform)</span>
        <span>•</span>
        <span>Expiry: {Math.round((platformStatus?.otpExpirySeconds ?? 300) / 60)} min</span>
        <span>•</span>
        <span>Resend Cooldown: {platformStatus?.resendCooldownSeconds ?? 60}s</span>
        <span>•</span>
        <span>Max Attempts: {platformStatus?.maxAttempts ?? 5}</span>
      </div>
    </div>
  );
};
