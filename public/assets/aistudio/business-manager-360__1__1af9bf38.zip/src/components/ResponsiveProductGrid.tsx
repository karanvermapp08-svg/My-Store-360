import React from 'react';
import { PackageSearch } from 'lucide-react';
import { Product } from '../types/store';
import { ProductCard } from './ProductCard';

interface ResponsiveProductGridProps {
  products: Product[];
  wishlistIds: string[];
  compareIds?: string[];
  loading?: boolean;
  columnsVariant?: 'default' | 'catalog';
  emptyTitle?: string;
  emptyDescription?: string;
  suggestedTerms?: string[];
  onSelectSuggestedTerm?: (term: string) => void;
  onResetFilters?: () => void;
  onOpenProduct: (p: Product) => void;
  onAddToCart: (p: Product) => void;
  onToggleWishlist: (p: Product) => void;
  onToggleCompare?: (p: Product) => void;
}

export const ResponsiveProductGrid: React.FC<ResponsiveProductGridProps> = ({
  products,
  wishlistIds,
  compareIds = [],
  loading = false,
  columnsVariant = 'default',
  emptyTitle = 'No matching products found',
  emptyDescription = 'Try clearing filters or searching for another item.',
  suggestedTerms = ['Basmati Rice', 'A2 Milk', 'Kashmiri Apples', 'Combo Pack', 'Headphones'],
  onSelectSuggestedTerm,
  onResetFilters,
  onOpenProduct,
  onAddToCart,
  onToggleWishlist,
  onToggleCompare,
}) => {
  const gridClass =
    columnsVariant === 'catalog'
      ? 'grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3 sm:gap-4'
      : 'grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-4';

  if (loading) {
    return (
      <div className={gridClass}>
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="rounded-2xl bg-white border border-slate-200 p-3 space-y-3 animate-pulse">
            <div className="aspect-[4/3] rounded-xl bg-slate-100" />
            <div className="h-3 w-2/3 rounded bg-slate-100" />
            <div className="h-4 w-full rounded bg-slate-100" />
            <div className="h-4 w-1/2 rounded bg-slate-100" />
            <div className="h-9 w-full rounded-xl bg-slate-100" />
          </div>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="rounded-2xl bg-white border border-slate-200 p-8 sm:p-12 text-center space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-[#EAF2FF] text-[#2874F0] flex items-center justify-center mx-auto">
          <PackageSearch className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-display text-base font-bold text-[#202433]">{emptyTitle}</h3>
          <p className="mt-1 text-sm text-slate-500 max-w-md mx-auto">{emptyDescription}</p>
        </div>

        {onSelectSuggestedTerm && suggestedTerms.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-semibold text-slate-500">Popular searches to try:</p>
            <div className="flex flex-wrap justify-center gap-2">
              {suggestedTerms.map((term) => (
                <button
                  key={term}
                  type="button"
                  onClick={() => onSelectSuggestedTerm(term)}
                  className="rounded-xl border border-slate-200 bg-[#F7F8FC] hover:bg-[#EAF2FF] hover:text-[#2874F0] px-3 py-1.5 text-xs font-semibold text-[#202433] cursor-pointer"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>
        )}

        {onResetFilters && (
          <button
            type="button"
            onClick={onResetFilters}
            className="rounded-xl bg-[#2874F0] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1A56C4] cursor-pointer"
          >
            Reset All Filters
          </button>
        )}
      </div>
    );
  }

  return (
    <div className={gridClass}>
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          isWishlisted={wishlistIds.includes(product.id)}
          isCompared={compareIds.includes(product.id)}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onToggleWishlist={onToggleWishlist}
          onToggleCompare={onToggleCompare}
        />
      ))}
    </div>
  );
};
