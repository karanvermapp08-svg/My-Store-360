import React from 'react';
import { Category } from '../types/store';
import { SafeImage } from './SafeImage';

interface CategoryStripProps {
  categories: Category[];
  activeSlug: string;
  onSelectCategory: (slug: string) => void;
}

export const CategoryStrip: React.FC<CategoryStripProps> = ({
  categories,
  activeSlug,
  onSelectCategory,
}) => {
  return (
    <section aria-label="Shopping Categories">
      {/* Mobile & Tablet: Horizontally Scrollable Circular Category Icons */}
      <div className="lg:hidden -mx-3.5 px-3.5 overflow-x-auto no-scrollbar">
        <div className="flex items-start gap-3.5 py-1 min-w-max">
          {categories.map((cat) => {
            const active = activeSlug === cat.slug;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => onSelectCategory(cat.slug)}
                className="flex flex-col items-center w-[68px] shrink-0 group cursor-pointer"
              >
                <div
                  className={`w-14 h-14 rounded-full p-1.5 flex items-center justify-center transition-transform group-active:scale-95 border ${
                    active ? 'border-[#2874F0] ring-2 ring-[#2874F0]/25' : 'border-black/5'
                  }`}
                  style={{ backgroundColor: cat.bgTint }}
                >
                  <div className="w-full h-full rounded-full overflow-hidden bg-white">
                    <SafeImage
                      src={cat.image}
                      alt={cat.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                <span
                  className={`mt-1.5 text-[11px] leading-tight text-center line-clamp-2 ${
                    active ? 'font-bold text-[#2874F0]' : 'font-medium text-[#202433]'
                  }`}
                >
                  {cat.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Desktop: Colorful Pastel Rounded Category Cards */}
      <div className="hidden lg:grid grid-cols-5 gap-3.5">
        {categories.map((cat) => {
          const active = activeSlug === cat.slug;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => onSelectCategory(cat.slug)}
              style={{ backgroundColor: cat.bgTint }}
              className={`group flex items-center gap-3.5 rounded-2xl p-3.5 text-left transition-all hover:-translate-y-0.5 hover:shadow-md border cursor-pointer ${
                active ? 'border-[#2874F0] ring-2 ring-[#2874F0]/20' : 'border-black/5'
              }`}
            >
              <div className="w-16 h-16 rounded-xl overflow-hidden bg-white shrink-0 shadow-xs">
                <SafeImage
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
              </div>
              <div className="min-w-0">
                <span className="block font-display text-sm font-bold text-[#202433] leading-snug">
                  {cat.name}
                </span>
                <span className="text-xs font-medium mt-0.5 block" style={{ color: cat.color }}>
                  Explore →
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
};
