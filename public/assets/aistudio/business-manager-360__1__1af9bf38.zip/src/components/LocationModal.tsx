import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  LocateFixed,
  MapPin,
  Search,
  Sparkles,
  X,
} from 'lucide-react';
import {
  Address,
  PincodeServiceabilityResult,
  ServiceableLocationSuggestion,
  StoreSettings,
} from '../types/store';
import { inventoryAvailabilityService } from '../services/serviceContainer';

export interface SelectedLocationState {
  city: string;
  pincode: string;
  serviceable: boolean;
  areaName?: string;
  hub?: string;
  estimatedDeliveryText?: string;
  expressAvailable?: boolean;
}

interface LocationModalProps {
  isOpen: boolean;
  isFirstOpen?: boolean;
  onClose: () => void;
  currentLocation: SelectedLocationState;
  addresses: Address[];
  settings: StoreSettings;
  onSelectLocation: (loc: SelectedLocationState) => void;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  isFirstOpen = false,
  onClose,
  currentLocation,
  addresses,
  onSelectLocation,
}) => {
  const [pincode, setPincode] = useState(currentLocation.pincode || '400001');
  const [areaSearch, setAreaSearch] = useState('');
  const [suggestions, setSuggestions] = useState<ServiceableLocationSuggestion[]>([]);
  const [checking, setChecking] = useState(false);
  const [detectingGps, setDetectingGps] = useState(false);
  const [result, setResult] = useState<PincodeServiceabilityResult | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setPincode(currentLocation.pincode || '400001');
    inventoryAvailabilityService
      .searchServiceableLocations(areaSearch)
      .then(setSuggestions)
      .catch(() => setSuggestions([]));
  }, [isOpen, areaSearch, currentLocation.pincode]);

  if (!isOpen) return null;

  const applyVerifiedResult = (data: PincodeServiceabilityResult, closeAfter = false) => {
    setResult(data);
    onSelectLocation({
      city: data.areaName ? `${data.areaName}, ${data.city}` : data.city || `Pincode ${data.pincode}`,
      pincode: data.pincode,
      serviceable: data.serviceable,
      areaName: data.areaName,
      hub: data.hub,
      estimatedDeliveryText: data.estimatedDeliveryText,
      expressAvailable: data.expressAvailable,
    });
    if (closeAfter && data.serviceable) {
      onClose();
    }
  };

  const verifyPincode = async (pinToVerify: string, closeOnSuccess = false) => {
    setChecking(true);
    setResult(null);
    try {
      const data = await inventoryAvailabilityService.checkPincodeServiceability(pinToVerify);
      applyVerifiedResult(data, closeOnSuccess);
    } catch {
      setResult({
        serviceable: false,
        pincode: pinToVerify,
        message: 'Unable to verify pincode right now. Please try again.',
      });
    } finally {
      setChecking(false);
    }
  };

  const handleDetectLocation = () => {
    if (!('geolocation' in navigator)) {
      setResult({
        serviceable: false,
        pincode: '',
        message: 'Device GPS detection is unavailable in this browser. Please enter your 6-digit PIN code.',
      });
      return;
    }

    setDetectingGps(true);
    setResult(null);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const detected = await inventoryAvailabilityService.detectNearestLocation(
            pos.coords.latitude,
            pos.coords.longitude
          );
          if (detected.pincode) setPincode(detected.pincode);
          if (detected.serviceable) {
            applyVerifiedResult(detected, true);
          } else {
            setResult(detected);
          }
        } finally {
          setDetectingGps(false);
        }
      },
      (err) => {
        setDetectingGps(false);
        setResult({
          serviceable: false,
          pincode: '',
          message:
            err.code === err.PERMISSION_DENIED
              ? 'Location permission was declined. You can search your area or enter your 6-digit PIN code below.'
              : 'Could not detect GPS coordinates accurately. Please enter your 6-digit PIN code.',
        });
      },
      { enableHighAccuracy: false, timeout: 8000 }
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-3.5 sm:p-4 backdrop-blur-xs">
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl bg-white p-5 sm:p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-start gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#EAF2FF] text-[#2874F0] flex items-center justify-center shrink-0">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display text-base sm:text-lg font-bold text-[#202433]">
                {isFirstOpen ? 'Welcome! Set Your Delivery Location' : 'Change Delivery Location'}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Check hyperlocal delivery availability, ETA &amp; local stock for your PIN code.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[38px] min-h-[38px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close location modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Optional Device GPS Detection */}
        <button
          type="button"
          disabled={detectingGps}
          onClick={handleDetectLocation}
          className="w-full flex items-center justify-between rounded-xl border border-[#2874F0]/30 bg-[#EAF2FF]/60 hover:bg-[#EAF2FF] px-4 py-3 text-left transition-colors cursor-pointer disabled:opacity-60"
        >
          <div className="flex items-center gap-2.5">
            <LocateFixed className={`w-4 h-4 text-[#2874F0] ${detectingGps ? 'animate-spin' : ''}`} />
            <div>
              <p className="text-xs sm:text-sm font-bold text-[#2874F0]">
                {detectingGps ? 'Detecting device coordinates...' : 'Detect My Location'}
              </p>
              <p className="text-[11px] text-slate-600">
                Optional browser permission — matches nearest Business Manager 360 hub locally
              </p>
            </div>
          </div>
          <Sparkles className="w-4 h-4 text-[#FF7A30] shrink-0" />
        </button>

        {/* Manual PIN-Code Verification */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            verifyPincode(pincode.trim(), true);
          }}
          className="space-y-1.5"
        >
          <label className="block text-xs font-semibold text-slate-700">Enter 6-Digit PIN Code</label>
          <div className="flex gap-2">
            <input
              type="text"
              inputMode="numeric"
              maxLength={6}
              value={pincode}
              onChange={(e) => setPincode(e.target.value.replace(/\D/g, '').slice(0, 6))}
              placeholder="e.g. 400001 or 560034"
              className="flex-1 rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm font-mono-num focus:border-[#2874F0] focus:outline-none"
            />
            <button
              type="submit"
              disabled={checking || pincode.length !== 6}
              className="rounded-xl bg-[#2874F0] px-4 py-2.5 text-xs sm:text-sm font-bold text-white hover:bg-[#1A56C4] disabled:opacity-50 whitespace-nowrap cursor-pointer"
            >
              {checking ? 'Checking...' : 'Check & Apply'}
            </button>
          </div>
        </form>

        {/* Verification Result Banner */}
        {result && (
          <div
            className={`flex items-start gap-2.5 rounded-xl border p-3 text-xs ${
              result.serviceable
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-red-50 border-red-200 text-red-900'
            }`}
          >
            {result.serviceable ? (
              <CheckCircle2 className="w-4 h-4 text-[#16A879] shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            )}
            <div className="space-y-0.5">
              <p className="font-bold">
                {result.serviceable ? 'Delivery Available' : 'Area Currently Unavailable'}
              </p>
              <p>{result.message}</p>
              {result.serviceable && result.hub && (
                <p className="text-[11px] text-emerald-700">Fulfilled from: {result.hub}</p>
              )}
            </div>
          </div>
        )}

        {/* Saved Delivery Addresses */}
        {addresses.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-bold text-slate-600">Saved Delivery Addresses</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {addresses.map((addr) => {
                const active = currentLocation.pincode === addr.pincode;
                return (
                  <button
                    key={addr.id}
                    type="button"
                    onClick={() => verifyPincode(addr.pincode, true)}
                    className={`rounded-xl border p-2.5 text-left transition-colors cursor-pointer ${
                      active
                        ? 'border-[#2874F0] bg-[#EAF2FF]'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-xs font-bold text-[#2874F0]">{addr.label}</span>
                      <span className="text-[11px] font-mono-num text-slate-500">{addr.pincode}</span>
                    </div>
                    <p className="text-xs font-semibold text-[#202433] truncate mt-0.5">
                      {addr.line1}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">
                      {addr.city}, {addr.state}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Search Area / Address / Hub */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-600">
            Search Area, City or Hub
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={areaSearch}
              onChange={(e) => setAreaSearch(e.target.value)}
              placeholder="Search Bandra, Koramangala, Connaught Place, Powai, Pune..."
              className="w-full rounded-xl border border-slate-300 pl-9 pr-3 py-2 text-xs sm:text-sm focus:border-[#2874F0] focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-0.5">
            {suggestions.length === 0 ? (
              <p className="sm:col-span-2 text-xs text-slate-500 py-3 text-center">
                No verified hub matches &ldquo;{areaSearch}&rdquo;. Try entering your 6-digit PIN code above.
              </p>
            ) : (
              suggestions.map((item) => {
                const active = currentLocation.pincode === item.pincode;
                return (
                  <button
                    key={item.pincode}
                    type="button"
                    onClick={() => {
                      setPincode(item.pincode);
                      onSelectLocation({
                        city: `${item.areaName}, ${item.city}`,
                        pincode: item.pincode,
                        serviceable: true,
                        areaName: item.areaName,
                        hub: item.hub,
                        expressAvailable: item.expressAvailable,
                        estimatedDeliveryText: item.estimatedDeliveryText,
                      });
                      onClose();
                    }}
                    className={`flex flex-col items-start rounded-xl border p-2.5 text-left transition-colors cursor-pointer ${
                      active
                        ? 'border-[#2874F0] bg-[#EAF2FF]'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full gap-1">
                      <span className="text-xs font-bold text-[#202433] truncate">{item.areaName}</span>
                      <span className="text-[11px] font-mono-num text-slate-500 shrink-0">{item.pincode}</span>
                    </div>
                    <span className="text-[11px] text-slate-500">{item.city}, {item.state}</span>
                    {item.estimatedDeliveryText && (
                      <span className="mt-1 inline-flex items-center gap-1 text-[10px] font-bold text-[#16A879]">
                        <Clock className="w-3 h-3" />
                        {item.estimatedDeliveryText}
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
