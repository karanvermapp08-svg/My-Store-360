import React, { useState } from 'react';
import {
  Bell,
  ChevronDown,
  Clock,
  MapPin,
  Mic,
  Search,
  ShoppingCart,
  TrendingUp,
  User as UserIcon,
  X,
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { Category, CustomerUser, Product } from '../types/store';
import { SafeImage } from './SafeImage';

interface MobileHeaderProps {
  user: CustomerUser | null;
  location: { city: string; pincode: string; serviceable?: boolean; estimatedDeliveryText?: string };
  searchQuery: string;
  recentSearches: string[];
  products: Product[];
  categories: Category[];
  cartCount: number;
  unreadNotifications: number;
  onSearchChange: (val: string) => void;
  onSearchSubmit: (val: string) => void;
  onSelectProduct: (p: Product) => void;
  onSelectCategory: (slug: string) => void;
  onOpenLocation: () => void;
  onNavigateHome: () => void;
  onOpenNotifications: () => void;
  onOpenCart: () => void;
  onOpenAccount: () => void;
  onVoiceMessage: (msg: string) => void;
}

const MOBILE_POPULAR_SEARCHES = ['A2 Milk', 'Basmati Rice', 'Combo Pack', 'Apples', 'Tea'];

export const MobileHeader: React.FC<MobileHeaderProps> = ({
  user,
  location,
  searchQuery,
  recentSearches,
  products,
  categories,
  cartCount,
  unreadNotifications,
  onSearchChange,
  onSearchSubmit,
  onSelectProduct,
  onSelectCategory,
  onOpenLocation,
  onNavigateHome,
  onOpenNotifications,
  onOpenCart,
  onOpenAccount,
  onVoiceMessage,
}) => {
  const [focused, setFocused] = useState(false);
  const [listening, setListening] = useState(false);

  const q = searchQuery.trim().toLowerCase();
  const suggestions = q
    ? products
        .filter(
          (p) =>
            p.name.toLowerCase().includes(q) ||
            p.brand.toLowerCase().includes(q) ||
            p.categoryName.toLowerCase().includes(q) ||
            (p.tags || []).some((t) => t.toLowerCase().includes(q))
        )
        .slice(0, 4)
    : [];
  const matchedCategories = q
    ? categories.filter((c) => c.name.toLowerCase().includes(q)).slice(0, 3)
    : [];

  const handleVoiceSearch = () => {
    const SpeechRecognition =
      (window as unknown as { SpeechRecognition?: new () => any; webkitSpeechRecognition?: new () => any })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => any }).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      onVoiceMessage('Voice search is ready in supported mobile Chrome/Safari browsers. Type to search.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-IN';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      setListening(true);
      recognition.onresult = (event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => {
        const transcript = event.results[0]?.[0]?.transcript || '';
        if (transcript) {
          onSearchChange(transcript);
          onSearchSubmit(transcript);
        }
        setListening(false);
      };
      recognition.onerror = () => setListening(false);
      recognition.onend = () => setListening(false);
      recognition.start();
    } catch {
      setListening(false);
    }
  };

  return (
    <header className="lg:hidden sticky top-0 z-40 bg-[#2874F0] text-white shadow-sm">
      {/* Top Row */}
      <div className="px-3.5 h-13 flex items-center justify-between gap-2">
        <BrandLogo variant="mobile" onClick={onNavigateHome} />

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onOpenAccount}
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl hover:bg-white/15 transition-colors cursor-pointer"
            aria-label={user ? 'My Account' : 'Sign In'}
          >
            <UserIcon className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={onOpenNotifications}
            className="relative min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl hover:bg-white/15 transition-colors cursor-pointer"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifications > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-[#FFC83D]" />
            )}
          </button>

          <button
            type="button"
            onClick={onOpenCart}
            className="relative min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl hover:bg-white/15 transition-colors cursor-pointer"
            aria-label="Shopping Cart"
          >
            <ShoppingCart className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute top-1 right-1 inline-flex items-center justify-center rounded-full bg-[#FF7A30] px-1 min-w-[17px] h-[17px] text-[10px] font-bold text-white tabular-nums">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Search Row */}
      <div className="px-3.5 pb-2.5 relative">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setFocused(false);
            onSearchSubmit(searchQuery);
          }}
          className="flex items-center bg-white rounded-xl px-3 h-10 text-[#202433] shadow-xs"
        >
          <Search className="w-4 h-4 text-slate-400 shrink-0 mr-2" />
          <input
            type="text"
            value={searchQuery}
            onFocus={() => setFocused(true)}
            onBlur={() => setTimeout(() => setFocused(false), 180)}
            onChange={(e) => {
              onSearchChange(e.target.value);
              setFocused(true);
            }}
            placeholder="Search for products, groceries..."
            aria-label="Search products"
            className="w-full bg-transparent text-sm text-[#202433] placeholder:text-slate-400 focus:outline-none"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              className="p-1 text-slate-400"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            type="button"
            onClick={handleVoiceSearch}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              listening ? 'text-[#FF7A30] bg-orange-50' : 'text-[#2874F0] hover:bg-blue-50'
            }`}
            aria-label="Voice search"
          >
            <Mic className="w-4 h-4" />
          </button>
        </form>

        {focused && (
          <div className="absolute left-3.5 right-3.5 top-11 rounded-2xl bg-white text-[#202433] border border-slate-200 shadow-xl p-2.5 z-50 space-y-2.5">
            {q ? (
              <>
                {matchedCategories.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {matchedCategories.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onMouseDown={() => {
                          setFocused(false);
                          onSelectCategory(c.slug);
                        }}
                        className="rounded-lg bg-[#EAF2FF] px-2.5 py-1 text-[11px] font-semibold text-[#2874F0]"
                      >
                        in {c.name}
                      </button>
                    ))}
                  </div>
                )}

                {suggestions.length > 0 ? (
                  <div className="divide-y divide-slate-100">
                    {suggestions.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onMouseDown={() => {
                          setFocused(false);
                          onSelectProduct(p);
                        }}
                        className="w-full flex items-center gap-2.5 py-2 text-left hover:bg-slate-50"
                      >
                        <div className="w-9 h-9 rounded-lg overflow-hidden bg-slate-50 shrink-0">
                          <SafeImage src={p.images[0]} alt={p.name} className="w-full h-full object-contain p-0.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold truncate">{p.name}</p>
                          <p className="text-[11px] text-slate-500">{p.unit}</p>
                        </div>
                        <span className="text-xs font-bold tabular-nums">₹{p.price}</span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-1.5 py-1">
                    <p className="text-xs text-slate-500">
                      No direct matches for &ldquo;{searchQuery}&rdquo;. Try popular items:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {MOBILE_POPULAR_SEARCHES.map((term) => (
                        <button
                          key={term}
                          type="button"
                          onMouseDown={() => {
                            onSearchChange(term);
                            setFocused(false);
                            onSearchSubmit(term);
                          }}
                          className="rounded-lg bg-slate-100 px-2.5 py-1 text-[11px] font-medium text-[#202433]"
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="space-y-2.5">
                {recentSearches.length > 0 && (
                  <div>
                    <p className="text-[10px] font-semibold text-slate-400 mb-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Recent
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {recentSearches.map((term) => (
                        <button
                          key={term}
                          type="button"
                          onMouseDown={() => {
                            onSearchChange(term);
                            setFocused(false);
                            onSearchSubmit(term);
                          }}
                          className="rounded-lg border border-slate-200 px-2 py-1 text-[11px] text-slate-700"
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 mb-1 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-[#FF7A30]" /> Popular Searches
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {MOBILE_POPULAR_SEARCHES.map((term) => (
                      <button
                        key={term}
                        type="button"
                        onMouseDown={() => {
                          onSearchChange(term);
                          setFocused(false);
                          onSearchSubmit(term);
                        }}
                        className="rounded-lg bg-slate-100 px-2.5 py-1 text-[11px] font-medium text-[#202433]"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Location Strip */}
      <button
        type="button"
        onClick={onOpenLocation}
        className={`w-full px-3.5 py-1.5 flex items-center gap-1.5 text-xs text-white/95 text-left cursor-pointer ${
          location.serviceable === false ? 'bg-red-600' : 'bg-[#1E62D6]'
        }`}
      >
        <MapPin className="w-3.5 h-3.5 text-[#FFC83D] shrink-0" />
        <span className="truncate">
          {location.serviceable === false ? (
            <>
              Area unavailable · <strong>{location.pincode}</strong> (Tap to change)
            </>
          ) : (
            <>
              {location.estimatedDeliveryText ? (
                <>
                  <strong>{location.estimatedDeliveryText}</strong> to {location.city} · {location.pincode}
                </>
              ) : (
                <>
                  Deliver to <strong>{location.city}</strong> · {location.pincode}
                </>
              )}
            </>
          )}
        </span>
        <ChevronDown className="w-3.5 h-3.5 ml-auto shrink-0 opacity-80" />
      </button>
    </header>
  );
};
