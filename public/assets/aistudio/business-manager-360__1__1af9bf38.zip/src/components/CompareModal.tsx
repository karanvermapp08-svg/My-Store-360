import React from 'react';
import { GitCompareArrows, ShoppingCart, Star, Trash2, X } from 'lucide-react';
import { Product } from '../types/store';
import { SafeImage } from './SafeImage';

interface CompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onRemove: (id: string) => void;
  onAddToCart: (product: Product) => void;
}

export const CompareModal: React.FC<CompareModalProps> = ({
  isOpen,
  onClose,
  products,
  onRemove,
  onAddToCart,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="w-full max-w-4xl max-h-[88vh] rounded-2xl bg-white shadow-2xl flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <div className="flex items-center gap-2 font-display text-base font-bold text-[#202433]">
            <GitCompareArrows className="w-5 h-5 text-[#2874F0]" />
            <span>Compare Products ({products.length}/3)</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close comparison"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {products.length === 0 ? (
          <div className="p-10 text-center text-sm text-slate-500">
            Select up to 3 products using the compare icon on any product card.
          </div>
        ) : (
          <div className="overflow-x-auto p-5">
            <table className="w-full text-left border-collapse min-w-[540px]">
              <thead>
                <tr>
                  <th className="w-36 py-2 pr-3 text-xs font-semibold text-slate-500 align-top">Attribute</th>
                  {products.map((p) => (
                    <th key={p.id} className="p-2 align-top min-w-[170px]">
                      <div className="relative rounded-xl border border-slate-200 p-3 bg-[#F7F8FC]">
                        <button
                          type="button"
                          onClick={() => onRemove(p.id)}
                          aria-label={`Remove ${p.name}`}
                          className="absolute top-2 right-2 p-1 rounded-lg bg-white text-slate-400 hover:text-red-600 shadow-xs cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        <div className="h-24 mb-2 flex items-center justify-center bg-white rounded-lg p-2">
                          <SafeImage src={p.images[0]} alt={p.name} className="max-h-full object-contain" />
                        </div>
                        <p className="text-xs font-bold text-[#202433] line-clamp-2">{p.name}</p>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
                <tr>
                  <td className="py-2.5 pr-3 font-semibold text-slate-500">Selling Price</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-2.5 font-bold text-[#202433] tabular-nums">
                      ₹{p.price.toLocaleString('en-IN')}{' '}
                      <span className="text-xs font-normal text-slate-400 line-through">₹{p.mrp}</span>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="py-2.5 pr-3 font-semibold text-slate-500">Discount</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-2.5 font-semibold text-[#16A879] tabular-nums">
                      {p.discountPercent}% OFF
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="py-2.5 pr-3 font-semibold text-slate-500">Brand &amp; Unit</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-2.5 text-slate-700">
                      {p.brand} · {p.unit}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="py-2.5 pr-3 font-semibold text-slate-500">Rating</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-2.5 text-slate-700 tabular-nums">
                      <span className="inline-flex items-center gap-1 font-semibold">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        {p.rating.toFixed(1)} ({p.reviewCount})
                      </span>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="py-2.5 pr-3 font-semibold text-slate-500">Availability</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-2.5">
                      {p.inStock && p.stock > 0 ? (
                        <span className="text-[#16A879] font-semibold">In Stock ({p.stock})</span>
                      ) : (
                        <span className="text-red-600 font-semibold">Out of Stock</span>
                      )}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="py-3 pr-3" />
                  {products.map((p) => (
                    <td key={p.id} className="p-2.5">
                      <button
                        type="button"
                        disabled={!p.inStock || p.stock <= 0}
                        onClick={() => onAddToCart(p)}
                        className="w-full rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] disabled:bg-slate-300 text-white py-2 px-3 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>Add to Cart</span>
                      </button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
