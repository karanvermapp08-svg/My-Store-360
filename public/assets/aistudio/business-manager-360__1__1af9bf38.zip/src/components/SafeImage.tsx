import React, { useState } from 'react';
import { Package } from 'lucide-react';

interface SafeImageProps {
  src?: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
  eager?: boolean;
}

export const SafeImage: React.FC<SafeImageProps> = ({
  src,
  alt,
  className = 'w-full h-full object-cover',
  fallbackLabel,
  eager = false,
}) => {
  const [failed, setFailed] = useState(false);
  const normalizedSrc = src?.startsWith('/src/assets/images/')
    ? src.replace('/src/assets/images/', '/images/')
    : src;

  if (!normalizedSrc || failed) {
    return (
      <div
        className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-blue-50 text-slate-400 p-3 text-center"
        role="img"
        aria-label={alt}
      >
        <Package className="w-7 h-7 mb-1 text-[#2874F0]/50" />
        <span className="text-[11px] font-medium text-slate-500 line-clamp-2">
          {fallbackLabel || alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={normalizedSrc}
      alt={alt}
      loading={eager ? 'eager' : 'lazy'}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
