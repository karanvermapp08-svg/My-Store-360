import {
  OfflineSyncQueueItem,
  flushOfflineDbWrites,
  getLastSyncedAt,
  getOfflineState,
  getSyncQueue,
  removeSyncQueueKeys,
  setOfflineState,
  upsertSyncQueueItem,
} from './offlineDb';

export interface SyncStatusSnapshot {
  pendingCount: number;
  lastSyncedAt: string | null;
  isSyncing: boolean;
  lastConflictCount: number;
  lastAppliedCount: number;
}

const syncListeners = new Set<() => void>();
let isSyncing = false;
let lastConflictCount = 0;
let lastAppliedCount = 0;
let autoSyncTimer: number | null = null;
let autoListenersBound = false;

function emitSyncChange(): void {
  syncListeners.forEach((fn) => {
    try {
      fn();
    } catch {
      // ignore
    }
  });
}

export function subscribeSyncStatus(listener: () => void): () => void {
  syncListeners.add(listener);
  return () => {
    syncListeners.delete(listener);
  };
}

export function getSyncStatusSnapshot(): SyncStatusSnapshot {
  return {
    pendingCount: getSyncQueue().length,
    lastSyncedAt: getLastSyncedAt(),
    isSyncing,
    lastConflictCount,
    lastAppliedCount,
  };
}

function isBrowserOnline(): boolean {
  if (typeof navigator === 'undefined') return true;
  return navigator.onLine !== false;
}

export function enqueueOfflineSyncMutation(
  entityType: string,
  entityId: string,
  operation: 'upsert' | 'delete',
  payload: Record<string, unknown> | null,
  clientUpdatedAt = new Date().toISOString()
): void {
  const queueKey = `${entityType}:${entityId}`;
  const item: OfflineSyncQueueItem = {
    queueKey,
    idempotencyKey: `${queueKey}:${clientUpdatedAt}:${Math.random().toString(36).slice(2, 7)}`,
    entityType,
    entityId,
    operation,
    payload,
    clientUpdatedAt,
    createdAt: new Date().toISOString(),
    retryCount: 0,
  };
  upsertSyncQueueItem(item);
  emitSyncChange();
  scheduleAutoSync();
}

export function scheduleAutoSync(): void {
  if (typeof window === 'undefined' || !isBrowserOnline()) return;
  if (autoSyncTimer !== null) {
    window.clearTimeout(autoSyncTimer);
  }
  autoSyncTimer = window.setTimeout(() => {
    autoSyncTimer = null;
    void syncPendingChanges();
  }, 600);
}

interface ServerSyncOutcome {
  queueKey: string;
  entityType: string;
  entityId: string;
  status: 'applied' | 'duplicate_ignored' | 'conflict_server_newer';
  serverUpdatedAt: string;
  serverRecord?: {
    entityType: string;
    entityId: string;
    operation: 'upsert' | 'delete';
    payload: Record<string, unknown> | null;
    updatedAt: string;
  };
}

function parseMs(iso?: string): number {
  if (!iso) return 0;
  const ms = Date.parse(iso);
  return Number.isFinite(ms) ? ms : 0;
}

function applyNewerServerConflictRecord(outcome: ServerSyncOutcome): void {
  if (!outcome.serverRecord || !outcome.serverRecord.payload) return;
  const state = getOfflineState();
  const srv = outcome.serverRecord;
  const srvMs = parseMs(srv.updatedAt);

  if (srv.entityType === 'address' && srv.operation === 'upsert') {
    const existing = state.addresses.find((a) => a.id === srv.entityId);
    if (!existing || srvMs > parseMs(existing.updatedAt)) {
      const nextAddresses = existing
        ? state.addresses.map((a) =>
            a.id === srv.entityId ? ({ ...a, ...srv.payload } as typeof a) : a
          )
        : [srv.payload as unknown as (typeof state.addresses)[number], ...state.addresses];
      setOfflineState({ ...state, addresses: nextAddresses });
    }
  } else if (srv.entityType === 'profile' && srv.operation === 'upsert') {
    if (srvMs > parseMs(state.profile.updatedAt)) {
      setOfflineState({
        ...state,
        profile: { ...state.profile, ...srv.payload } as typeof state.profile,
      });
    }
  } else if (srv.entityType === 'order' && srv.operation === 'upsert') {
    const existing = state.orders.find((o) => o.id === srv.entityId);
    if (existing && srvMs > parseMs(existing.updatedAt)) {
      setOfflineState({
        ...state,
        orders: state.orders.map((o) =>
          o.id === srv.entityId ? ({ ...o, ...srv.payload } as typeof o) : o
        ),
      });
    }
  }
}

export async function syncPendingChanges(): Promise<{
  synced: boolean;
  appliedCount: number;
  conflictCount: number;
  remainingCount: number;
}> {
  const queue = getSyncQueue();
  if (isSyncing) {
    return {
      synced: false,
      appliedCount: 0,
      conflictCount: 0,
      remainingCount: queue.length,
    };
  }
  if (!isBrowserOnline() || typeof fetch !== 'function') {
    return {
      synced: false,
      appliedCount: 0,
      conflictCount: 0,
      remainingCount: queue.length,
    };
  }

  if (queue.length === 0) {
    return {
      synced: true,
      appliedCount: 0,
      conflictCount: 0,
      remainingCount: 0,
    };
  }

  isSyncing = true;
  emitSyncChange();

  try {
    await flushOfflineDbWrites();
    const response = await fetch('/api/v1/sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({ mutations: queue }),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const result = (await response.json()) as {
      outcomes?: ServerSyncOutcome[];
      syncedAt?: string;
    };

    const outcomes = Array.isArray(result.outcomes) ? result.outcomes : [];
    const processedKeys: string[] = [];
    let applied = 0;
    let conflicts = 0;

    for (const outcome of outcomes) {
      processedKeys.push(outcome.queueKey);
      if (outcome.status === 'conflict_server_newer') {
        conflicts++;
        applyNewerServerConflictRecord(outcome);
      } else {
        applied++;
      }
    }

    removeSyncQueueKeys(processedKeys, result.syncedAt || new Date().toISOString());
    await flushOfflineDbWrites();

    lastAppliedCount = applied;
    lastConflictCount = conflicts;
    return {
      synced: true,
      appliedCount: applied,
      conflictCount: conflicts,
      remainingCount: getSyncQueue().length,
    };
  } catch {
    // Offline or server unreachable — keep all changes safely queued in IndexedDB
    return {
      synced: false,
      appliedCount: 0,
      conflictCount: 0,
      remainingCount: getSyncQueue().length,
    };
  } finally {
    isSyncing = false;
    emitSyncChange();
  }
}

export function bindOfflineSyncLifecycle(): void {
  if (typeof window === 'undefined' || autoListenersBound) return;
  autoListenersBound = true;

  window.addEventListener('online', () => {
    emitSyncChange();
    void syncPendingChanges();
  });

  window.addEventListener('offline', () => {
    emitSyncChange();
  });

  window.addEventListener('beforeunload', () => {
    void flushOfflineDbWrites();
  });

  if (isBrowserOnline() && getSyncQueue().length > 0) {
    scheduleAutoSync();
  }
}
