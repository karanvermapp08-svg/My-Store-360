import {
  DEFAULT_STORE_SETTINGS,
  INITIAL_CATEGORIES,
  INITIAL_COUPONS,
  INITIAL_OFFERS,
  INITIAL_PRODUCTS,
} from '../data/catalogSeed';
import {
  DEMO_CUSTOMER_USER,
  INITIAL_DEMO_ADDRESSES,
  INITIAL_DEMO_INVOICES,
  INITIAL_DEMO_NOTIFICATIONS,
  INITIAL_DEMO_ORDERS,
  INITIAL_DEMO_ORDER_ITEMS,
  INITIAL_DEMO_PRIVATE_INFO,
  INITIAL_DEMO_PROFILE,
  INITIAL_DEMO_REVIEWS,
  INITIAL_DEMO_REWARDS,
  INITIAL_DEMO_TICKETS,
} from '../data/demoStoreSeed';
import {
  Address,
  CartItem,
  Category,
  Coupon,
  CustomerUser,
  Invoice,
  NotificationItem,
  Offer,
  Order,
  OrderItem,
  Product,
  ProductReview,
  RewardTransaction,
  StoreSettings,
  SupportTicket,
  UserPrivateInfo,
  UserProfile,
} from '../types/store';

export const OFFLINE_DB_NAME = 'bm360_offline_db';
export const OFFLINE_DB_VERSION = 1;

const LEGACY_STATE_KEY = 'bm360_local_demo_state_v1';
const LEGACY_CART_KEY = 'bm360_local_cart_v1';
const LEGACY_SAVED_KEY = 'bm360_local_saved_v1';
const DEVICE_ID_SETTING_KEY = 'bm360_device_id_v1';

export interface OfflineDatabaseState {
  categories: Category[];
  products: Product[];
  offers: Offer[];
  coupons: Coupon[];
  settings: StoreSettings;
  signedInUser: CustomerUser | null;
  profile: UserProfile;
  privateInfo: UserPrivateInfo;
  addresses: Address[];
  wishlistIds: string[];
  recentlyViewedIds: string[];
  orders: Order[];
  orderItems: OrderItem[];
  invoices: Invoice[];
  rewardTransactions: RewardTransaction[];
  notifications: NotificationItem[];
  reviews: ProductReview[];
  tickets: SupportTicket[];
}

export interface OfflineSyncQueueItem {
  queueKey: string;
  idempotencyKey: string;
  entityType: string;
  entityId: string;
  operation: 'upsert' | 'delete';
  payload: Record<string, unknown> | null;
  clientUpdatedAt: string;
  createdAt: string;
  retryCount: number;
  lastError?: string;
}

export interface OfflineDbStats {
  storageEngine: 'IndexedDB' | 'MemoryFallback';
  dbName: string;
  initialized: boolean;
  productsCount: number;
  ordersCount: number;
  addressesCount: number;
  reviewsCount: number;
  cartCount: number;
  savedForLaterCount: number;
  ticketsCount: number;
  pendingSyncCount: number;
  lastSyncedAt: string | null;
  deviceId: string;
}

export interface DatabaseBackupPayload {
  app: 'Business Manager 360';
  formatVersion: number;
  exportedAt: string;
  deviceId: string;
  state: OfflineDatabaseState;
  cart: CartItem[];
  savedForLater: CartItem[];
  syncQueue: OfflineSyncQueueItem[];
}

const STORES = {
  KV: 'kv_store',
  ADDRESSES: 'addresses',
  ORDERS: 'orders',
  ORDER_ITEMS: 'orderItems',
  INVOICES: 'invoices',
  REVIEWS: 'reviews',
  NOTIFICATIONS: 'notifications',
  REWARDS: 'rewards',
  TICKETS: 'tickets',
  SYNC_QUEUE: 'syncQueue',
} as const;

function getOrCreateDeviceId(): string {
  try {
    const existing = localStorage.getItem(DEVICE_ID_SETTING_KEY);
    if (existing) return existing;
    const created = `dev_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    localStorage.setItem(DEVICE_ID_SETTING_KEY, created);
    return created;
  } catch {
    return 'dev_local';
  }
}

function normalizeImageUrl(url?: string): string {
  if (!url) return '';
  return url.startsWith('/src/assets/images/')
    ? url.replace('/src/assets/images/', '/images/')
    : url;
}

function normalizeStateAssetUrls(state: OfflineDatabaseState): OfflineDatabaseState {
  return {
    ...state,
    categories: state.categories.map((c) => ({ ...c, image: normalizeImageUrl(c.image) })),
    products: state.products.map((p) => ({
      ...p,
      images: (p.images || []).map(normalizeImageUrl),
    })),
    orderItems: state.orderItems.map((oi) => ({
      ...oi,
      image: normalizeImageUrl(oi.image),
    })),
    reviews: state.reviews.map((r) => ({
      ...r,
      photos: r.photos ? r.photos.map(normalizeImageUrl) : r.photos,
    })),
  };
}

export function createSeedDatabaseState(): OfflineDatabaseState {
  return {
    categories: INITIAL_CATEGORIES.map((c) => ({ ...c })),
    products: INITIAL_PRODUCTS.map((p) => ({ ...p })),
    offers: INITIAL_OFFERS.map((o) => ({ ...o })),
    coupons: INITIAL_COUPONS.map((c) => ({ ...c })),
    settings: { ...DEFAULT_STORE_SETTINGS },
    signedInUser: { ...DEMO_CUSTOMER_USER },
    profile: { ...INITIAL_DEMO_PROFILE },
    privateInfo: { ...INITIAL_DEMO_PRIVATE_INFO },
    addresses: INITIAL_DEMO_ADDRESSES.map((a) => ({ ...a })),
    wishlistIds: ['prod_fresh_apples', 'prod_wireless_headphones'],
    recentlyViewedIds: ['prod_fresh_apples', 'prod_basmati_rice', 'prod_wireless_headphones'],
    orders: INITIAL_DEMO_ORDERS.map((o) => ({ ...o })),
    orderItems: INITIAL_DEMO_ORDER_ITEMS.map((oi) => ({ ...oi })),
    invoices: INITIAL_DEMO_INVOICES.map((i) => ({ ...i })),
    rewardTransactions: INITIAL_DEMO_REWARDS.map((r) => ({ ...r })),
    notifications: INITIAL_DEMO_NOTIFICATIONS.map((n) => ({ ...n })),
    reviews: INITIAL_DEMO_REVIEWS.map((rv) => ({ ...rv })),
    tickets: INITIAL_DEMO_TICKETS.map((t) => ({ ...t })),
  };
}

// In-memory write-through mirror hydrated from IndexedDB on startup
let cachedState: OfflineDatabaseState | null = null;
let cachedCart: CartItem[] = [];
let cachedSavedForLater: CartItem[] = [];
let cachedSyncQueue: OfflineSyncQueueItem[] = [];
let cachedLastSyncedAt: string | null = null;
let dbInstance: IDBDatabase | null = null;
let initPromise: Promise<void> | null = null;
let writeChain: Promise<void> = Promise.resolve();
let initialized = false;
const deviceId = getOrCreateDeviceId();

function hasIndexedDbSupport(): boolean {
  return typeof indexedDB !== 'undefined' && indexedDB !== null;
}

function openIndexedDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(OFFLINE_DB_NAME, OFFLINE_DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORES.KV)) {
        db.createObjectStore(STORES.KV, { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains(STORES.ADDRESSES)) {
        const s = db.createObjectStore(STORES.ADDRESSES, { keyPath: 'id' });
        s.createIndex('userId', 'userId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.ORDERS)) {
        const s = db.createObjectStore(STORES.ORDERS, { keyPath: 'id' });
        s.createIndex('userId', 'userId', { unique: false });
        s.createIndex('updatedAt', 'updatedAt', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.ORDER_ITEMS)) {
        const s = db.createObjectStore(STORES.ORDER_ITEMS, { keyPath: 'id' });
        s.createIndex('orderId', 'orderId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.INVOICES)) {
        const s = db.createObjectStore(STORES.INVOICES, { keyPath: 'id' });
        s.createIndex('orderId', 'orderId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.REVIEWS)) {
        const s = db.createObjectStore(STORES.REVIEWS, { keyPath: 'id' });
        s.createIndex('productId', 'productId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.NOTIFICATIONS)) {
        const s = db.createObjectStore(STORES.NOTIFICATIONS, { keyPath: 'id' });
        s.createIndex('userId', 'userId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.REWARDS)) {
        const s = db.createObjectStore(STORES.REWARDS, { keyPath: 'id' });
        s.createIndex('userId', 'userId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.TICKETS)) {
        const s = db.createObjectStore(STORES.TICKETS, { keyPath: 'id' });
        s.createIndex('userId', 'userId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.SYNC_QUEUE)) {
        const s = db.createObjectStore(STORES.SYNC_QUEUE, { keyPath: 'queueKey' });
        s.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('Failed to open IndexedDB'));
  });
}

function idbGet<T>(db: IDBDatabase, storeName: string, key: string): Promise<T | undefined> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => resolve(req.result as T | undefined);
    req.onerror = () => reject(req.error);
  });
}

function idbGetAll<T>(db: IDBDatabase, storeName: string): Promise<T[]> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).getAll();
    req.onsuccess = () => resolve((req.result as T[]) || []);
    req.onerror = () => reject(req.error);
  });
}

async function writeFullSnapshotToIdb(
  db: IDBDatabase,
  state: OfflineDatabaseState,
  cart: CartItem[],
  savedForLater: CartItem[],
  syncQueue: OfflineSyncQueueItem[],
  lastSyncedAt: string | null
): Promise<void> {
  const storeNames = Object.values(STORES);
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(storeNames, 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('IndexedDB write transaction failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB write transaction aborted'));

    const kv = tx.objectStore(STORES.KV);
    kv.put({ key: 'store_initialized', value: true, updatedAt: new Date().toISOString() });
    kv.put({
      key: 'catalog',
      value: {
        categories: state.categories,
        products: state.products,
        offers: state.offers,
        coupons: state.coupons,
        settings: state.settings,
      },
    });
    kv.put({
      key: 'customer',
      value: {
        signedInUser: state.signedInUser,
        profile: state.profile,
        privateInfo: state.privateInfo,
        wishlistIds: state.wishlistIds,
        recentlyViewedIds: state.recentlyViewedIds,
      },
    });
    kv.put({ key: 'cart', value: cart });
    kv.put({ key: 'savedForLater', value: savedForLater });
    kv.put({
      key: 'meta',
      value: {
        schemaVersion: OFFLINE_DB_VERSION,
        lastSyncedAt,
        deviceId,
        updatedAt: new Date().toISOString(),
      },
    });

    const replaceCollection = <T extends object>(storeName: string, rows: T[]) => {
      const store = tx.objectStore(storeName);
      store.clear();
      for (const row of rows) {
        store.put(row);
      }
    };

    replaceCollection(STORES.ADDRESSES, state.addresses);
    replaceCollection(STORES.ORDERS, state.orders);
    replaceCollection(STORES.ORDER_ITEMS, state.orderItems);
    replaceCollection(STORES.INVOICES, state.invoices);
    replaceCollection(STORES.REVIEWS, state.reviews);
    replaceCollection(STORES.NOTIFICATIONS, state.notifications);
    replaceCollection(STORES.REWARDS, state.rewardTransactions);
    replaceCollection(STORES.TICKETS, state.tickets);
    replaceCollection(STORES.SYNC_QUEUE, syncQueue);
  });
}

function enqueuePersist(): Promise<void> {
  if (!dbInstance || !cachedState) return Promise.resolve();
  const db = dbInstance;
  const stateSnap = cachedState;
  const cartSnap = cachedCart;
  const savedSnap = cachedSavedForLater;
  const queueSnap = cachedSyncQueue;
  const syncedAtSnap = cachedLastSyncedAt;

  writeChain = writeChain
    .then(() =>
      writeFullSnapshotToIdb(db, stateSnap, cartSnap, savedSnap, queueSnap, syncedAtSnap)
    )
    .catch((err) => {
      console.error('IndexedDB persistence warning:', err);
    });
  return writeChain;
}

function readLegacyLocalStorageSeed(): {
  state: OfflineDatabaseState;
  cart: CartItem[];
  savedForLater: CartItem[];
  migrated: boolean;
} {
  const seed = createSeedDatabaseState();
  let state = seed;
  let cart: CartItem[] = [];
  let savedForLater: CartItem[] = [];
  let migrated = false;

  try {
    const rawState = localStorage.getItem(LEGACY_STATE_KEY);
    if (rawState) {
      const parsed = JSON.parse(rawState) as Partial<OfflineDatabaseState>;
      state = normalizeStateAssetUrls({
        ...seed,
        ...parsed,
        settings: { ...seed.settings, ...(parsed.settings || {}) },
      });
      migrated = true;
    }
  } catch {
    // Keep seed if legacy parse fails
  }

  try {
    const rawCart = localStorage.getItem(LEGACY_CART_KEY);
    if (rawCart) {
      const parsedCart = JSON.parse(rawCart);
      if (Array.isArray(parsedCart)) {
        cart = parsedCart.map((c) => ({ ...c, image: normalizeImageUrl(c.image) }));
        migrated = true;
      }
    }
  } catch {
    // Ignore
  }

  try {
    const rawSaved = localStorage.getItem(LEGACY_SAVED_KEY);
    if (rawSaved) {
      const parsedSaved = JSON.parse(rawSaved);
      if (Array.isArray(parsedSaved)) {
        savedForLater = parsedSaved.map((c) => ({ ...c, image: normalizeImageUrl(c.image) }));
        migrated = true;
      }
    }
  } catch {
    // Ignore
  }

  return { state, cart, savedForLater, migrated };
}

export async function initOfflineDb(): Promise<void> {
  if (initialized) return;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    if (!hasIndexedDbSupport()) {
      const legacy = readLegacyLocalStorageSeed();
      cachedState = legacy.state;
      cachedCart = legacy.cart;
      cachedSavedForLater = legacy.savedForLater;
      cachedSyncQueue = [];
      initialized = true;
      return;
    }

    try {
      const db = await openIndexedDb();
      dbInstance = db;

      const marker = await idbGet<{ key: string; value: boolean }>(db, STORES.KV, 'store_initialized');
      if (!marker?.value) {
        const legacy = readLegacyLocalStorageSeed();
        cachedState = legacy.state;
        cachedCart = legacy.cart;
        cachedSavedForLater = legacy.savedForLater;
        cachedSyncQueue = [];
        cachedLastSyncedAt = null;
        await writeFullSnapshotToIdb(
          db,
          cachedState,
          cachedCart,
          cachedSavedForLater,
          cachedSyncQueue,
          cachedLastSyncedAt
        );
        // Clean large legacy blobs from localStorage only AFTER IndexedDB commit succeeds
        if (legacy.migrated) {
          try {
            localStorage.removeItem(LEGACY_STATE_KEY);
            localStorage.removeItem(LEGACY_CART_KEY);
            localStorage.removeItem(LEGACY_SAVED_KEY);
          } catch {
            // ignore
          }
        }
      } else {
        const seed = createSeedDatabaseState();
        const [
          catalogKv,
          customerKv,
          cartKv,
          savedKv,
          metaKv,
          addresses,
          orders,
          orderItems,
          invoices,
          reviews,
          notifications,
          rewardTransactions,
          tickets,
          syncQueue,
        ] = await Promise.all([
          idbGet<{ key: string; value: Partial<OfflineDatabaseState> }>(db, STORES.KV, 'catalog'),
          idbGet<{ key: string; value: Partial<OfflineDatabaseState> }>(db, STORES.KV, 'customer'),
          idbGet<{ key: string; value: CartItem[] }>(db, STORES.KV, 'cart'),
          idbGet<{ key: string; value: CartItem[] }>(db, STORES.KV, 'savedForLater'),
          idbGet<{ key: string; value: { lastSyncedAt?: string | null } }>(db, STORES.KV, 'meta'),
          idbGetAll<Address>(db, STORES.ADDRESSES),
          idbGetAll<Order>(db, STORES.ORDERS),
          idbGetAll<OrderItem>(db, STORES.ORDER_ITEMS),
          idbGetAll<Invoice>(db, STORES.INVOICES),
          idbGetAll<ProductReview>(db, STORES.REVIEWS),
          idbGetAll<NotificationItem>(db, STORES.NOTIFICATIONS),
          idbGetAll<RewardTransaction>(db, STORES.REWARDS),
          idbGetAll<SupportTicket>(db, STORES.TICKETS),
          idbGetAll<OfflineSyncQueueItem>(db, STORES.SYNC_QUEUE),
        ]);

        const sortNewestFirst = <T extends { createdAt?: string; issuedAt?: string }>(rows: T[]) =>
          [...rows].sort((a, b) =>
            String(b.createdAt || b.issuedAt || '').localeCompare(
              String(a.createdAt || a.issuedAt || '')
            )
          );

        cachedState = normalizeStateAssetUrls({
          ...seed,
          ...(catalogKv?.value || {}),
          ...(customerKv?.value || {}),
          settings: { ...seed.settings, ...(catalogKv?.value?.settings || {}) },
          addresses,
          orders: sortNewestFirst(orders),
          orderItems,
          invoices: sortNewestFirst(invoices),
          reviews: sortNewestFirst(reviews),
          notifications: sortNewestFirst(notifications),
          rewardTransactions: sortNewestFirst(rewardTransactions),
          tickets: sortNewestFirst(tickets),
        });
        cachedCart = Array.isArray(cartKv?.value)
          ? cartKv.value.map((c) => ({ ...c, image: normalizeImageUrl(c.image) }))
          : [];
        cachedSavedForLater = Array.isArray(savedKv?.value)
          ? savedKv.value.map((c) => ({ ...c, image: normalizeImageUrl(c.image) }))
          : [];
        cachedSyncQueue = [...syncQueue].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        cachedLastSyncedAt = metaKv?.value?.lastSyncedAt || null;
      }
    } catch (err) {
      console.error('Failed to open IndexedDB, using in-memory store:', err);
      const legacy = readLegacyLocalStorageSeed();
      cachedState = legacy.state;
      cachedCart = legacy.cart;
      cachedSavedForLater = legacy.savedForLater;
      cachedSyncQueue = [];
    }

    initialized = true;
  })();

  return initPromise;
}

export function getOfflineState(): OfflineDatabaseState {
  if (!cachedState) {
    const legacy = readLegacyLocalStorageSeed();
    cachedState = legacy.state;
    if (cachedCart.length === 0 && legacy.cart.length > 0) cachedCart = legacy.cart;
    if (cachedSavedForLater.length === 0 && legacy.savedForLater.length > 0) {
      cachedSavedForLater = legacy.savedForLater;
    }
    if (hasIndexedDbSupport() && !initPromise) {
      void initOfflineDb();
    }
  }
  return cachedState;
}

export function setOfflineState(next: OfflineDatabaseState): void {
  cachedState = normalizeStateAssetUrls(next);
  void enqueuePersist();
}

export function getOfflineCart(): CartItem[] {
  if (!initialized && cachedCart.length === 0) {
    getOfflineState();
  }
  return cachedCart;
}

export function setOfflineCart(items: CartItem[]): void {
  cachedCart = items.map((i) => ({ ...i, image: normalizeImageUrl(i.image) }));
  void enqueuePersist();
}

export function getOfflineSavedForLater(): CartItem[] {
  if (!initialized && cachedSavedForLater.length === 0) {
    getOfflineState();
  }
  return cachedSavedForLater;
}

export function setOfflineSavedForLater(items: CartItem[]): void {
  cachedSavedForLater = items.map((i) => ({ ...i, image: normalizeImageUrl(i.image) }));
  void enqueuePersist();
}

export function getSyncQueue(): OfflineSyncQueueItem[] {
  return [...cachedSyncQueue];
}

export function upsertSyncQueueItem(item: OfflineSyncQueueItem): void {
  const idx = cachedSyncQueue.findIndex((q) => q.queueKey === item.queueKey);
  if (idx >= 0) {
    cachedSyncQueue[idx] = item;
  } else {
    cachedSyncQueue = [...cachedSyncQueue, item];
  }
  void enqueuePersist();
}

export function removeSyncQueueKeys(keys: string[], syncedAt?: string): void {
  if (keys.length === 0 && !syncedAt) return;
  const drop = new Set(keys);
  cachedSyncQueue = cachedSyncQueue.filter((q) => !drop.has(q.queueKey));
  if (syncedAt) cachedLastSyncedAt = syncedAt;
  void enqueuePersist();
}

export function getLastSyncedAt(): string | null {
  return cachedLastSyncedAt;
}

export async function flushOfflineDbWrites(): Promise<void> {
  await writeChain;
}

export function getOfflineDbStats(): OfflineDbStats {
  const st = getOfflineState();
  return {
    storageEngine: dbInstance ? 'IndexedDB' : 'MemoryFallback',
    dbName: OFFLINE_DB_NAME,
    initialized,
    productsCount: st.products.length,
    ordersCount: st.orders.length,
    addressesCount: st.addresses.length,
    reviewsCount: st.reviews.length,
    cartCount: cachedCart.reduce((s, i) => s + i.quantity, 0),
    savedForLaterCount: cachedSavedForLater.length,
    ticketsCount: st.tickets.length,
    pendingSyncCount: cachedSyncQueue.length,
    lastSyncedAt: cachedLastSyncedAt,
    deviceId,
  };
}

export function exportDatabaseBackupJson(): string {
  const payload: DatabaseBackupPayload = {
    app: 'Business Manager 360',
    formatVersion: 1,
    exportedAt: new Date().toISOString(),
    deviceId,
    state: getOfflineState(),
    cart: getOfflineCart(),
    savedForLater: getOfflineSavedForLater(),
    syncQueue: getSyncQueue(),
  };
  return JSON.stringify(payload, null, 2);
}

function parseTimeMs(iso?: string): number {
  if (!iso) return 0;
  const ms = Date.parse(iso);
  return Number.isFinite(ms) ? ms : 0;
}

function mergeByKeyWithTimestamp<
  T extends { updatedAt?: string; createdAt?: string; issuedAt?: string }
>(existingRows: T[], incomingRows: T[], getKey: (row: T) => string | undefined): T[] {
  const map = new Map<string, T>();
  for (const row of existingRows) {
    const key = getKey(row);
    if (key) map.set(key, row);
  }
  for (const incoming of incomingRows) {
    if (!incoming) continue;
    const key = getKey(incoming);
    if (!key) continue;
    const current = map.get(key);
    if (!current) {
      map.set(key, incoming);
      continue;
    }
    const curMs = parseTimeMs(current.updatedAt || current.createdAt || current.issuedAt);
    const incMs = parseTimeMs(incoming.updatedAt || incoming.createdAt || incoming.issuedAt);
    // Never overwrite newer data with older data
    if (incMs >= curMs) {
      map.set(key, incoming);
    }
  }
  return Array.from(map.values());
}

function mergeByIdWithTimestamp<T extends { id: string; updatedAt?: string; createdAt?: string; issuedAt?: string }>(
  existingRows: T[],
  incomingRows: T[]
): T[] {
  return mergeByKeyWithTimestamp(existingRows, incomingRows, (r) => r.id);
}

export async function importDatabaseBackupJson(
  jsonText: string,
  mode: 'merge' | 'replace' = 'merge'
): Promise<{
  restoredOrders: number;
  restoredAddresses: number;
  restoredReviews: number;
  restoredCartItems: number;
}> {
  let parsed: Partial<DatabaseBackupPayload>;
  try {
    parsed = JSON.parse(jsonText) as Partial<DatabaseBackupPayload>;
  } catch {
    throw new Error('Invalid JSON file. Please select a valid Business Manager 360 backup JSON.');
  }

  if (
    !parsed ||
    parsed.app !== 'Business Manager 360' ||
    !parsed.state ||
    !Array.isArray(parsed.state.products) ||
    !Array.isArray(parsed.state.orders)
  ) {
    throw new Error('Unrecognized backup format. Missing Business Manager 360 database structure.');
  }

  const seed = createSeedDatabaseState();
  const incomingState = normalizeStateAssetUrls({
    ...seed,
    ...parsed.state,
    settings: { ...seed.settings, ...(parsed.state.settings || {}) },
  });
  const incomingCart = Array.isArray(parsed.cart) ? parsed.cart : [];
  const incomingSaved = Array.isArray(parsed.savedForLater) ? parsed.savedForLater : [];
  const incomingQueue = Array.isArray(parsed.syncQueue) ? parsed.syncQueue : [];

  if (mode === 'replace') {
    cachedState = incomingState;
    cachedCart = incomingCart.map((c) => ({ ...c, image: normalizeImageUrl(c.image) }));
    cachedSavedForLater = incomingSaved.map((c) => ({ ...c, image: normalizeImageUrl(c.image) }));
    cachedSyncQueue = incomingQueue;
  } else {
    const current = getOfflineState();
    const curProfMs = parseTimeMs(current.profile?.updatedAt);
    const incProfMs = parseTimeMs(incomingState.profile?.updatedAt);
    const curPrivMs = parseTimeMs(current.privateInfo?.updatedAt);
    const incPrivMs = parseTimeMs(incomingState.privateInfo?.updatedAt);

    cachedState = normalizeStateAssetUrls({
      ...current,
      products: mergeByIdWithTimestamp(current.products, incomingState.products),
      categories: mergeByIdWithTimestamp(current.categories, incomingState.categories),
      offers: mergeByIdWithTimestamp(current.offers, incomingState.offers),
      coupons: mergeByKeyWithTimestamp(current.coupons, incomingState.coupons, (c) => c.code),
      profile: incProfMs > curProfMs ? incomingState.profile : current.profile,
      privateInfo: incPrivMs > curPrivMs ? incomingState.privateInfo : current.privateInfo,
      signedInUser: incomingState.signedInUser || current.signedInUser,
      addresses: mergeByIdWithTimestamp(current.addresses, incomingState.addresses),
      wishlistIds: Array.from(new Set([...current.wishlistIds, ...incomingState.wishlistIds])),
      recentlyViewedIds: Array.from(
        new Set([...current.recentlyViewedIds, ...incomingState.recentlyViewedIds])
      ).slice(0, 12),
      orders: mergeByIdWithTimestamp(current.orders, incomingState.orders),
      orderItems: mergeByIdWithTimestamp(current.orderItems, incomingState.orderItems),
      invoices: mergeByIdWithTimestamp(current.invoices, incomingState.invoices),
      rewardTransactions: mergeByIdWithTimestamp(
        current.rewardTransactions,
        incomingState.rewardTransactions
      ),
      notifications: mergeByIdWithTimestamp(current.notifications, incomingState.notifications),
      reviews: mergeByIdWithTimestamp(current.reviews, incomingState.reviews),
      tickets: mergeByIdWithTimestamp(current.tickets, incomingState.tickets),
    });

    if (incomingCart.length > 0 && cachedCart.length === 0) {
      cachedCart = incomingCart.map((c) => ({ ...c, image: normalizeImageUrl(c.image) }));
    }
    if (incomingSaved.length > 0 && cachedSavedForLater.length === 0) {
      cachedSavedForLater = incomingSaved.map((c) => ({ ...c, image: normalizeImageUrl(c.image) }));
    }
    const queueMap = new Map(cachedSyncQueue.map((q) => [q.queueKey, q]));
    for (const q of incomingQueue) {
      if (q && q.queueKey && !queueMap.has(q.queueKey)) {
        queueMap.set(q.queueKey, q);
      }
    }
    cachedSyncQueue = Array.from(queueMap.values());
  }

  await enqueuePersist();

  return {
    restoredOrders: cachedState.orders.length,
    restoredAddresses: cachedState.addresses.length,
    restoredReviews: cachedState.reviews.length,
    restoredCartItems: cachedCart.length,
  };
}
