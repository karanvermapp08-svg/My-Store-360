import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import { initOfflineDb } from './db/offlineDb';
import { bindOfflineSyncLifecycle } from './db/syncManager';
import './index.css';

async function bootstrap() {
  // Hydrate primary IndexedDB storage before rendering UI so persisted data loads immediately
  await initOfflineDb();
  bindOfflineSyncLifecycle();

  if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
    registerSW({
      immediate: true,
      onRegisteredSW(_swUrl, registration) {
        if (registration && navigator.onLine) {
          registration.update().catch(() => {});
        }
      },
    });
  }

  createRoot(document.getElementById('root')!).render(<App />);
}

void bootstrap();
