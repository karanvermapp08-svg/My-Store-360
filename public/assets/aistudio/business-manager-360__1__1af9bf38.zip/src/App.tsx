import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Clock,
  GitCompareArrows,
  MapPin,
  PackagePlus,
  RotateCcw,
  SlidersHorizontal,
  Sparkles,
  Tag,
} from 'lucide-react';
import {
  DEFAULT_STORE_SETTINGS,
  INITIAL_CATEGORIES,
  INITIAL_COUPONS,
  INITIAL_OFFERS,
  INITIAL_PRODUCTS,
} from './data/catalogSeed';
import {
  AccountSection,
  Address,
  AppView,
  CartItem,
  Category,
  Coupon,
  CustomerUser,
  Invoice,
  NotificationItem,
  Offer,
  Order,
  OrderItem,
  Product,
  RewardTransaction,
  StoreSettings,
  SupportTicket,
  ToastMessage,
  UserPrivateInfo,
  UserProfile,
} from './types/store';
import {
  activeServices,
  cartService,
  categoryService,
  customerService,
  inventoryAvailabilityService,
  invoiceService,
  offerService,
  orderService,
  productService,
} from './services/serviceContainer';
import { DesktopHeader } from './components/DesktopHeader';
import { DesktopNavigation } from './components/DesktopNavigation';
import { MobileHeader } from './components/MobileHeader';
import { MobileBottomNavigation } from './components/MobileBottomNavigation';
import { HeroCarousel } from './components/HeroCarousel';
import { CategoryStrip } from './components/CategoryStrip';
import { ProductCard } from './components/ProductCard';
import { ResponsiveProductGrid } from './components/ResponsiveProductGrid';
import { DesktopProductFilters, FilterState } from './components/DesktopProductFilters';
import { MobileProductFilters } from './components/MobileProductFilters';
import { ProductDetailsView } from './components/ProductDetailsView';
import { ResponsiveCart } from './components/ResponsiveCart';
import { ResponsiveCheckout } from './components/ResponsiveCheckout';
import { ResponsiveAccountDashboard } from './components/ResponsiveAccountDashboard';
import { CompareModal } from './components/CompareModal';
import { LocationModal, SelectedLocationState } from './components/LocationModal';
import { SafeImage } from './components/SafeImage';
import { ToastContainer } from './components/ToastContainer';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallButton } from './components/PWAInstallButton';

const RECENT_SEARCH_KEY = 'bm360_recent_searches_v4';
const LOCATION_STORAGE_KEY = 'bm360_selected_location_v1';
const LOCATION_CONFIRMED_KEY = 'bm360_location_confirmed_v1';

const DEFAULT_LOCATION: SelectedLocationState = {
  city: 'Fort / Churchgate, Mumbai',
  pincode: '400001',
  serviceable: true,
  areaName: 'Fort / Churchgate',
  hub: 'Mumbai Central Express Hub',
  estimatedDeliveryText: '18–25 mins',
  expressAvailable: true,
};

export default function App() {
  // Standalone Demo Customer & Local Store State
  const [user, setUser] = useState<CustomerUser | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [privateInfo, setPrivateInfo] = useState<UserPrivateInfo | null>(null);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [wishlistIds, setWishlistIds] = useState<string[]>([]);
  const [recentlyViewedIds, setRecentlyViewedIds] = useState<string[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [rewardTransactions, setRewardTransactions] = useState<RewardTransaction[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);

  // Local Demo Storefront Catalog
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [offers, setOffers] = useState<Offer[]>(INITIAL_OFFERS);
  const [coupons, setCoupons] = useState<Coupon[]>(INITIAL_COUPONS);
  const [settings, setSettings] = useState<StoreSettings>(DEFAULT_STORE_SETTINGS);
  const [catalogLoading, setCatalogLoading] = useState(false);

  // Navigation & UI State
  const [view, setView] = useState<AppView>('home');
  const [accountSection, setAccountSection] = useState<AccountSection>('orders');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(RECENT_SEARCH_KEY) || '[]');
    } catch {
      return [];
    }
  });
  const [filters, setFilters] = useState<FilterState>({
    categorySlug: 'all',
    maxPrice: 5000,
    selectedBrands: [],
    minDiscount: 0,
    inStockOnly: false,
    sortBy: 'popular',
  });
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  const [locationConfirmed, setLocationConfirmed] = useState<boolean>(() => {
    try {
      return localStorage.getItem(LOCATION_CONFIRMED_KEY) === 'true';
    } catch {
      return false;
    }
  });
  const [locationModalOpen, setLocationModalOpen] = useState<boolean>(() => {
    try {
      return localStorage.getItem(LOCATION_CONFIRMED_KEY) !== 'true';
    } catch {
      return false;
    }
  });
  const [location, setLocation] = useState<SelectedLocationState>(() => {
    try {
      const raw = localStorage.getItem(LOCATION_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as SelectedLocationState;
        if (parsed && parsed.pincode) return parsed;
      }
    } catch {
      // ignore
    }
    return DEFAULT_LOCATION;
  });

  // Cart, Saved For Later, Coupon & Compare
  const [cart, setCart] = useState<CartItem[]>(() => cartService.getCart());
  const [savedForLater, setSavedForLater] = useState<CartItem[]>(() => cartService.getSavedForLater());
  const [recommendedProducts, setRecommendedProducts] = useState<Product[]>([]);
  const [selectedCouponCode, setSelectedCouponCode] = useState('');
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [compareOpen, setCompareOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (
    title: string,
    description?: string,
    variant: ToastMessage['variant'] = 'success'
  ) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
    setToasts((prev) => [...prev.slice(-3), { id, title, description, variant }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3600);
  };

  // Persist Cart, Saved-for-Later, Location & Recent Searches locally
  useEffect(() => {
    cartService.saveCart(cart);
  }, [cart]);

  useEffect(() => {
    cartService.saveSavedForLater(savedForLater);
  }, [savedForLater]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCATION_STORAGE_KEY, JSON.stringify(location));
    } catch {
      // ignore
    }
  }, [location]);

  useEffect(() => {
    try {
      localStorage.setItem(RECENT_SEARCH_KEY, JSON.stringify(recentSearches));
    } catch {
      // ignore
    }
  }, [recentSearches]);

  const hydrateFromServices = useCallback(async () => {
    const [cats, prods, offList, coupList, storeCfg, currentUser] = await Promise.all([
      categoryService.getCategories(),
      productService.getProducts(),
      offerService.getOffers(),
      offerService.getCoupons(),
      offerService.getStoreSettings(),
      customerService.getCurrentCustomer(),
    ]);

    setCategories(cats);
    setProducts(prods);
    setOffers(offList);
    setCoupons(coupList);
    setSettings(storeCfg);
    setCatalogLoading(false);
    setUser(currentUser);
    setAuthReady(true);

    const latestCart = cartService.getCart();
    setCart((prev) => (JSON.stringify(prev) === JSON.stringify(latestCart) ? prev : latestCart));
    const latestSaved = cartService.getSavedForLater();
    setSavedForLater((prev) =>
      JSON.stringify(prev) === JSON.stringify(latestSaved) ? prev : latestSaved
    );

    const recs = await productService.getRecommendedProducts(currentUser?.uid || null);
    setRecommendedProducts(recs);

    if (currentUser) {
      const [snapshot, userOrders, userInvoices] = await Promise.all([
        customerService.getWorkspaceSnapshot(currentUser.uid),
        orderService.getOrders(currentUser.uid),
        invoiceService.getInvoices(currentUser.uid),
      ]);
      setProfile(snapshot.profile);
      setPrivateInfo(snapshot.privateInfo);
      if (snapshot.privateInfo?.preferredPincode && !localStorage.getItem(LOCATION_STORAGE_KEY)) {
        const svc = await inventoryAvailabilityService.checkPincodeServiceability(
          snapshot.privateInfo.preferredPincode
        );
        setLocation({
          city: svc.areaName
            ? `${svc.areaName}, ${svc.city}`
            : snapshot.privateInfo.preferredCity || svc.city || 'Mumbai, MH',
          pincode: svc.pincode,
          serviceable: svc.serviceable,
          areaName: svc.areaName,
          hub: svc.hub,
          estimatedDeliveryText: svc.estimatedDeliveryText,
          expressAvailable: svc.expressAvailable,
        });
      }
      setAddresses(snapshot.addresses);
      setWishlistIds(snapshot.wishlistIds);
      setRecentlyViewedIds(snapshot.recentlyViewedIds);
      setNotifications(snapshot.notifications);
      setRewardTransactions(snapshot.rewardTransactions);
      setTickets(snapshot.tickets);
      setOrders(userOrders);
      setInvoices(userInvoices);
    } else {
      setProfile(null);
      setPrivateInfo(null);
      setAddresses([]);
      setWishlistIds([]);
      setNotifications([]);
      setRewardTransactions([]);
      setOrders([]);
      setInvoices([]);
      setTickets([]);
    }
  }, []);

  useEffect(() => {
    hydrateFromServices();
    const unsub = activeServices.subscribe ? activeServices.subscribe(() => hydrateFromServices()) : () => {};
    return () => unsub();
  }, [hydrateFromServices]);

  const handleSignIn = async () => {
    const signedIn = await customerService.signInDemoCustomer();
    setUser(signedIn);
    await hydrateFromServices();
    addToast('Signed in to Demo Account', `Welcome, ${signedIn.displayName}.`);
  };

  const handleSignOut = async () => {
    await customerService.signOutCustomer();
    setUser(null);
    await hydrateFromServices();
    setView('home');
    addToast('Signed out', 'You can continue browsing or sign back in anytime.', 'info');
  };

  const handleOpenProduct = (product: Product) => {
    setSelectedProduct(product);
    setView('product');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    const updated = [product.id, ...recentlyViewedIds.filter((id) => id !== product.id)].slice(0, 10);
    setRecentlyViewedIds(updated);
    if (user) {
      customerService.recordRecentlyViewed(user.uid, product.id).catch(() => {});
    }
  };

  const handleAddToCart = (
    product: Product,
    quantity = 1,
    variantLabel?: string,
    variantPrice?: number,
    variantMrp?: number
  ) => {
    const unitPrice = variantPrice ?? product.price;
    const unitMrp = variantMrp ?? product.mrp;
    const unitName = variantLabel ?? product.unit;

    setCart((prev) => {
      const existing = prev.find((i) => i.productId === product.id);
      if (existing) {
        const nextQty = Math.min(product.stock, existing.quantity + quantity);
        return prev.map((i) =>
          i.productId === product.id
            ? { ...i, quantity: nextQty, price: unitPrice, mrp: unitMrp, unit: unitName, maxStock: product.stock }
            : i
        );
      }
      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          brand: product.brand,
          unit: unitName,
          mrp: unitMrp,
          price: unitPrice,
          gstPercent: product.gstPercent,
          image: product.images[0],
          quantity: Math.min(product.stock, quantity),
          maxStock: product.stock,
        },
      ];
    });
    addToast('Added to cart', `${product.name} (${quantity} × ${unitName})`);
  };

  const handleBuyNow = (
    product: Product,
    quantity = 1,
    variantLabel?: string,
    variantPrice?: number,
    variantMrp?: number
  ) => {
    handleAddToCart(product, quantity, variantLabel, variantPrice, variantMrp);
    setView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleWishlist = async (product: Product) => {
    if (!user) {
      addToast('Sign in required', 'Signing in to Demo Account so your wishlist is saved locally.', 'info');
      await handleSignIn();
      return;
    }
    const exists = wishlistIds.includes(product.id);
    await customerService.toggleWishlist(user.uid, product.id);
    addToast(
      exists ? 'Removed from wishlist' : 'Saved to wishlist',
      product.name,
      exists ? 'info' : 'success'
    );
  };

  const handleToggleCompare = (product: Product) => {
    setCompareIds((prev) => {
      if (prev.includes(product.id)) return prev.filter((id) => id !== product.id);
      if (prev.length >= 3) {
        addToast('Comparison limit reached', 'You can compare up to 3 products at once.', 'warning');
        return prev;
      }
      return [...prev, product.id];
    });
  };

  const handleSelectCategory = (slug: string) => {
    setFilters((f) => ({ ...f, categorySlug: slug }));
    setView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearchSubmit = (val: string) => {
    const clean = val.trim();
    if (clean) {
      setRecentSearches((prev) => [clean, ...prev.filter((s) => s !== clean)].slice(0, 6));
    }
    setSearchQuery(clean);
    setView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setFilters({
      categorySlug: 'all',
      maxPrice: 5000,
      selectedBrands: [],
      minDiscount: 0,
      inStockOnly: false,
      sortBy: 'popular',
    });
  };

  const handleReorder = (orderItems: OrderItem[]) => {
    let addedCount = 0;
    for (const oi of orderItems) {
      const liveProd = products.find((p) => p.id === oi.productId);
      if (liveProd && liveProd.inStock && liveProd.stock > 0) {
        handleAddToCart(liveProd, Math.min(oi.quantity, liveProd.stock));
        addedCount++;
      }
    }
    if (addedCount > 0) {
      setView('cart');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      addToast('Items unavailable', 'Previous items are currently out of stock.', 'warning');
    }
  };

  const handleSaveForLater = (item: CartItem) => {
    setCart((prev) => prev.filter((i) => i.productId !== item.productId));
    setSavedForLater((prev) => {
      const exists = prev.some((s) => s.productId === item.productId);
      if (exists) return prev;
      return [item, ...prev];
    });
    addToast('Saved for later', `${item.name} moved to Saved Items.`, 'info');
  };

  const handleMoveSavedToCart = (item: CartItem) => {
    setSavedForLater((prev) => prev.filter((s) => s.productId !== item.productId));
    setCart((prev) => {
      const existing = prev.find((i) => i.productId === item.productId);
      if (existing) {
        return prev.map((i) =>
          i.productId === item.productId
            ? { ...i, quantity: Math.min(i.maxStock, i.quantity + item.quantity) }
            : i
        );
      }
      return [...prev, item];
    });
    addToast('Moved to cart', `${item.name} is ready in your cart.`);
  };

  const handleRemoveSaved = (productId: string) => {
    setSavedForLater((prev) => prev.filter((s) => s.productId !== productId));
  };

  // Filtered Catalog Products
  const availableBrands = useMemo(
    () => Array.from(new Set(products.map((p) => p.brand))).sort(),
    [products]
  );

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = products.filter((p) => {
      if (
        filters.categorySlug !== 'all' &&
        filters.categorySlug !== 'offers' &&
        filters.categorySlug !== 'combos'
      ) {
        const cat = categories.find((c) => c.slug === filters.categorySlug);
        if (cat && p.categoryId !== cat.id) return false;
      }
      if (filters.categorySlug === 'offers' && p.discountPercent < 20) return false;
      if (filters.categorySlug === 'combos' && !p.isComboPack) return false;
      if (p.price > filters.maxPrice) return false;
      if (filters.selectedBrands.length > 0 && !filters.selectedBrands.includes(p.brand)) return false;
      if (p.discountPercent < filters.minDiscount) return false;
      if (filters.inStockOnly && (!p.inStock || p.stock <= 0)) return false;
      if (q) {
        const hay = `${p.name} ${p.brand} ${p.categoryName} ${(p.tags || []).join(' ')} ${(p.bundleItems || []).join(' ')}`.toLowerCase();
        const tokens = q.split(/\s+/);
        if (!tokens.every((t) => hay.includes(t))) return false;
      }
      return true;
    });

    if (filters.sortBy === 'price-asc') return [...list].sort((a, b) => a.price - b.price);
    if (filters.sortBy === 'price-desc') return [...list].sort((a, b) => b.price - a.price);
    if (filters.sortBy === 'discount') return [...list].sort((a, b) => b.discountPercent - a.discountPercent);
    return [...list].sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
  }, [products, categories, filters, searchQuery]);

  // Curated Home Collections
  const todaysDeals = useMemo(
    () => products.filter((p) => p.isTodaysDeal || p.discountPercent >= 20).slice(0, 5),
    [products]
  );
  const comboProducts = useMemo(
    () => products.filter((p) => p.isComboPack),
    [products]
  );
  const bestSellers = useMemo(
    () => products.filter((p) => p.isBestSeller).slice(0, 5),
    [products]
  );
  const trendingProducts = useMemo(
    () => products.filter((p) => p.isTrending).slice(0, 5),
    [products]
  );
  const groceryAndDairySpecials = useMemo(
    () =>
      products
        .filter((p) =>
          ['cat_grocery', 'cat_daily_essentials', 'cat_dairy', 'cat_fruits_veg'].includes(
            p.categoryId
          )
        )
        .slice(0, 5),
    [products]
  );
  const recentlyViewedProducts = useMemo(
    () =>
      recentlyViewedIds
        .map((id) => products.find((p) => p.id === id))
        .filter((p): p is Product => Boolean(p))
        .slice(0, 5),
    [recentlyViewedIds, products]
  );
  const lastDeliveredOrder = useMemo(
    () => orders.find((o) => o.status === 'Delivered'),
    [orders]
  );
  const wishlistProducts = useMemo(
    () => products.filter((p) => wishlistIds.includes(p.id)),
    [products, wishlistIds]
  );
  const compareProducts = useMemo(
    () => products.filter((p) => compareIds.includes(p.id)),
    [products, compareIds]
  );
  const cartCount = useMemo(() => cart.reduce((sum, i) => sum + i.quantity, 0), [cart]);
  const unreadNotifs = useMemo(() => notifications.filter((n) => !n.read).length, [notifications]);

  const activeCategoryLabel =
    filters.categorySlug === 'all'
      ? 'All Products'
      : filters.categorySlug === 'offers'
      ? 'Special Offers & Deals'
      : filters.categorySlug === 'combos'
      ? 'Combo Value Packs & Bundles'
      : categories.find((c) => c.slug === filters.categorySlug)?.name || 'Catalog';

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F8FC] text-[#202433]">
      {/* Desktop & Mobile Headers */}
      <DesktopHeader
        user={user}
        profile={profile}
        location={location}
        searchQuery={searchQuery}
        recentSearches={recentSearches}
        products={products}
        categories={categories}
        wishlistCount={wishlistIds.length}
        cartCount={cartCount}
        onSearchChange={setSearchQuery}
        onSearchSubmit={handleSearchSubmit}
        onSelectProduct={handleOpenProduct}
        onSelectCategory={handleSelectCategory}
        onOpenLocation={() => setLocationModalOpen(true)}
        onNavigateHome={() => setView('home')}
        onOpenWishlist={() => {
          setAccountSection('wishlist');
          setView('account');
        }}
        onOpenCart={() => setView('cart')}
        onOpenAccount={(sec) => {
          setAccountSection(sec);
          setView('account');
        }}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        onClearRecentSearches={() => setRecentSearches([])}
      />

      <DesktopNavigation
        categories={categories}
        activeCategorySlug={view === 'catalog' ? filters.categorySlug : ''}
        onSelectCategory={handleSelectCategory}
        onSelectOffers={() => handleSelectCategory('offers')}
      />

      <MobileHeader
        user={user}
        location={location}
        searchQuery={searchQuery}
        recentSearches={recentSearches}
        products={products}
        categories={categories}
        cartCount={cartCount}
        unreadNotifications={unreadNotifs}
        onSearchChange={setSearchQuery}
        onSearchSubmit={handleSearchSubmit}
        onSelectProduct={handleOpenProduct}
        onSelectCategory={handleSelectCategory}
        onOpenLocation={() => setLocationModalOpen(true)}
        onNavigateHome={() => setView('home')}
        onOpenNotifications={() => {
          setAccountSection('notifications');
          setView('account');
        }}
        onOpenCart={() => setView('cart')}
        onOpenAccount={() => {
          setAccountSection('profile');
          setView('account');
        }}
        onVoiceMessage={(msg) => addToast('Voice Search', msg, 'info')}
      />

      {/* Main Content Container */}
      <main className="flex-1 w-full max-w-[1440px] mx-auto px-3.5 sm:px-6 py-4 sm:py-6">
        {/* HOME VIEW */}
        {view === 'home' && (
          <div className="space-y-7 sm:space-y-9 pb-20 lg:pb-4">
            {/* Hyperlocal Smart Location Banner */}
            <div
              className={`rounded-2xl border px-4 py-3 flex flex-wrap items-center justify-between gap-3 ${
                location.serviceable
                  ? 'bg-white border-slate-200 shadow-xs'
                  : 'bg-rose-50 border-rose-200'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    location.serviceable
                      ? 'bg-[#EAF2FF] text-[#2874F0]'
                      : 'bg-rose-100 text-rose-600'
                  }`}
                >
                  {location.serviceable ? (
                    <MapPin className="w-5 h-5" />
                  ) : (
                    <AlertTriangle className="w-5 h-5" />
                  )}
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs sm:text-sm font-bold text-[#202433]">
                      {location.serviceable
                        ? `Delivering to ${location.city} (${location.pincode})`
                        : `Delivery unavailable in ${location.pincode}`}
                    </span>
                    {location.serviceable && location.estimatedDeliveryText && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 text-[11px] font-bold text-[#16A879]">
                        <Clock className="w-3 h-3" />
                        {location.expressAvailable ? 'Express ' : ''}ETA: {location.estimatedDeliveryText}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                    {location.serviceable
                      ? location.hub
                        ? `Served locally by ${location.hub} · Live inventory checked for your PIN code`
                        : 'PIN code verified for delivery. Reliable express slots shown at checkout.'
                      : 'We do not deliver to this PIN code yet. Please choose a nearby serviceable PIN code.'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {lastDeliveredOrder && (
                  <button
                    type="button"
                    onClick={async () => {
                      const orderItems = await orderService.getOrderItems(lastDeliveredOrder.id);
                      handleReorder(orderItems);
                    }}
                    className="hidden sm:inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 px-3 py-1.5 text-xs font-semibold text-[#202433] cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-[#16A879]" />
                    <span>Quick Reorder ({lastDeliveredOrder.orderNumber})</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setLocationModalOpen(true)}
                  className="rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] px-3.5 py-1.5 text-xs font-bold text-white cursor-pointer"
                >
                  Change Location
                </button>
              </div>
            </div>

            <HeroCarousel onSelectCategory={handleSelectCategory} />

            <CategoryStrip
              categories={categories}
              activeSlug=""
              onSelectCategory={handleSelectCategory}
            />

            {/* Today's Deals + Special Offer Banner Card */}
            <section aria-label="Today's Deals" className="space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h2 className="font-display text-lg sm:text-xl font-bold text-[#202433]">
                    Today&apos;s Deals
                  </h2>
                  <span className="hidden sm:inline text-xs font-semibold text-[#E83E8C]">
                    · Extra Savings Live
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleSelectCategory('offers')}
                  className="text-xs sm:text-sm font-bold text-[#2874F0] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>View All</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
                {todaysDeals.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    isWishlisted={wishlistIds.includes(product.id)}
                    isCompared={compareIds.includes(product.id)}
                    onOpenProduct={handleOpenProduct}
                    onAddToCart={(p) => handleAddToCart(p, 1)}
                    onToggleWishlist={handleToggleWishlist}
                    onToggleCompare={handleToggleCompare}
                  />
                ))}

                {/* Featured Special Offer Tile */}
                <div className="col-span-2 md:col-span-3 lg:col-span-1 rounded-2xl bg-gradient-to-br from-[#FFF2D6] via-[#FFE0A3] to-[#FFC857] p-5 flex flex-col justify-between border border-amber-200/80 shadow-xs">
                  <div>
                    <span className="inline-block rounded-lg bg-[#202433] px-2.5 py-1 text-[11px] font-bold text-[#FFC83D]">
                      Special Offer
                    </span>
                    <h3 className="mt-3 font-display text-lg font-extrabold text-[#202433] leading-snug">
                      Flat 40% OFF on Home Essentials
                    </h3>
                    <p className="mt-1 text-xs text-slate-700">
                      Cookware, laundry &amp; kitchen favorites.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleSelectCategory('home-kitchen')}
                    className="mt-4 w-fit inline-flex items-center gap-1.5 rounded-full bg-[#2874F0] hover:bg-[#1A56C4] px-4 py-2 text-xs font-bold text-white cursor-pointer"
                  >
                    <span>Shop Now</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </section>

            {/* Combo Offers & Value Packs */}
            {comboProducts.length > 0 && (
              <section aria-label="Combo Value Packs" className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <PackagePlus className="w-5 h-5 text-[#7B4DDB]" />
                    <h2 className="font-display text-lg sm:text-xl font-bold text-[#202433]">
                      Combo Offers &amp; Value Packs
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleSelectCategory('combos')}
                    className="text-xs sm:text-sm font-bold text-[#7B4DDB] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>View All Combos</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {comboProducts.map((combo) => (
                    <div
                      key={combo.id}
                      className="rounded-2xl bg-white border border-slate-200 p-4 shadow-xs hover:shadow-md transition-shadow flex flex-col sm:flex-row gap-4"
                    >
                      <button
                        type="button"
                        onClick={() => handleOpenProduct(combo)}
                        className="w-full sm:w-36 h-36 rounded-xl bg-slate-50 border border-slate-100 overflow-hidden shrink-0 cursor-pointer"
                      >
                        <SafeImage
                          src={combo.images[0]}
                          alt={combo.name}
                          className="w-full h-full object-cover"
                        />
                      </button>
                      <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="rounded-md bg-[#F2EDFF] px-2 py-0.5 text-[11px] font-bold text-[#7B4DDB]">
                              COMBO BUNDLE · {combo.discountPercent}% OFF
                            </span>
                            <span className="text-[11px] font-semibold text-[#16A879]">
                              Save ₹{(combo.mrp - combo.price).toLocaleString('en-IN')}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleOpenProduct(combo)}
                            className="mt-1.5 text-left font-display text-base font-bold text-[#202433] hover:text-[#2874F0] cursor-pointer"
                          >
                            {combo.name}
                          </button>
                          {combo.bundleItems && combo.bundleItems.length > 0 && (
                            <div className="mt-2 flex flex-wrap gap-1.5">
                              {combo.bundleItems.map((bi, idx) => (
                                <span
                                  key={idx}
                                  className="rounded-lg bg-slate-100 px-2 py-0.5 text-[11px] text-slate-700"
                                >
                                  {bi}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-3">
                          <div>
                            <span className="text-lg font-extrabold text-[#202433] tabular-nums">
                              ₹{combo.price.toLocaleString('en-IN')}
                            </span>
                            <span className="ml-2 text-xs text-slate-400 line-through tabular-nums">
                              ₹{combo.mrp.toLocaleString('en-IN')}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleOpenProduct(combo)}
                              className="rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-semibold text-[#202433] hover:bg-slate-50 cursor-pointer"
                            >
                              Details
                            </button>
                            <button
                              type="button"
                              onClick={() => handleAddToCart(combo, 1)}
                              className="rounded-xl bg-[#2874F0] hover:bg-[#1A56C4] px-3.5 py-1.5 text-xs font-bold text-white cursor-pointer"
                            >
                              Add Combo
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Colorful Promotional Offer Tiles */}
            <section aria-label="Personalized Offers" className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {offers.slice(0, 3).map((offer) => (
                <button
                  key={offer.id}
                  type="button"
                  onClick={() => handleSelectCategory(offer.categorySlug)}
                  className={`rounded-2xl bg-gradient-to-r ${
                    offer.bgGradient || 'from-[#EAF2FF] to-[#D6E6FF]'
                  } p-5 text-left border border-black/5 hover:-translate-y-0.5 hover:shadow-md transition-all cursor-pointer`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-bold uppercase tracking-wide text-[#202433]/80">
                      {offer.badge}
                    </span>
                    <span className="rounded-lg bg-white/90 px-2.5 py-0.5 text-xs font-extrabold text-[#2874F0]">
                      {offer.discountText}
                    </span>
                  </div>
                  <h3 className="mt-2 font-display text-base font-bold text-[#202433]">{offer.title}</h3>
                  <p className="mt-1 text-xs text-slate-700">{offer.subtitle}</p>
                </button>
              ))}
            </section>

            {/* Recommended For You */}
            {recommendedProducts.length > 0 && (
              <section aria-label="Recommended For You" className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#2874F0]" />
                    <h2 className="font-display text-lg sm:text-xl font-bold text-[#202433]">
                      Recommended For You
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleSelectCategory('all')}
                    className="text-xs sm:text-sm font-bold text-[#2874F0] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>Explore All</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <ResponsiveProductGrid
                  products={recommendedProducts.slice(0, 5)}
                  wishlistIds={wishlistIds}
                  compareIds={compareIds}
                  onOpenProduct={handleOpenProduct}
                  onAddToCart={(p) => handleAddToCart(p, 1)}
                  onToggleWishlist={handleToggleWishlist}
                  onToggleCompare={handleToggleCompare}
                />
              </section>
            )}

            {/* Best Selling Products */}
            <section aria-label="Best Sellers" className="space-y-3.5">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg sm:text-xl font-bold text-[#202433]">
                  Best Selling Products
                </h2>
                <button
                  type="button"
                  onClick={() => handleSelectCategory('all')}
                  className="text-xs sm:text-sm font-bold text-[#2874F0] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>View All</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <ResponsiveProductGrid
                products={bestSellers}
                wishlistIds={wishlistIds}
                compareIds={compareIds}
                loading={catalogLoading}
                onOpenProduct={handleOpenProduct}
                onAddToCart={(p) => handleAddToCart(p, 1)}
                onToggleWishlist={handleToggleWishlist}
                onToggleCompare={handleToggleCompare}
              />
            </section>

            {/* Grocery, Dairy & Daily Essentials */}
            <section aria-label="Grocery, Dairy & Daily Essentials" className="space-y-3.5">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg sm:text-xl font-bold text-[#202433]">
                  Grocery, Dairy &amp; Daily Essentials
                </h2>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => handleSelectCategory('dairy-products')}
                    className="hidden sm:inline text-xs font-bold text-[#2874F0] hover:underline cursor-pointer"
                  >
                    Dairy
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectCategory('daily-essentials')}
                    className="text-xs sm:text-sm font-bold text-[#16A879] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>Shop Essentials</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <ResponsiveProductGrid
                products={groceryAndDairySpecials}
                wishlistIds={wishlistIds}
                compareIds={compareIds}
                onOpenProduct={handleOpenProduct}
                onAddToCart={(p) => handleAddToCart(p, 1)}
                onToggleWishlist={handleToggleWishlist}
                onToggleCompare={handleToggleCompare}
              />
            </section>

            {/* Trending Products */}
            <section aria-label="Trending Products" className="space-y-3.5">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg sm:text-xl font-bold text-[#202433]">
                  Trending Near You
                </h2>
                <button
                  type="button"
                  onClick={() => handleSelectCategory('all')}
                  className="text-xs sm:text-sm font-bold text-[#2874F0] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Explore Catalog</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <ResponsiveProductGrid
                products={trendingProducts}
                wishlistIds={wishlistIds}
                compareIds={compareIds}
                onOpenProduct={handleOpenProduct}
                onAddToCart={(p) => handleAddToCart(p, 1)}
                onToggleWishlist={handleToggleWishlist}
                onToggleCompare={handleToggleCompare}
              />
            </section>

            {/* Recently Viewed */}
            {recentlyViewedProducts.length > 0 && (
              <section aria-label="Recently Viewed" className="space-y-3.5">
                <h2 className="font-display text-lg sm:text-xl font-bold text-[#202433]">
                  Recently Viewed
                </h2>
                <ResponsiveProductGrid
                  products={recentlyViewedProducts}
                  wishlistIds={wishlistIds}
                  compareIds={compareIds}
                  onOpenProduct={handleOpenProduct}
                  onAddToCart={(p) => handleAddToCart(p, 1)}
                  onToggleWishlist={handleToggleWishlist}
                  onToggleCompare={handleToggleCompare}
                />
              </section>
            )}
          </div>
        )}

        {/* CATALOG & SEARCH VIEW */}
        {view === 'catalog' && (
          <div className="space-y-4 pb-20 lg:pb-6">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
              <div>
                <h1 className="font-display text-lg sm:text-xl font-bold text-[#202433]">
                  {searchQuery ? `Search: "${searchQuery}"` : activeCategoryLabel}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                  Showing {filteredProducts.length} verified products
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setMobileFilterOpen(true)}
                  className="lg:hidden inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-[#202433]"
                >
                  <SlidersHorizontal className="w-4 h-4 text-[#2874F0]" />
                  <span>Filter &amp; Sort</span>
                </button>

                <select
                  aria-label="Sort products"
                  value={filters.sortBy}
                  onChange={(e) =>
                    setFilters((f) => ({ ...f, sortBy: e.target.value as FilterState['sortBy'] }))
                  }
                  className="hidden lg:block rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-[#202433] cursor-pointer"
                >
                  <option value="popular">Sort: Popularity</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="discount">Best Discount</option>
                </select>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <DesktopProductFilters
                categories={categories}
                availableBrands={availableBrands}
                filters={filters}
                onChange={setFilters}
                onReset={handleResetFilters}
              />

              <div className="flex-1 min-w-0">
                <ResponsiveProductGrid
                  products={filteredProducts}
                  wishlistIds={wishlistIds}
                  compareIds={compareIds}
                  columnsVariant="catalog"
                  onSelectSuggestedTerm={(term) => handleSearchSubmit(term)}
                  onResetFilters={handleResetFilters}
                  onOpenProduct={handleOpenProduct}
                  onAddToCart={(p) => handleAddToCart(p, 1)}
                  onToggleWishlist={handleToggleWishlist}
                  onToggleCompare={handleToggleCompare}
                />
              </div>
            </div>

            <MobileProductFilters
              isOpen={mobileFilterOpen}
              onClose={() => setMobileFilterOpen(false)}
              categories={categories}
              availableBrands={availableBrands}
              filters={filters}
              onChange={setFilters}
              onReset={handleResetFilters}
            />
          </div>
        )}

        {/* PRODUCT DETAILS VIEW */}
        {view === 'product' && selectedProduct && (
          <ProductDetailsView
            product={products.find((p) => p.id === selectedProduct.id) || selectedProduct}
            allProducts={products}
            recentlyViewedProducts={recentlyViewedProducts}
            coupons={coupons}
            settings={settings}
            user={user}
            location={location}
            wishlistIds={wishlistIds}
            compareIds={compareIds}
            onBack={() => setView('catalog')}
            onOpenLocation={() => setLocationModalOpen(true)}
            onAddToCart={handleAddToCart}
            onBuyNow={handleBuyNow}
            onToggleWishlist={handleToggleWishlist}
            onToggleCompare={handleToggleCompare}
            onOpenProduct={handleOpenProduct}
            onRequireSignIn={handleSignIn}
            onToast={(title, desc, variant) => addToast(title, desc, variant)}
          />
        )}

        {/* CART VIEW */}
        {view === 'cart' && (
          <ResponsiveCart
            items={cart}
            savedForLater={savedForLater}
            coupons={coupons}
            selectedCouponCode={selectedCouponCode}
            settings={settings}
            membershipTier={profile?.membershipTier || 'Basic'}
            location={location}
            suggestedProducts={products.filter(
              (p) => p.inStock && p.stock > 0 && !cart.some((c) => c.productId === p.id)
            )}
            onUpdateQuantity={(productId, qty) => {
              if (qty <= 0) {
                setCart((prev) => prev.filter((i) => i.productId !== productId));
              } else {
                setCart((prev) =>
                  prev.map((i) => (i.productId === productId ? { ...i, quantity: qty } : i))
                );
              }
            }}
            onRemoveItem={(productId) => setCart((prev) => prev.filter((i) => i.productId !== productId))}
            onSaveForLater={handleSaveForLater}
            onMoveSavedToCart={handleMoveSavedToCart}
            onRemoveSaved={handleRemoveSaved}
            onApplyCoupon={setSelectedCouponCode}
            onAddSuggested={(p) => handleAddToCart(p, 1)}
            onOpenLocation={() => setLocationModalOpen(true)}
            onProceedCheckout={() => {
              setView('checkout');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onContinueShopping={() => setView('home')}
          />
        )}

        {/* CHECKOUT VIEW */}
        {view === 'checkout' && (
          <ResponsiveCheckout
            user={user}
            profile={profile}
            privateInfo={privateInfo}
            items={cart}
            allProducts={products}
            addresses={addresses}
            coupons={coupons}
            initialCouponCode={selectedCouponCode}
            settings={settings}
            onRequireSignIn={handleSignIn}
            onOrderSuccess={(order) => {
              setCart([]);
              setSelectedCouponCode('');
              setAccountSection('orders');
              setView('account');
              addToast(
                `Order ${order.orderNumber} Placed`,
                'Order and GST invoice saved locally in Demo Store.'
              );
            }}
            onBackToCart={() => setView('cart')}
            onToast={addToast}
          />
        )}

        {/* ACCOUNT DASHBOARD VIEW */}
        {view === 'account' && authReady && (
          <ResponsiveAccountDashboard
            user={user}
            activeSection={accountSection}
            profile={profile}
            privateInfo={privateInfo}
            addresses={addresses}
            orders={orders}
            invoices={invoices}
            wishlistProducts={wishlistProducts}
            allProducts={products}
            coupons={coupons}
            notifications={notifications}
            rewardTransactions={rewardTransactions}
            tickets={tickets}
            settings={settings}
            onSelectSection={setAccountSection}
            onSignIn={handleSignIn}
            onSignOut={handleSignOut}
            onOpenProduct={handleOpenProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            onToggleWishlist={handleToggleWishlist}
            onReorder={handleReorder}
            onToast={addToast}
          />
        )}
      </main>

      {/* Clean Desktop Footer */}
      <footer className="hidden lg:block bg-white border-t border-slate-200 mt-8">
        <div className="max-w-[1440px] mx-auto px-6 py-8 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-3">
            <span className="font-display font-bold text-sm text-[#2874F0]">
              Business Manager 360
            </span>
            <span>·</span>
            <span>Shopping Super App · Currency INR (₹)</span>
          </div>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => {
                setAccountSection('support');
                setView('account');
              }}
              className="hover:text-[#2874F0] cursor-pointer"
            >
              Customer Support &amp; FAQ
            </button>
            <button
              type="button"
              onClick={() => {
                setAccountSection('orders');
                setView('account');
              }}
              className="hover:text-[#2874F0] cursor-pointer"
            >
              Track Orders
            </button>
            <button
              type="button"
              onClick={() => handleSelectCategory('offers')}
              className="hover:text-[#2874F0] flex items-center gap-1 cursor-pointer"
            >
              <Tag className="w-3.5 h-3.5" /> Offers &amp; Coupons
            </button>
            <PWAInstallButton compact />
          </div>
        </div>
      </footer>

      {/* Floating Compare Pill Bar */}
      {compareProducts.length > 0 && (
        <div className="fixed bottom-18 lg:bottom-6 left-4 z-40">
          <button
            type="button"
            onClick={() => setCompareOpen(true)}
            className="flex items-center gap-2 rounded-full bg-[#202433] text-white px-4 py-2.5 text-xs font-bold shadow-xl hover:bg-slate-800 cursor-pointer"
          >
            <GitCompareArrows className="w-4 h-4 text-[#FFC83D]" />
            <span>Compare ({compareProducts.length}/3)</span>
          </button>
        </div>
      )}

      {/* Mobile Bottom Navigation */}
      <MobileBottomNavigation
        currentView={view}
        accountSection={accountSection}
        wishlistCount={wishlistIds.length}
        onSelectHome={() => {
          setView('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectCategories={() => {
          setView('catalog');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectWishlist={() => {
          setAccountSection('wishlist');
          setView('account');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectOrders={() => {
          setAccountSection('orders');
          setView('account');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectAccount={() => {
          setAccountSection('profile');
          setView('account');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Modals, AI Assistant, Offline & Toasts */}
      <CompareModal
        isOpen={compareOpen}
        onClose={() => setCompareOpen(false)}
        products={compareProducts}
        onRemove={(id) => setCompareIds((prev) => prev.filter((x) => x !== id))}
        onAddToCart={(p) => handleAddToCart(p, 1)}
      />

      <LocationModal
        isOpen={locationModalOpen}
        isFirstOpen={!locationConfirmed}
        onClose={() => {
          setLocationModalOpen(false);
          setLocationConfirmed(true);
          try {
            localStorage.setItem(LOCATION_CONFIRMED_KEY, 'true');
          } catch {
            // ignore
          }
        }}
        currentLocation={location}
        addresses={addresses}
        settings={settings}
        onSelectLocation={(loc) => {
          setLocation(loc);
          setLocationConfirmed(true);
          try {
            localStorage.setItem(LOCATION_CONFIRMED_KEY, 'true');
          } catch {
            // ignore
          }
          addToast(
            loc.serviceable ? 'Delivery location updated' : 'Area currently unserviceable',
            loc.serviceable
              ? `${loc.city} (${loc.pincode})${loc.estimatedDeliveryText ? ` · ETA ${loc.estimatedDeliveryText}` : ''}`
              : `Delivery is not available for PIN code ${loc.pincode} yet.`,
            loc.serviceable ? 'success' : 'warning'
          );
        }}
      />

      <OfflineIndicator />
      <ToastContainer
        toasts={toasts}
        onDismiss={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))}
      />
    </div>
  );
}
