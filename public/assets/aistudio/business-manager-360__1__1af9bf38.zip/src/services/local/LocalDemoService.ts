import {
  DEFAULT_STORE_SETTINGS,
  INITIAL_CATEGORIES,
  INITIAL_COUPONS,
  INITIAL_OFFERS,
  INITIAL_PRODUCTS,
} from '../../data/catalogSeed';
import {
  DEMO_CUSTOMER_USER,
  INITIAL_DEMO_ADDRESSES,
  INITIAL_DEMO_INVOICES,
  INITIAL_DEMO_NOTIFICATIONS,
  INITIAL_DEMO_ORDERS,
  INITIAL_DEMO_ORDER_ITEMS,
  INITIAL_DEMO_PRIVATE_INFO,
  INITIAL_DEMO_PROFILE,
  INITIAL_DEMO_REVIEWS,
  INITIAL_DEMO_REWARDS,
  INITIAL_DEMO_TICKETS,
} from '../../data/demoStoreSeed';
import {
  Address,
  CartItem,
  Category,
  CheckoutValidationResult,
  Coupon,
  CustomerUser,
  Invoice,
  MembershipTier,
  NotificationItem,
  Offer,
  Order,
  OrderItem,
  PincodeServiceabilityResult,
  Product,
  ProductReview,
  ReviewEligibilityResult,
  RewardTransaction,
  ServiceableLocationSuggestion,
  StoreSettings,
  SupportTicket,
  UserPrivateInfo,
  UserProfile,
  WhatsAppVerifyOtpResult,
} from '../../types/store';
import { whatsAppVerificationClient } from '../api/WhatsAppVerificationClient';
import {
  OfflineDatabaseState,
  createSeedDatabaseState,
  getOfflineCart,
  getOfflineSavedForLater,
  getOfflineState,
  setOfflineCart,
  setOfflineSavedForLater,
  setOfflineState,
} from '../../db/offlineDb';
import { enqueueOfflineSyncMutation } from '../../db/syncManager';
import {
  CartService,
  CategoryService,
  CustomerService,
  CustomerWorkspaceSnapshot,
  InventoryAvailabilityService,
  InvoiceService,
  OfferService,
  OrderService,
  PlaceOrderInput,
  ProductSearchFilters,
  ProductService,
  StockAvailabilityResponse,
  StockCheckItem,
  StorefrontServiceRegistry,
} from '../interfaces/ServiceContracts';

interface HubZoneConfig {
  city: string;
  state: string;
  areaName: string;
  hub: string;
  lat: number;
  lng: number;
  expressAvailable: boolean;
  estimatedDeliveryText?: string;
}

const PINCODE_ZONES: Record<string, HubZoneConfig> = {
  '400001': {
    city: 'Mumbai',
    state: 'Maharashtra',
    areaName: 'Marine Lines / Fort',
    hub: 'Mumbai Central Express Hub',
    lat: 18.9388,
    lng: 72.8355,
    expressAvailable: true,
    estimatedDeliveryText: '18–25 mins',
  },
  '400002': {
    city: 'Mumbai',
    state: 'Maharashtra',
    areaName: 'Kalbadevi / Crawford Market',
    hub: 'Mumbai South Hub',
    lat: 18.948,
    lng: 72.831,
    expressAvailable: true,
    estimatedDeliveryText: '20–30 mins',
  },
  '400050': {
    city: 'Mumbai',
    state: 'Maharashtra',
    areaName: 'Bandra West / Pali Hill',
    hub: 'Bandra West Express Hub',
    lat: 19.0596,
    lng: 72.8295,
    expressAvailable: true,
    estimatedDeliveryText: '15–22 mins',
  },
  '400053': {
    city: 'Mumbai',
    state: 'Maharashtra',
    areaName: 'Andheri West / Lokhandwala',
    hub: 'Andheri West Hub',
    lat: 19.1363,
    lng: 72.8277,
    expressAvailable: true,
    estimatedDeliveryText: '22–32 mins',
  },
  '400076': {
    city: 'Mumbai',
    state: 'Maharashtra',
    areaName: 'Powai / Hiranandani',
    hub: 'Powai Express Hub',
    lat: 19.1176,
    lng: 72.906,
    expressAvailable: true,
    estimatedDeliveryText: '20–30 mins',
  },
  '400093': {
    city: 'Mumbai',
    state: 'Maharashtra',
    areaName: 'Andheri East / Chakala',
    hub: 'Andheri East Hub',
    lat: 19.1155,
    lng: 72.8682,
    expressAvailable: true,
    estimatedDeliveryText: '25–35 mins',
  },
  '110001': {
    city: 'New Delhi',
    state: 'Delhi',
    areaName: 'Connaught Place / Janpath',
    hub: 'Delhi Central Express Hub',
    lat: 28.6315,
    lng: 77.2167,
    expressAvailable: true,
    estimatedDeliveryText: '20–30 mins',
  },
  '110016': {
    city: 'New Delhi',
    state: 'Delhi',
    areaName: 'Hauz Khas / Green Park',
    hub: 'South Delhi Hub',
    lat: 28.5494,
    lng: 77.2001,
    expressAvailable: true,
    estimatedDeliveryText: '25–35 mins',
  },
  '560001': {
    city: 'Bengaluru',
    state: 'Karnataka',
    areaName: 'MG Road / Shivajinagar',
    hub: 'Bengaluru Central Express Hub',
    lat: 12.9762,
    lng: 77.6033,
    expressAvailable: true,
    estimatedDeliveryText: '18–25 mins',
  },
  '560034': {
    city: 'Bengaluru',
    state: 'Karnataka',
    areaName: 'Koramangala',
    hub: 'Koramangala Express Hub',
    lat: 12.9352,
    lng: 77.6245,
    expressAvailable: true,
    estimatedDeliveryText: '15–22 mins',
  },
  '411001': {
    city: 'Pune',
    state: 'Maharashtra',
    areaName: 'Camp / MG Road',
    hub: 'Pune Camp Hub',
    lat: 18.5196,
    lng: 73.8794,
    expressAvailable: true,
    estimatedDeliveryText: '25–35 mins',
  },
  '500001': {
    city: 'Hyderabad',
    state: 'Telangana',
    areaName: 'Abids / Koti',
    hub: 'Hyderabad Central Hub',
    lat: 17.3886,
    lng: 78.4751,
    expressAvailable: false,
    estimatedDeliveryText: 'Same-day (2–4 hrs)',
  },
  '600001': {
    city: 'Chennai',
    state: 'Tamil Nadu',
    areaName: 'Parrys / George Town',
    hub: 'Chennai Central Hub',
    lat: 13.0908,
    lng: 80.2856,
    expressAvailable: false,
    estimatedDeliveryText: 'Same-day (2–4 hrs)',
  },
  '700001': {
    city: 'Kolkata',
    state: 'West Bengal',
    areaName: 'BBD Bagh / Esplanade',
    hub: 'Kolkata Central Hub',
    lat: 22.5726,
    lng: 88.352,
    expressAvailable: false,
    estimatedDeliveryText: 'Same-day (2–4 hrs)',
  },
  '380001': {
    city: 'Ahmedabad',
    state: 'Gujarat',
    areaName: 'Lal Darwaja / Navrangpura',
    hub: 'Ahmedabad Hub',
    lat: 23.0258,
    lng: 72.5873,
    expressAvailable: false,
    estimatedDeliveryText: 'Same-day (2–4 hrs)',
  },
  '302001': {
    city: 'Jaipur',
    state: 'Rajasthan',
    areaName: 'MI Road / Johari Bazaar',
    hub: 'Jaipur Hub',
    lat: 26.9124,
    lng: 75.7873,
    expressAvailable: false,
    estimatedDeliveryText: 'Next-day delivery',
  },
};

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const TIER_RANK: Record<MembershipTier, number> = {
  Basic: 0,
  Silver: 1,
  Gold: 2,
  Premium: 3,
};

type LocalDemoDatabaseState = OfflineDatabaseState;

const listeners = new Set<() => void>();

export function notifyLocalStoreListeners() {
  listeners.forEach((fn) => {
    try {
      fn();
    } catch {
      // ignore subscriber errors
    }
  });
}

function readState(): LocalDemoDatabaseState {
  return getOfflineState();
}

function writeState(next: LocalDemoDatabaseState): void {
  setOfflineState(next);
  notifyLocalStoreListeners();
}

const localProductService: ProductService = {
  async getProducts() {
    return readState().products.filter((p) => p.active !== false);
  },

  async getProductById(productId) {
    return readState().products.find((p) => p.id === productId) || null;
  },

  async searchProducts(filters: ProductSearchFilters) {
    const state = readState();
    const q = (filters.query || '').trim().toLowerCase();
    const list = state.products.filter((p) => {
      if (p.active === false) return false;
      if (filters.categorySlug && filters.categorySlug !== 'all' && filters.categorySlug !== 'offers') {
        const cat = state.categories.find((c) => c.slug === filters.categorySlug);
        if (cat && p.categoryId !== cat.id) return false;
      }
      if (filters.categorySlug === 'offers' && p.discountPercent < 20) return false;
      if (typeof filters.maxPrice === 'number' && p.price > filters.maxPrice) return false;
      if (filters.brands && filters.brands.length > 0 && !filters.brands.includes(p.brand)) return false;
      if (typeof filters.minDiscount === 'number' && p.discountPercent < filters.minDiscount) return false;
      if (filters.inStockOnly && (!p.inStock || p.stock <= 0)) return false;
      if (q) {
        const hay = `${p.name} ${p.brand} ${p.categoryName} ${(p.tags || []).join(' ')}`.toLowerCase();
        const tokens = q.split(/\s+/);
        if (!tokens.every((t) => hay.includes(t))) return false;
      }
      return true;
    });

    if (filters.sortBy === 'price-asc') return [...list].sort((a, b) => a.price - b.price);
    if (filters.sortBy === 'price-desc') return [...list].sort((a, b) => b.price - a.price);
    if (filters.sortBy === 'discount') return [...list].sort((a, b) => b.discountPercent - a.discountPercent);
    return [...list].sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
  },

  async getProductReviews(productId) {
    return readState().reviews.filter((r) => r.productId === productId);
  },

  async getReviewEligibility(userId, productId): Promise<ReviewEligibilityResult> {
    if (!userId) {
      return {
        canSubmit: false,
        hasVerifiedPurchase: false,
        alreadyReviewed: false,
        reason: 'Please sign in to submit a product review.',
      };
    }

    const state = readState();
    const userDeliveredOrderIds = new Set(
      state.orders
        .filter((o) => o.userId === userId && o.status === 'Delivered')
        .map((o) => o.id)
    );

    const eligibleOrderItems = state.orderItems.filter(
      (oi) =>
        oi.userId === userId &&
        oi.productId === productId &&
        userDeliveredOrderIds.has(oi.orderId)
    );

    const existingReviewsForProduct = state.reviews.filter(
      (r) => r.productId === productId && r.userId === userId
    );

    if (eligibleOrderItems.length > 0) {
      const reviewedOrderIds = new Set(existingReviewsForProduct.map((r) => r.orderId).filter(Boolean));
      const unreviewedItem = eligibleOrderItems.find((oi) => !reviewedOrderIds.has(oi.orderId));

      if (!unreviewedItem && existingReviewsForProduct.length > 0) {
        return {
          canSubmit: false,
          hasVerifiedPurchase: true,
          alreadyReviewed: true,
          reason: 'You have already submitted a verified review for this purchase.',
        };
      }

      return {
        canSubmit: true,
        hasVerifiedPurchase: true,
        eligibleOrderId: unreviewedItem?.orderId,
        alreadyReviewed: false,
      };
    }

    if (existingReviewsForProduct.length > 0) {
      return {
        canSubmit: false,
        hasVerifiedPurchase: false,
        alreadyReviewed: true,
        reason: 'You have already reviewed this product.',
      };
    }

    return {
      canSubmit: true,
      hasVerifiedPurchase: false,
      alreadyReviewed: false,
    };
  },

  async addProductReview(review) {
    const state = readState();
    const eligibility = await localProductService.getReviewEligibility(review.userId, review.productId);
    if (!eligibility.canSubmit) {
      throw new Error(eligibility.reason || 'Duplicate review is not allowed for this purchase.');
    }

    const created: ProductReview = {
      ...review,
      id: `rev_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      orderId: eligibility.hasVerifiedPurchase ? eligibility.eligibleOrderId : undefined,
      // Verified Purchase label ONLY when backed by a genuine delivered order
      verifiedPurchase: eligibility.hasVerifiedPurchase,
      helpfulCount: 0,
      helpfulUserIds: [],
      reportedByUserIds: [],
      createdAt: new Date().toISOString(),
    };
    state.reviews = [created, ...state.reviews];
    writeState(state);
    enqueueOfflineSyncMutation(
      'review',
      created.id,
      'upsert',
      created as unknown as Record<string, unknown>,
      created.createdAt
    );
    return created;
  },

  async toggleReviewHelpful(reviewId, userId) {
    const state = readState();
    let updated: ProductReview | null = null;
    state.reviews = state.reviews.map((r) => {
      if (r.id !== reviewId) return r;
      const voters = r.helpfulUserIds || [];
      const alreadyVoted = voters.includes(userId);
      const nextVoters = alreadyVoted ? voters.filter((id) => id !== userId) : [...voters, userId];
      const baseCount = r.helpfulCount ?? 0;
      updated = {
        ...r,
        helpfulUserIds: nextVoters,
        helpfulCount: Math.max(0, alreadyVoted ? baseCount - 1 : baseCount + 1),
      };
      return updated;
    });
    if (!updated) throw new Error('Review not found.');
    writeState(state);
    enqueueOfflineSyncMutation(
      'review',
      reviewId,
      'upsert',
      updated as unknown as Record<string, unknown>,
      new Date().toISOString()
    );
    return updated;
  },

  async reportReview(reviewId, userId, reason) {
    const state = readState();
    let updated: ProductReview | null = null;
    state.reviews = state.reviews.map((r) => {
      if (r.id !== reviewId) return r;
      const reporters = r.reportedByUserIds || [];
      if (reporters.includes(userId)) {
        updated = r;
        return r;
      }
      updated = {
        ...r,
        reportedByUserIds: [...reporters, userId],
        lastReportReason: reason,
      };
      return updated;
    });
    if (!updated) throw new Error('Review not found.');
    writeState(state);
    enqueueOfflineSyncMutation(
      'review',
      reviewId,
      'upsert',
      updated as unknown as Record<string, unknown>,
      new Date().toISOString()
    );
    return updated;
  },

  async getCustomersAlsoBought(productId) {
    const state = readState();
    const activeProducts = state.products.filter((p) => p.active !== false && p.id !== productId);
    const ordersWithProduct = new Set(
      state.orderItems.filter((oi) => oi.productId === productId).map((oi) => oi.orderId)
    );

    const coCounts = new Map<string, number>();
    for (const oi of state.orderItems) {
      if (oi.productId !== productId && ordersWithProduct.has(oi.orderId)) {
        coCounts.set(oi.productId, (coCounts.get(oi.productId) || 0) + oi.quantity);
      }
    }

    const fromOrders = Array.from(coCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([id]) => activeProducts.find((p) => p.id === id))
      .filter((p): p is Product => Boolean(p));

    const target = state.products.find((p) => p.id === productId);
    const complementary = activeProducts.filter(
      (p) => !fromOrders.some((fo) => fo.id === p.id) && (target ? p.categoryId !== target.categoryId : true)
    );

    return [...fromOrders, ...complementary].slice(0, 4);
  },

  async getRecommendedProducts(userId) {
    const state = readState();
    const activeProducts = state.products.filter((p) => p.active !== false);
    if (!userId) {
      return activeProducts.filter((p) => p.isBestSeller || p.isTrending).slice(0, 5);
    }

    const affinityCategoryIds = new Set<string>();
    const preferredIds = [...state.wishlistIds, ...state.recentlyViewedIds];
    state.orderItems
      .filter((oi) => oi.userId === userId)
      .forEach((oi) => preferredIds.push(oi.productId));

    preferredIds.forEach((pid) => {
      const prod = activeProducts.find((p) => p.id === pid);
      if (prod) affinityCategoryIds.add(prod.categoryId);
    });

    const scored = activeProducts.map((p) => {
      let score = 0;
      if (affinityCategoryIds.has(p.categoryId)) score += 3;
      if (state.wishlistIds.includes(p.id)) score += 1;
      if (p.isBestSeller) score += 1;
      if (p.isTrending) score += 1;
      return { product: p, score };
    });

    return scored
      .sort((a, b) => b.score - a.score)
      .map((s) => s.product)
      .slice(0, 5);
  },
};

const localCategoryService: CategoryService = {
  async getCategories() {
    return readState()
      .categories.filter((c) => c.active !== false)
      .sort((a, b) => (a.sortOrder ?? 99) - (b.sortOrder ?? 99));
  },

  async getCategoryBySlug(slug) {
    return readState().categories.find((c) => c.slug === slug) || null;
  },
};

const localInventoryService: InventoryAvailabilityService = {
  async checkStockAvailability(productId, requestedQty) {
    const product = readState().products.find((p) => p.id === productId);
    if (!product || !product.inStock) {
      return { available: false, stock: 0 };
    }
    return {
      available: product.stock >= requestedQty,
      stock: product.stock,
    };
  },

  async checkCartStock(items: StockCheckItem[]): Promise<StockAvailabilityResponse> {
    const products = readState().products;
    const unavailableItems: { productId: string; requested: number; available: number }[] = [];
    for (const item of items) {
      const prod = products.find((p) => p.id === item.productId);
      const stock = prod && prod.inStock ? prod.stock : 0;
      if (!prod || stock < item.quantity) {
        unavailableItems.push({
          productId: item.productId,
          requested: item.quantity,
          available: stock,
        });
      }
    }
    return {
      allAvailable: unavailableItems.length === 0,
      unavailableItems,
    };
  },

  async checkPincodeServiceability(pincodeInput): Promise<PincodeServiceabilityResult> {
    const pincode = pincodeInput.trim();
    const settings = readState().settings;
    if (!/^\d{6}$/.test(pincode)) {
      return {
        serviceable: false,
        pincode,
        message: 'Please enter a valid 6-digit Indian pincode.',
      };
    }

    const isConfigured = settings.serviceablePincodes.includes(pincode);
    const knownZone = PINCODE_ZONES[pincode];

    if (!isConfigured && !knownZone) {
      return {
        serviceable: false,
        pincode,
        message: `Delivery is not yet available in pincode ${pincode}. Please choose a serviceable area or PIN code.`,
      };
    }

    return {
      serviceable: true,
      pincode,
      city: knownZone?.city || 'Verified Service Area',
      state: knownZone?.state || 'India',
      areaName: knownZone?.areaName,
      hub: knownZone?.hub || 'Business Manager 360 Fulfillment Center',
      expressAvailable: knownZone?.expressAvailable ?? false,
      // Only expose estimatedDeliveryText when reliable hub timing data exists
      estimatedDeliveryText: knownZone?.estimatedDeliveryText,
      message: knownZone?.estimatedDeliveryText
        ? `Delivery available to ${knownZone.areaName} (${pincode}) · Est. ${knownZone.estimatedDeliveryText}.`
        : `Delivery available to ${knownZone ? `${knownZone.city} (${pincode})` : pincode}.`,
    };
  },

  async searchServiceableLocations(query: string): Promise<ServiceableLocationSuggestion[]> {
    const q = query.trim().toLowerCase();
    const entries = Object.entries(PINCODE_ZONES).map(([pincode, z]) => ({
      pincode,
      city: z.city,
      state: z.state,
      areaName: z.areaName,
      hub: z.hub,
      expressAvailable: z.expressAvailable,
      estimatedDeliveryText: z.estimatedDeliveryText,
    }));
    if (!q) return entries;
    return entries.filter(
      (item) =>
        item.pincode.includes(q) ||
        item.city.toLowerCase().includes(q) ||
        item.state.toLowerCase().includes(q) ||
        item.areaName.toLowerCase().includes(q) ||
        item.hub.toLowerCase().includes(q)
    );
  },

  async detectNearestLocation(lat: number, lng: number): Promise<PincodeServiceabilityResult> {
    let bestPincode = '';
    let bestZone: HubZoneConfig | null = null;
    let minDistanceKm = Infinity;

    for (const [pin, zone] of Object.entries(PINCODE_ZONES)) {
      const dist = haversineKm(lat, lng, zone.lat, zone.lng);
      if (dist < minDistanceKm) {
        minDistanceKm = dist;
        bestPincode = pin;
        bestZone = zone;
      }
    }

    if (!bestZone || minDistanceKm > 35) {
      return {
        serviceable: false,
        pincode: bestPincode || '',
        message:
          'Your detected GPS location is outside our current hyperlocal delivery zones. Please enter a serviceable PIN code manually.',
      };
    }

    return {
      serviceable: true,
      pincode: bestPincode,
      city: bestZone.city,
      state: bestZone.state,
      areaName: bestZone.areaName,
      hub: bestZone.hub,
      expressAvailable: bestZone.expressAvailable,
      estimatedDeliveryText: bestZone.estimatedDeliveryText,
      message: `Detected ${bestZone.areaName}, ${bestZone.city} (${bestPincode}) · Est. ${
        bestZone.estimatedDeliveryText || 'Standard Delivery'
      }.`,
    };
  },
};

const localOfferService: OfferService = {
  async getOffers() {
    return readState().offers.filter((o) => o.active !== false);
  },

  async getCoupons() {
    return readState().coupons.filter((c) => c.active !== false);
  },

  async validateCoupon({ code, subtotal, membershipTier }) {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) return { valid: false, discount: 0, message: '' };
    const coupon = readState().coupons.find((c) => c.code === cleanCode);
    if (!coupon || !coupon.active) {
      return { valid: false, discount: 0, message: `Coupon ${cleanCode} is invalid or inactive.` };
    }
    const minTier = TIER_RANK[coupon.minMembership || 'Basic'] ?? 0;
    const userTier = TIER_RANK[membershipTier] ?? 0;
    if (userTier < minTier) {
      return {
        valid: false,
        discount: 0,
        message: `Coupon ${coupon.code} requires ${coupon.minMembership} membership or higher.`,
      };
    }
    if (subtotal < coupon.minOrderAmount) {
      return {
        valid: false,
        discount: 0,
        message: `Add ₹${Math.ceil(coupon.minOrderAmount - subtotal)} more to use ${coupon.code}.`,
      };
    }
    let discount =
      coupon.discountType === 'percent'
        ? (subtotal * coupon.discountValue) / 100
        : coupon.discountValue;
    if (coupon.maxDiscount) {
      discount = Math.min(discount, coupon.maxDiscount);
    }
    discount = Number(Math.min(subtotal, Math.max(0, discount)).toFixed(2));
    return {
      valid: true,
      discount,
      message: `Coupon ${coupon.code} applied (-₹${discount}).`,
    };
  },

  async getStoreSettings() {
    return readState().settings;
  },
};

const localCartService: CartService = {
  getCart() {
    return getOfflineCart();
  },

  saveCart(items) {
    const current = getOfflineCart();
    if (JSON.stringify(current) === JSON.stringify(items)) return;
    setOfflineCart(items);
    enqueueOfflineSyncMutation(
      'cart',
      'active',
      'upsert',
      { items },
      new Date().toISOString()
    );
  },

  clearCart() {
    if (getOfflineCart().length === 0) return;
    setOfflineCart([]);
    enqueueOfflineSyncMutation(
      'cart',
      'active',
      'upsert',
      { items: [] },
      new Date().toISOString()
    );
  },

  getSavedForLater() {
    return getOfflineSavedForLater();
  },

  saveSavedForLater(items) {
    const current = getOfflineSavedForLater();
    if (JSON.stringify(current) === JSON.stringify(items)) return;
    setOfflineSavedForLater(items);
    enqueueOfflineSyncMutation(
      'savedForLater',
      'active',
      'upsert',
      { items },
      new Date().toISOString()
    );
  },

  async calculateCheckoutTotals({
    items,
    couponCode,
    membershipTier,
    availableRewardPoints,
    useRewardPoints,
  }): Promise<CheckoutValidationResult> {
    if (!items || items.length === 0) {
      return {
        valid: false,
        subtotal: 0,
        mrpTotal: 0,
        catalogSavings: 0,
        couponDiscount: 0,
        approvedRewardPoints: 0,
        maxRedeemablePoints: 0,
        rewardDiscount: 0,
        totalDiscount: 0,
        gstAmount: 0,
        deliveryCharge: 0,
        totalAmount: 0,
        estimatedEarnedPoints: 0,
        error: 'Cart is empty.',
      };
    }

    const state = readState();
    let subtotal = 0;
    let mrpTotal = 0;
    let gstAmount = 0;

    for (const item of items) {
      const prod = state.products.find((p) => p.id === item.productId);
      if (!prod) {
        return {
          valid: false,
          subtotal: 0,
          mrpTotal: 0,
          catalogSavings: 0,
          couponDiscount: 0,
          approvedRewardPoints: 0,
          maxRedeemablePoints: 0,
          rewardDiscount: 0,
          totalDiscount: 0,
          gstAmount: 0,
          deliveryCharge: 0,
          totalAmount: 0,
          estimatedEarnedPoints: 0,
          error: `Product ${item.name} is unavailable.`,
        };
      }
      if (!prod.inStock || prod.stock < item.quantity) {
        return {
          valid: false,
          subtotal: 0,
          mrpTotal: 0,
          catalogSavings: 0,
          couponDiscount: 0,
          approvedRewardPoints: 0,
          maxRedeemablePoints: 0,
          rewardDiscount: 0,
          totalDiscount: 0,
          gstAmount: 0,
          deliveryCharge: 0,
          totalAmount: 0,
          estimatedEarnedPoints: 0,
          error: `Insufficient stock for ${prod.name}. Available: ${prod.stock}.`,
        };
      }

      const lineTotal = item.price * item.quantity;
      subtotal += lineTotal;
      mrpTotal += item.mrp * item.quantity;
      if (prod.gstPercent > 0) {
        gstAmount += lineTotal - lineTotal / (1 + prod.gstPercent / 100);
      }
    }

    subtotal = Number(subtotal.toFixed(2));
    mrpTotal = Number(mrpTotal.toFixed(2));
    gstAmount = Number(gstAmount.toFixed(2));

    let couponDiscount = 0;
    let couponMessage = '';
    if (couponCode && couponCode.trim()) {
      const couponResult = await localOfferService.validateCoupon({
        code: couponCode,
        subtotal,
        membershipTier,
      });
      couponDiscount = couponResult.discount;
      couponMessage = couponResult.message;
    }

    const settings = state.settings;
    const pointValueInr = settings.pointValueInr ?? 1;
    const maxRedeemPercent = settings.maxRedeemPercent ?? 20;
    const maxRedeemValue = ((subtotal - couponDiscount) * maxRedeemPercent) / 100;
    const maxRedeemablePoints = Math.max(
      0,
      Math.min(Math.floor(availableRewardPoints), Math.floor(maxRedeemValue / pointValueInr))
    );
    const approvedRewardPoints = useRewardPoints ? maxRedeemablePoints : 0;
    const rewardDiscount = Number((approvedRewardPoints * pointValueInr).toFixed(2));

    const isFreeTier = membershipTier === 'Gold' || membershipTier === 'Premium';
    const deliveryCharge = isFreeTier || subtotal >= settings.freeDeliveryThreshold ? 0 : settings.deliveryFee;

    const totalDiscount = Number((couponDiscount + rewardDiscount).toFixed(2));
    const totalAmount = Number(Math.max(0, subtotal - totalDiscount + deliveryCharge).toFixed(2));

    const tierMultiplier =
      membershipTier === 'Premium' ? 3 : membershipTier === 'Gold' ? 2 : membershipTier === 'Silver' ? 1.5 : 1;
    const estimatedEarnedPoints = Math.max(1, Math.round(subtotal * settings.rewardsEarnRate * tierMultiplier));

    return {
      valid: true,
      subtotal,
      mrpTotal,
      catalogSavings: Number(Math.max(0, mrpTotal - subtotal).toFixed(2)),
      couponDiscount,
      couponMessage,
      approvedRewardPoints,
      maxRedeemablePoints,
      rewardDiscount,
      totalDiscount,
      gstAmount,
      deliveryCharge,
      totalAmount,
      estimatedEarnedPoints,
    };
  },
};

const localOrderService: OrderService = {
  async getOrders(userId) {
    return readState().orders.filter((o) => o.userId === userId);
  },

  async getOrderItems(orderId) {
    return readState().orderItems.filter((oi) => oi.orderId === orderId);
  },

  async placeOrder(input: PlaceOrderInput): Promise<Order> {
    const state = readState();
    const nowIso = new Date().toISOString();

    for (const item of input.items) {
      const prod = state.products.find((p) => p.id === item.productId);
      if (!prod || prod.stock < item.quantity) {
        throw new Error(`Insufficient stock for ${item.name}. Available: ${prod?.stock ?? 0}`);
      }
      prod.stock = Math.max(0, prod.stock - item.quantity);
      prod.inStock = prod.stock > 0;
      prod.updatedAt = nowIso;
    }

    const orderId = `ord_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const orderNumber = `BM360-${new Date().getFullYear()}-${String(Math.floor(1000 + Math.random() * 9000))}`;
    const shippingSummary = `${input.address.line1}${
      input.address.line2 ? `, ${input.address.line2}` : ''
    }, ${input.address.city}, ${input.address.state} - ${input.address.pincode}`;

    const newOrder: Order = {
      id: orderId,
      orderNumber,
      userId: input.userId,
      customerName: input.customerName,
      customerPhone: input.customerPhone,
      shippingSummary,
      pincode: input.address.pincode,
      deliverySlot: input.deliverySlot,
      deliveryInstructions: input.deliveryInstructions,
      paymentMethod: input.paymentMethod,
      paymentStatus: 'Pending',
      subtotal: input.subtotal,
      discountAmount: input.discountAmount,
      couponCode: input.couponCode || undefined,
      rewardPointsUsed: input.rewardPointsUsed,
      rewardDiscount: input.rewardDiscount,
      gstAmount: input.gstAmount,
      deliveryCharge: input.deliveryCharge,
      totalAmount: input.totalAmount,
      status: 'Order Placed',
      timeline: [{ status: 'Order Placed', label: 'Order Placed', timestamp: nowIso }],
      itemCount: input.items.reduce((sum, i) => sum + i.quantity, 0),
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    const newOrderItems: OrderItem[] = input.items.map((item, idx) => ({
      id: `${orderId}_item_${idx + 1}`,
      orderId,
      userId: input.userId,
      productId: item.productId,
      productName: item.name,
      brand: item.brand,
      unit: item.unit,
      quantity: item.quantity,
      mrp: item.mrp,
      unitPrice: item.price,
      gstPercent: item.gstPercent,
      lineTotal: Number((item.price * item.quantity).toFixed(2)),
      image: item.image,
    }));

    const invoice: Invoice = {
      id: `inv_${orderId}`,
      invoiceNumber: `INV-${orderNumber}`,
      orderId,
      userId: input.userId,
      customerName: input.customerName,
      customerAddress: shippingSummary,
      itemsCount: newOrder.itemCount,
      subtotal: input.subtotal,
      gstAmount: input.gstAmount,
      discountAmount: input.discountAmount,
      deliveryCharge: input.deliveryCharge,
      grandTotal: input.totalAmount,
      issuedAt: nowIso,
    };

    if (input.rewardPointsUsed > 0) {
      state.profile.rewardPoints = Math.max(0, state.profile.rewardPoints - input.rewardPointsUsed);
      state.rewardTransactions = [
        {
          id: `rew_redeem_${Date.now()}`,
          userId: input.userId,
          points: input.rewardPointsUsed,
          type: 'redeemed',
          description: `Redeemed on Order ${orderNumber}`,
          orderId,
          createdAt: nowIso,
        },
        ...state.rewardTransactions,
      ];
    }

    state.notifications = [
      {
        id: `notif_${Date.now()}`,
        userId: input.userId,
        title: `Order ${orderNumber} Placed`,
        message: `Your order of ₹${input.totalAmount.toLocaleString('en-IN')} has been confirmed in local demo store.`,
        type: 'order',
        read: false,
        orderId,
        createdAt: nowIso,
      },
      ...state.notifications,
    ];

    state.orders = [newOrder, ...state.orders];
    state.orderItems = [...newOrderItems, ...state.orderItems];
    state.invoices = [invoice, ...state.invoices];
    writeState(state);
    enqueueOfflineSyncMutation(
      'order',
      newOrder.id,
      'upsert',
      newOrder as unknown as Record<string, unknown>,
      newOrder.updatedAt || nowIso
    );
    return newOrder;
  },

  async cancelOrder(orderId, reason) {
    const state = readState();
    const order = state.orders.find((o) => o.id === orderId);
    if (!order) throw new Error('Order not found.');
    if (order.status !== 'Order Placed' && order.status !== 'Accepted') {
      throw new Error('Order can no longer be cancelled at this stage.');
    }

    const nowIso = new Date().toISOString();
    order.status = 'Cancelled';
    order.cancelReason = reason;
    order.updatedAt = nowIso;
    order.timeline = [
      ...(order.timeline || []),
      { status: 'Cancelled', label: 'Order Cancelled', timestamp: nowIso, note: reason },
    ];

    // Restore product stock locally
    const items = state.orderItems.filter((oi) => oi.orderId === orderId);
    for (const oi of items) {
      const prod = state.products.find((p) => p.id === oi.productId);
      if (prod) {
        prod.stock += oi.quantity;
        prod.inStock = prod.stock > 0;
      }
    }

    writeState(state);
    enqueueOfflineSyncMutation(
      'order',
      order.id,
      'upsert',
      order as unknown as Record<string, unknown>,
      nowIso
    );
    return order;
  },

  async requestReturn(orderId, reason) {
    const state = readState();
    const order = state.orders.find((o) => o.id === orderId);
    if (!order) throw new Error('Order not found.');
    if (order.status !== 'Delivered') {
      throw new Error('Return can only be requested for delivered orders.');
    }
    const nowIso = new Date().toISOString();
    order.status = 'Return Requested';
    order.returnReason = reason;
    order.updatedAt = nowIso;
    order.timeline = [
      ...(order.timeline || []),
      { status: 'Return Requested', label: 'Return Requested', timestamp: nowIso, note: reason },
    ];
    writeState(state);
    enqueueOfflineSyncMutation(
      'order',
      order.id,
      'upsert',
      order as unknown as Record<string, unknown>,
      nowIso
    );
    return order;
  },
};

const localCustomerService: CustomerService = {
  async getCurrentCustomer() {
    return readState().signedInUser;
  },

  async signInDemoCustomer() {
    const state = readState();
    const user: CustomerUser = {
      ...DEMO_CUSTOMER_USER,
      displayName: state.profile.displayName || DEMO_CUSTOMER_USER.displayName,
      email: state.privateInfo.email || DEMO_CUSTOMER_USER.email,
      phone: state.privateInfo.phone || DEMO_CUSTOMER_USER.phone,
    };
    state.signedInUser = user;
    writeState(state);
    return user;
  },

  async signOutCustomer() {
    const state = readState();
    state.signedInUser = null;
    writeState(state);
  },

  async getWorkspaceSnapshot(userId): Promise<CustomerWorkspaceSnapshot> {
    const state = readState();
    return {
      user: state.signedInUser,
      profile: state.profile,
      privateInfo: state.privateInfo,
      addresses: state.addresses.filter((a) => a.userId === userId),
      wishlistIds: state.wishlistIds,
      recentlyViewedIds: state.recentlyViewedIds,
      rewardTransactions: state.rewardTransactions.filter((r) => r.userId === userId),
      notifications: state.notifications.filter((n) => n.userId === userId),
      tickets: state.tickets.filter((t) => t.userId === userId),
    };
  },

  async updateCustomerProfile(userId, displayName, privateUpdates) {
    const state = readState();
    const nowIso = new Date().toISOString();
    const normalizeDigits = (val?: string) => (val || '').replace(/\D/g, '').slice(-10);
    const phoneChanged =
      typeof privateUpdates.phone === 'string' &&
      normalizeDigits(privateUpdates.phone) !== normalizeDigits(state.privateInfo.phone);

    state.profile = {
      ...state.profile,
      uid: userId,
      displayName,
      updatedAt: nowIso,
    };
    state.privateInfo = {
      ...state.privateInfo,
      ...privateUpdates,
      uid: userId,
      // Only backend WhatsApp OTP verification can set phoneVerified = true; editing mobile resets it
      phoneVerified: phoneChanged ? false : Boolean(state.privateInfo.phoneVerified),
      phoneVerifiedAt: phoneChanged ? undefined : state.privateInfo.phoneVerifiedAt,
      phoneVerificationMethod: phoneChanged ? undefined : state.privateInfo.phoneVerificationMethod,
      updatedAt: nowIso,
    };
    if (state.signedInUser) {
      state.signedInUser = {
        ...state.signedInUser,
        displayName,
        phone: privateUpdates.phone ?? state.signedInUser.phone,
        phoneVerified: state.privateInfo.phoneVerified,
      };
    }
    writeState(state);
    enqueueOfflineSyncMutation(
      'profile',
      userId,
      'upsert',
      state.profile as unknown as Record<string, unknown>,
      nowIso
    );
  },

  async markPhoneVerified(userId: string, receipt: WhatsAppVerifyOtpResult) {
    if (!receipt.verified || receipt.method !== 'WHATSAPP_OTP' || !receipt.verificationId) {
      throw new Error('Mobile number can only be marked verified after successful backend WhatsApp OTP verification.');
    }
    const state = readState();
    const verifiedAt = receipt.verifiedAt || new Date().toISOString();
    const formattedPhone = receipt.formattedDisplay || receipt.e164 || state.privateInfo.phone;

    state.privateInfo = {
      ...state.privateInfo,
      uid: userId,
      phone: formattedPhone,
      phoneVerified: true,
      phoneVerifiedAt: verifiedAt,
      phoneVerificationMethod: 'WHATSAPP_OTP',
      updatedAt: verifiedAt,
    };
    if (state.signedInUser) {
      state.signedInUser = {
        ...state.signedInUser,
        phone: formattedPhone,
        phoneVerified: true,
      };
    }
    writeState(state);
    enqueueOfflineSyncMutation(
      'privateInfo',
      userId,
      'upsert',
      state.privateInfo as unknown as Record<string, unknown>,
      verifiedAt
    );
  },

  async updateMembershipTier(userId, tier) {
    const state = readState();
    const nowIso = new Date().toISOString();
    state.profile = {
      ...state.profile,
      uid: userId,
      membershipTier: tier,
      updatedAt: nowIso,
    };
    writeState(state);
    enqueueOfflineSyncMutation(
      'profile',
      userId,
      'upsert',
      state.profile as unknown as Record<string, unknown>,
      nowIso
    );
    return state.profile;
  },

  async getAddresses(userId) {
    return readState().addresses.filter((a) => a.userId === userId);
  },

  async saveAddress(userId, address) {
    const state = readState();
    const nowIso = new Date().toISOString();
    const existingIdx = state.addresses.findIndex((a) => a.id === address.id);
    const saved: Address = {
      ...address,
      userId,
      updatedAt: nowIso,
    };
    if (existingIdx >= 0) {
      state.addresses[existingIdx] = saved;
    } else {
      state.addresses = [saved, ...state.addresses];
    }
    writeState(state);
    enqueueOfflineSyncMutation(
      'address',
      saved.id,
      'upsert',
      saved as unknown as Record<string, unknown>,
      nowIso
    );
    return saved;
  },

  async deleteAddress(_userId, addressId) {
    const state = readState();
    const nowIso = new Date().toISOString();
    state.addresses = state.addresses.filter((a) => a.id !== addressId);
    writeState(state);
    enqueueOfflineSyncMutation('address', addressId, 'delete', null, nowIso);
  },

  async toggleWishlist(_userId, productId) {
    const state = readState();
    const exists = state.wishlistIds.includes(productId);
    state.wishlistIds = exists
      ? state.wishlistIds.filter((id) => id !== productId)
      : [productId, ...state.wishlistIds];
    writeState(state);
    enqueueOfflineSyncMutation(
      'wishlist',
      'active',
      'upsert',
      { wishlistIds: state.wishlistIds },
      new Date().toISOString()
    );
    return state.wishlistIds;
  },

  async recordRecentlyViewed(_userId, productId) {
    const state = readState();
    state.recentlyViewedIds = [productId, ...state.recentlyViewedIds.filter((id) => id !== productId)].slice(0, 10);
    writeState(state);
    return state.recentlyViewedIds;
  },

  async markNotificationRead(_userId, notificationId) {
    const state = readState();
    state.notifications = state.notifications.map((n) =>
      n.id === notificationId ? { ...n, read: true } : n
    );
    writeState(state);
    enqueueOfflineSyncMutation(
      'notification',
      notificationId,
      'upsert',
      { id: notificationId, read: true },
      new Date().toISOString()
    );
  },

  async createSupportTicket(ticket) {
    const state = readState();
    const nowIso = new Date().toISOString();
    const created: SupportTicket = {
      ...ticket,
      id: `tkt_${Date.now()}`,
      status: 'Open',
      createdAt: nowIso,
      updatedAt: nowIso,
    };
    state.tickets = [created, ...state.tickets];
    writeState(state);
    enqueueOfflineSyncMutation(
      'ticket',
      created.id,
      'upsert',
      created as unknown as Record<string, unknown>,
      nowIso
    );
    return created;
  },
};

const localInvoiceService: InvoiceService = {
  async getInvoices(userId) {
    return readState().invoices.filter((i) => i.userId === userId);
  },

  async getInvoiceByOrderId(orderId) {
    return readState().invoices.find((i) => i.orderId === orderId) || null;
  },
};

export const LocalDemoService: StorefrontServiceRegistry = {
  mode: 'local-demo',
  products: localProductService,
  categories: localCategoryService,
  inventory: localInventoryService,
  cart: localCartService,
  orders: localOrderService,
  customer: localCustomerService,
  invoices: localInvoiceService,
  offers: localOfferService,
  whatsappVerification: whatsAppVerificationClient,
  subscribe(listener) {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },
  resetDemoData() {
    const seed = createSeedDatabaseState();
    writeState(seed);
    localCartService.clearCart();
    localCartService.saveSavedForLater([]);
  },
};
