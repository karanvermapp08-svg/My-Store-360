import {
  Address,
  CartItem,
  Category,
  CheckoutValidationResult,
  Coupon,
  CustomerUser,
  Invoice,
  MembershipTier,
  NotificationItem,
  Offer,
  Order,
  OrderItem,
  PincodeServiceabilityResult,
  Product,
  ProductReview,
  ReviewEligibilityResult,
  RewardTransaction,
  ServiceableLocationSuggestion,
  StoreSettings,
  SupportTicket,
  UserPrivateInfo,
  UserProfile,
  WhatsAppPlatformStatus,
  WhatsAppSendOtpResult,
  WhatsAppVerifyOtpResult,
} from '../../types/store';

export interface ProductSearchFilters {
  categorySlug?: string;
  query?: string;
  maxPrice?: number;
  brands?: string[];
  minDiscount?: number;
  inStockOnly?: boolean;
  sortBy?: 'popular' | 'price-asc' | 'price-desc' | 'discount';
}

export interface ProductService {
  getProducts(): Promise<Product[]>;
  getProductById(productId: string): Promise<Product | null>;
  searchProducts(filters: ProductSearchFilters): Promise<Product[]>;
  getProductReviews(productId: string): Promise<ProductReview[]>;
  getReviewEligibility(userId: string | null, productId: string): Promise<ReviewEligibilityResult>;
  addProductReview(review: Omit<ProductReview, 'id' | 'createdAt'>): Promise<ProductReview>;
  toggleReviewHelpful(reviewId: string, userId: string): Promise<ProductReview>;
  reportReview(reviewId: string, userId: string, reason: string): Promise<ProductReview>;
  getCustomersAlsoBought(productId: string): Promise<Product[]>;
  getRecommendedProducts(userId: string | null): Promise<Product[]>;
}

export interface CategoryService {
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | null>;
}

export interface StockCheckItem {
  productId: string;
  quantity: number;
}

export interface StockAvailabilityResponse {
  allAvailable: boolean;
  unavailableItems: { productId: string; requested: number; available: number }[];
}

export interface InventoryAvailabilityService {
  checkStockAvailability(productId: string, requestedQty: number): Promise<{ available: boolean; stock: number }>;
  checkCartStock(items: StockCheckItem[]): Promise<StockAvailabilityResponse>;
  checkPincodeServiceability(pincode: string): Promise<PincodeServiceabilityResult>;
  searchServiceableLocations(query: string): Promise<ServiceableLocationSuggestion[]>;
  detectNearestLocation(lat: number, lng: number): Promise<PincodeServiceabilityResult>;
}

export interface CartService {
  getCart(): CartItem[];
  saveCart(items: CartItem[]): void;
  clearCart(): void;
  getSavedForLater(): CartItem[];
  saveSavedForLater(items: CartItem[]): void;
  calculateCheckoutTotals(params: {
    items: CartItem[];
    couponCode?: string;
    membershipTier: MembershipTier;
    availableRewardPoints: number;
    useRewardPoints: boolean;
  }): Promise<CheckoutValidationResult>;
}

export interface PlaceOrderInput {
  userId: string;
  customerName: string;
  customerPhone: string;
  address: Address;
  deliverySlot: string;
  deliveryInstructions: string;
  paymentMethod: 'COD' | 'ONLINE_PENDING';
  items: CartItem[];
  subtotal: number;
  discountAmount: number;
  couponCode: string;
  rewardPointsUsed: number;
  rewardDiscount: number;
  gstAmount: number;
  deliveryCharge: number;
  totalAmount: number;
}

export interface OrderService {
  getOrders(userId: string): Promise<Order[]>;
  getOrderItems(orderId: string): Promise<OrderItem[]>;
  placeOrder(input: PlaceOrderInput): Promise<Order>;
  cancelOrder(orderId: string, reason: string): Promise<Order>;
  requestReturn(orderId: string, reason: string): Promise<Order>;
}

export interface CustomerWorkspaceSnapshot {
  user: CustomerUser | null;
  profile: UserProfile | null;
  privateInfo: UserPrivateInfo | null;
  addresses: Address[];
  wishlistIds: string[];
  recentlyViewedIds: string[];
  rewardTransactions: RewardTransaction[];
  notifications: NotificationItem[];
  tickets: SupportTicket[];
}

export interface CustomerService {
  getCurrentCustomer(): Promise<CustomerUser | null>;
  signInDemoCustomer(): Promise<CustomerUser>;
  signOutCustomer(): Promise<void>;
  getWorkspaceSnapshot(userId: string): Promise<CustomerWorkspaceSnapshot>;
  updateCustomerProfile(
    userId: string,
    displayName: string,
    privateUpdates: Partial<UserPrivateInfo>
  ): Promise<void>;
  markPhoneVerified(userId: string, receipt: WhatsAppVerifyOtpResult): Promise<void>;
  updateMembershipTier(userId: string, tier: MembershipTier): Promise<UserProfile>;
  getAddresses(userId: string): Promise<Address[]>;
  saveAddress(userId: string, address: Address): Promise<Address>;
  deleteAddress(userId: string, addressId: string): Promise<void>;
  toggleWishlist(userId: string, productId: string): Promise<string[]>;
  recordRecentlyViewed(userId: string, productId: string): Promise<string[]>;
  markNotificationRead(userId: string, notificationId: string): Promise<void>;
  createSupportTicket(
    ticket: Omit<SupportTicket, 'id' | 'status' | 'createdAt' | 'updatedAt'>
  ): Promise<SupportTicket>;
}

export interface InvoiceService {
  getInvoices(userId: string): Promise<Invoice[]>;
  getInvoiceByOrderId(orderId: string): Promise<Invoice | null>;
}

export interface OfferService {
  getOffers(): Promise<Offer[]>;
  getCoupons(): Promise<Coupon[]>;
  validateCoupon(params: {
    code: string;
    subtotal: number;
    membershipTier: MembershipTier;
  }): Promise<{ valid: boolean; discount: number; message: string }>;
  getStoreSettings(): Promise<StoreSettings>;
}

export interface WhatsAppVerificationService {
  getPlatformStatus(): Promise<WhatsAppPlatformStatus>;
  sendOtpViaWhatsApp(mobileNumber: string): Promise<WhatsAppSendOtpResult>;
  verifyWhatsAppOtp(mobileNumber: string, otpCode: string): Promise<WhatsAppVerifyOtpResult>;
}

export interface StorefrontServiceRegistry {
  readonly mode: 'local-demo' | 'future-api';
  products: ProductService;
  categories: CategoryService;
  inventory: InventoryAvailabilityService;
  cart: CartService;
  orders: OrderService;
  customer: CustomerService;
  invoices: InvoiceService;
  offers: OfferService;
  whatsappVerification: WhatsAppVerificationService;
  subscribe?(listener: () => void): () => void;
  resetDemoData?(): void;
}
