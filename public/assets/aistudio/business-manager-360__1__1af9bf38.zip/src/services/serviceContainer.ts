import { StorefrontServiceRegistry } from './interfaces/ServiceContracts';
import { LocalDemoService } from './local/LocalDemoService';
// Future integration ready:
// import { createFutureApiService } from './api/FutureApiService';

/**
 * Single composition root for all storefront services.
 * Currently bound exclusively to LocalDemoService (local demo data + localStorage).
 * To connect a future Secure Backend API proxy without rebuilding UI components,
 * swap this binding to an implemented FutureApiService adapter.
 */
export const activeServices: StorefrontServiceRegistry = LocalDemoService;

export const productService = activeServices.products;
export const categoryService = activeServices.categories;
export const inventoryAvailabilityService = activeServices.inventory;
export const cartService = activeServices.cart;
export const orderService = activeServices.orders;
export const customerService = activeServices.customer;
export const invoiceService = activeServices.invoices;
export const offerService = activeServices.offers;
export const whatsappVerificationService = activeServices.whatsappVerification;
