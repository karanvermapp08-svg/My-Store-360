import { StorefrontServiceRegistry } from '../interfaces/ServiceContracts';

/**
 * FUTURE API INTEGRATION ARCHITECTURE (INACTIVE PLACEHOLDER)
 *
 * Connection Flow when activated later:
 *   Customer Shopping App  --->  Secure Backend API (/api/v1/*)  --->  Separate Admin Billing App
 *
 * Security Rules:
 * - DO NOT put Admin Billing App API keys, tokens, or secrets in client-side code.
 * - All Admin Billing API credentials must live strictly on your secure backend server.
 * - This module intentionally does NOT perform any fetch/network requests in standalone Demo Mode.
 */

export interface FutureApiConfig {
  /** Base URL of your own Secure Backend API proxy (e.g. "/api/v1" or "https://api.yourdomain.com") */
  backendBaseUrl: string;
  /** Request timeout in milliseconds */
  timeoutMs: number;
  /** Feature flag - remains false until explicitly activated in a future release */
  enabled: false;
  endpoints: {
    products: string;
    categories: string;
    inventoryCheck: string;
    pincodeCheck: string;
    cartCheckoutValidate: string;
    orders: string;
    customer: string;
    invoices: string;
    offers: string;
    whatsappSendOtp: string;
    whatsappVerifyOtp: string;
  };
}

export const DEFAULT_FUTURE_API_CONFIG: FutureApiConfig = {
  backendBaseUrl: '',
  timeoutMs: 10000,
  enabled: false,
  endpoints: {
    products: '/api/v1/products',
    categories: '/api/v1/categories',
    inventoryCheck: '/api/v1/inventory/availability',
    pincodeCheck: '/api/v1/inventory/pincode',
    cartCheckoutValidate: '/api/v1/checkout/validate',
    orders: '/api/v1/orders',
    customer: '/api/v1/customers/me',
    invoices: '/api/v1/invoices',
    offers: '/api/v1/offers',
    whatsappSendOtp: '/api/v1/verification/whatsapp/send-otp',
    whatsappVerifyOtp: '/api/v1/verification/whatsapp/verify-otp',
  },
};

export interface FutureApiService extends StorefrontServiceRegistry {
  readonly mode: 'future-api';
  readonly config: FutureApiConfig;
  isConfigured(): boolean;
}

class InactiveFutureApiError extends Error {
  constructor(operation: string) {
    super(
      `FutureApiService.${operation} is intentionally inactive. The app is running in standalone LocalDemoService mode.`
    );
    this.name = 'InactiveFutureApiError';
  }
}

/**
 * Inert placeholder factory for future backend integration.
 * Makes ZERO network requests and throws InactiveFutureApiError if invoked prematurely.
 */
export function createFutureApiService(
  config: FutureApiConfig = DEFAULT_FUTURE_API_CONFIG
): FutureApiService {
  const notActivated = (op: string) => () => Promise.reject(new InactiveFutureApiError(op));

  return {
    mode: 'future-api',
    config,
    isConfigured: () => Boolean(config.enabled && config.backendBaseUrl),
    products: {
      getProducts: notActivated('products.getProducts'),
      getProductById: notActivated('products.getProductById'),
      searchProducts: notActivated('products.searchProducts'),
      getProductReviews: notActivated('products.getProductReviews'),
      getReviewEligibility: notActivated('products.getReviewEligibility'),
      addProductReview: notActivated('products.addProductReview'),
      toggleReviewHelpful: notActivated('products.toggleReviewHelpful'),
      reportReview: notActivated('products.reportReview'),
      getCustomersAlsoBought: notActivated('products.getCustomersAlsoBought'),
      getRecommendedProducts: notActivated('products.getRecommendedProducts'),
    },
    categories: {
      getCategories: notActivated('categories.getCategories'),
      getCategoryBySlug: notActivated('categories.getCategoryBySlug'),
    },
    inventory: {
      checkStockAvailability: notActivated('inventory.checkStockAvailability'),
      checkCartStock: notActivated('inventory.checkCartStock'),
      checkPincodeServiceability: notActivated('inventory.checkPincodeServiceability'),
      searchServiceableLocations: notActivated('inventory.searchServiceableLocations'),
      detectNearestLocation: notActivated('inventory.detectNearestLocation'),
    },
    cart: {
      getCart: () => {
        throw new InactiveFutureApiError('cart.getCart');
      },
      saveCart: () => {
        throw new InactiveFutureApiError('cart.saveCart');
      },
      clearCart: () => {
        throw new InactiveFutureApiError('cart.clearCart');
      },
      getSavedForLater: () => {
        throw new InactiveFutureApiError('cart.getSavedForLater');
      },
      saveSavedForLater: () => {
        throw new InactiveFutureApiError('cart.saveSavedForLater');
      },
      calculateCheckoutTotals: notActivated('cart.calculateCheckoutTotals'),
    },
    orders: {
      getOrders: notActivated('orders.getOrders'),
      getOrderItems: notActivated('orders.getOrderItems'),
      placeOrder: notActivated('orders.placeOrder'),
      cancelOrder: notActivated('orders.cancelOrder'),
      requestReturn: notActivated('orders.requestReturn'),
    },
    customer: {
      getCurrentCustomer: notActivated('customer.getCurrentCustomer'),
      signInDemoCustomer: notActivated('customer.signInDemoCustomer'),
      signOutCustomer: notActivated('customer.signOutCustomer'),
      getWorkspaceSnapshot: notActivated('customer.getWorkspaceSnapshot'),
      updateCustomerProfile: notActivated('customer.updateCustomerProfile'),
      markPhoneVerified: notActivated('customer.markPhoneVerified'),
      updateMembershipTier: notActivated('customer.updateMembershipTier'),
      getAddresses: notActivated('customer.getAddresses'),
      saveAddress: notActivated('customer.saveAddress'),
      deleteAddress: notActivated('customer.deleteAddress'),
      toggleWishlist: notActivated('customer.toggleWishlist'),
      recordRecentlyViewed: notActivated('customer.recordRecentlyViewed'),
      markNotificationRead: notActivated('customer.markNotificationRead'),
      createSupportTicket: notActivated('customer.createSupportTicket'),
    },
    invoices: {
      getInvoices: notActivated('invoices.getInvoices'),
      getInvoiceByOrderId: notActivated('invoices.getInvoiceByOrderId'),
    },
    offers: {
      getOffers: notActivated('offers.getOffers'),
      getCoupons: notActivated('offers.getCoupons'),
      validateCoupon: notActivated('offers.validateCoupon'),
      getStoreSettings: notActivated('offers.getStoreSettings'),
    },
    whatsappVerification: {
      getPlatformStatus: notActivated('whatsappVerification.getPlatformStatus'),
      sendOtpViaWhatsApp: notActivated('whatsappVerification.sendOtpViaWhatsApp'),
      verifyWhatsAppOtp: notActivated('whatsappVerification.verifyWhatsAppOtp'),
    },
  };
}
