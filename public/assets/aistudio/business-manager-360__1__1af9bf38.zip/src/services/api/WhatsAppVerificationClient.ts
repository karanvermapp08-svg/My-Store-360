import {
  WhatsAppPlatformStatus,
  WhatsAppSendOtpResult,
  WhatsAppVerifyOtpResult,
} from '../../types/store';
import { WhatsAppVerificationService } from '../interfaces/ServiceContracts';

/**
 * Frontend client for Backend WhatsApp Business Platform OTP routes.
 * - Never generates, stores, or logs OTPs in client code.
 * - Never holds WhatsApp Business Platform API keys or tokens.
 * - Verification status is accepted strictly from backend response.
 */
function isOffline(): boolean {
  return typeof navigator !== 'undefined' && navigator.onLine === false;
}

export const whatsAppVerificationClient: WhatsAppVerificationService = {
  async getPlatformStatus(): Promise<WhatsAppPlatformStatus> {
    if (isOffline()) {
      return {
        provider: 'Meta WhatsApp Business Platform',
        defaultMethod: 'WHATSAPP_OTP',
        smsFallbackEnabled: false,
        liveSendingEnabled: false,
        credentialsConfigured: false,
        otpLength: 6,
        otpExpirySeconds: 300,
        resendCooldownSeconds: 60,
        maxAttempts: 5,
        maxSendsPerWindow: 4,
        statusMessage:
          'Offline Mode active — WhatsApp OTP verification requires an internet connection. Your shopping data is saved locally in IndexedDB.',
      };
    }

    try {
      const response = await fetch('/api/v1/verification/whatsapp/status', {
        method: 'GET',
        headers: { Accept: 'application/json' },
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      return (await response.json()) as WhatsAppPlatformStatus;
    } catch {
      return {
        provider: 'Meta WhatsApp Business Platform',
        defaultMethod: 'WHATSAPP_OTP',
        smsFallbackEnabled: false,
        liveSendingEnabled: false,
        credentialsConfigured: false,
        otpLength: 6,
        otpExpirySeconds: 300,
        resendCooldownSeconds: 60,
        maxAttempts: 5,
        maxSendsPerWindow: 4,
        statusMessage: 'Unable to reach backend WhatsApp verification status endpoint.',
      };
    }
  },

  async sendOtpViaWhatsApp(mobileNumber: string): Promise<WhatsAppSendOtpResult> {
    if (isOffline()) {
      return {
        sent: false,
        code: 'OFFLINE_MODE',
        message:
          'You are currently offline. Live WhatsApp OTP sending requires an internet connection, while local shopping remains 100% available.',
        liveSendingEnabled: false,
        credentialsConfigured: false,
      };
    }

    try {
      const response = await fetch('/api/v1/verification/whatsapp/send-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({ mobileNumber }),
      });
      return (await response.json()) as WhatsAppSendOtpResult;
    } catch {
      return {
        sent: false,
        code: 'NETWORK_ERROR',
        message: 'Could not reach backend WhatsApp verification service. Please try again.',
        liveSendingEnabled: false,
        credentialsConfigured: false,
      };
    }
  },

  async verifyWhatsAppOtp(mobileNumber: string, otpCode: string): Promise<WhatsAppVerifyOtpResult> {
    if (isOffline()) {
      return {
        verified: false,
        code: 'OFFLINE_MODE',
        message:
          'You are currently offline. Reconnect to verify your mobile number via WhatsApp OTP.',
      };
    }

    try {
      const response = await fetch('/api/v1/verification/whatsapp/verify-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({ mobileNumber, otpCode }),
      });
      return (await response.json()) as WhatsAppVerifyOtpResult;
    } catch {
      return {
        verified: false,
        code: 'NETWORK_ERROR',
        message: 'Could not reach backend WhatsApp verification service. Please verify your connection.',
      };
    }
  },
};
