import fs from 'fs';
import path from 'path';

export interface SyncMutationInput {
  queueKey: string;
  idempotencyKey: string;
  entityType: string;
  entityId: string;
  operation: 'upsert' | 'delete';
  payload: Record<string, unknown> | null;
  clientUpdatedAt: string;
}

export interface StoredSyncRecord {
  entityKey: string;
  entityType: string;
  entityId: string;
  operation: 'upsert' | 'delete';
  payload: Record<string, unknown> | null;
  updatedAt: string;
  lastIdempotencyKey: string;
}

export interface SyncMutationOutcome {
  queueKey: string;
  entityType: string;
  entityId: string;
  status: 'applied' | 'duplicate_ignored' | 'conflict_server_newer';
  serverUpdatedAt: string;
  serverRecord?: StoredSyncRecord;
}

interface SyncLedgerFile {
  version: number;
  updatedAt: string;
  processedIdempotencyKeys: string[];
  records: Record<string, StoredSyncRecord>;
}

const MAX_IDEMPOTENCY_HISTORY = 2000;

export class PersistentSyncLedger {
  private readonly ledgerPath: string;
  private state: SyncLedgerFile;

  constructor(ledgerPath = path.resolve(process.cwd(), '.data', 'sync-ledger.json')) {
    this.ledgerPath = ledgerPath;
    this.state = this.loadFromDisk();
  }

  private loadFromDisk(): SyncLedgerFile {
    try {
      if (fs.existsSync(this.ledgerPath)) {
        const raw = fs.readFileSync(this.ledgerPath, 'utf8');
        const parsed = JSON.parse(raw) as Partial<SyncLedgerFile>;
        if (parsed && typeof parsed === 'object' && parsed.records) {
          return {
            version: parsed.version ?? 1,
            updatedAt: parsed.updatedAt || new Date().toISOString(),
            processedIdempotencyKeys: Array.isArray(parsed.processedIdempotencyKeys)
              ? parsed.processedIdempotencyKeys.slice(-MAX_IDEMPOTENCY_HISTORY)
              : [],
            records: parsed.records,
          };
        }
      }
    } catch {
      // Fallback to clean ledger if disk file is missing or unreadable
    }
    return {
      version: 1,
      updatedAt: new Date().toISOString(),
      processedIdempotencyKeys: [],
      records: {},
    };
  }

  private saveToDisk(): void {
    try {
      const dir = path.dirname(this.ledgerPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.ledgerPath, JSON.stringify(this.state, null, 2), 'utf8');
    } catch {
      // Keep running safely if filesystem is read-only
    }
  }

  private parseTimeMs(iso?: string): number {
    if (!iso) return 0;
    const ms = Date.parse(iso);
    return Number.isFinite(ms) ? ms : 0;
  }

  public getStatus(): {
    recordCount: number;
    processedMutationCount: number;
    updatedAt: string;
  } {
    return {
      recordCount: Object.keys(this.state.records).length,
      processedMutationCount: this.state.processedIdempotencyKeys.length,
      updatedAt: this.state.updatedAt,
    };
  }

  public applyBatch(mutations: SyncMutationInput[]): {
    outcomes: SyncMutationOutcome[];
    syncedAt: string;
  } {
    const syncedAt = new Date().toISOString();
    const outcomes: SyncMutationOutcome[] = [];
    const seenKeys = new Set(this.state.processedIdempotencyKeys);

    for (const mut of mutations) {
      if (!mut || typeof mut.entityType !== 'string' || typeof mut.entityId !== 'string') {
        continue;
      }
      const entityKey = `${mut.entityType}:${mut.entityId}`;
      const existing = this.state.records[entityKey];

      // 1. Deduplicate identical idempotency keys
      if (mut.idempotencyKey && seenKeys.has(mut.idempotencyKey)) {
        outcomes.push({
          queueKey: mut.queueKey || entityKey,
          entityType: mut.entityType,
          entityId: mut.entityId,
          status: 'duplicate_ignored',
          serverUpdatedAt: existing?.updatedAt || mut.clientUpdatedAt || syncedAt,
        });
        continue;
      }

      // 2. Timestamp conflict check: NEVER overwrite newer data with older data
      const incomingMs = this.parseTimeMs(mut.clientUpdatedAt);
      const existingMs = this.parseTimeMs(existing?.updatedAt);

      if (existing && existingMs > incomingMs) {
        if (mut.idempotencyKey) {
          seenKeys.add(mut.idempotencyKey);
          this.state.processedIdempotencyKeys.push(mut.idempotencyKey);
        }
        outcomes.push({
          queueKey: mut.queueKey || entityKey,
          entityType: mut.entityType,
          entityId: mut.entityId,
          status: 'conflict_server_newer',
          serverUpdatedAt: existing.updatedAt,
          serverRecord: existing,
        });
        continue;
      }

      const stored: StoredSyncRecord = {
        entityKey,
        entityType: mut.entityType,
        entityId: mut.entityId,
        operation: mut.operation === 'delete' ? 'delete' : 'upsert',
        payload: mut.payload ?? null,
        updatedAt: mut.clientUpdatedAt || syncedAt,
        lastIdempotencyKey: mut.idempotencyKey || `${entityKey}_${Date.now()}`,
      };

      this.state.records[entityKey] = stored;
      if (mut.idempotencyKey) {
        seenKeys.add(mut.idempotencyKey);
        this.state.processedIdempotencyKeys.push(mut.idempotencyKey);
      }

      outcomes.push({
        queueKey: mut.queueKey || entityKey,
        entityType: mut.entityType,
        entityId: mut.entityId,
        status: 'applied',
        serverUpdatedAt: stored.updatedAt,
      });
    }

    if (this.state.processedIdempotencyKeys.length > MAX_IDEMPOTENCY_HISTORY) {
      this.state.processedIdempotencyKeys = this.state.processedIdempotencyKeys.slice(
        -MAX_IDEMPOTENCY_HISTORY
      );
    }
    this.state.updatedAt = syncedAt;
    this.saveToDisk();

    return { outcomes, syncedAt };
  }

  public getRecordsSince(sinceIso?: string): {
    records: StoredSyncRecord[];
    serverTime: string;
  } {
    const sinceMs = this.parseTimeMs(sinceIso);
    const records = Object.values(this.state.records).filter(
      (r) => this.parseTimeMs(r.updatedAt) > sinceMs
    );
    return {
      records,
      serverTime: new Date().toISOString(),
    };
  }
}

export const defaultSyncLedger = new PersistentSyncLedger();
