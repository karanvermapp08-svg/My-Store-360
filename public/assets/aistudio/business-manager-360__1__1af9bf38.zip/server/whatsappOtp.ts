import crypto from 'crypto';

export const OTP_EXPIRY_SECONDS = 5 * 60; // 5 minutes
export const OTP_EXPIRY_MS = OTP_EXPIRY_SECONDS * 1000;
export const RESEND_COOLDOWN_SECONDS = 60; // 60 seconds between sends
export const RESEND_COOLDOWN_MS = RESEND_COOLDOWN_SECONDS * 1000;
export const MAX_VERIFY_ATTEMPTS = 5;
export const RESEND_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
export const MAX_SENDS_PER_WINDOW = 4;

export interface NormalizedIndianMobile {
  valid: boolean;
  national10: string;
  e164: string;
  waId: string;
  masked: string;
  formattedDisplay: string;
  error?: string;
}

export interface WhatsAppPlatformStatusResponse {
  provider: 'Meta WhatsApp Business Platform';
  defaultMethod: 'WHATSAPP_OTP';
  smsFallbackEnabled: false;
  liveSendingEnabled: boolean;
  credentialsConfigured: boolean;
  otpLength: 6;
  otpExpirySeconds: number;
  resendCooldownSeconds: number;
  maxAttempts: number;
  maxSendsPerWindow: number;
  statusMessage: string;
}

export interface WhatsAppGatewayDispatchResult {
  dispatched: boolean;
  messageId?: string;
  code: 'SENT' | 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED' | 'WHATSAPP_GATEWAY_ERROR';
  errorMessage?: string;
}

export interface WhatsAppOtpGateway {
  isLiveSendingEnabled(): boolean;
  areCredentialsConfigured(): boolean;
  sendAuthenticationOtp(params: { toWaId: string; otpCode: string }): Promise<WhatsAppGatewayDispatchResult>;
}

export interface SendOtpOutcome {
  httpStatus: number;
  sent: boolean;
  code:
    | 'OTP_SENT'
    | 'INVALID_MOBILE_NUMBER'
    | 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED'
    | 'RESEND_COOLDOWN_ACTIVE'
    | 'RATE_LIMIT_EXCEEDED'
    | 'WHATSAPP_GATEWAY_ERROR';
  message: string;
  liveSendingEnabled: boolean;
  credentialsConfigured: boolean;
  maskedPhone?: string;
  e164?: string;
  expiresInSeconds?: number;
  expiresAt?: string;
  resendCooldownSeconds?: number;
  retryAfterSeconds?: number;
  maxAttempts?: number;
}

export interface VerifyOtpOutcome {
  httpStatus: number;
  verified: boolean;
  code:
    | 'VERIFIED'
    | 'INVALID_MOBILE_NUMBER'
    | 'INVALID_OTP_FORMAT'
    | 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED'
    | 'OTP_NOT_FOUND'
    | 'OTP_EXPIRED'
    | 'INVALID_OTP'
    | 'MAX_ATTEMPTS_EXCEEDED';
  message: string;
  e164?: string;
  national10?: string;
  formattedDisplay?: string;
  maskedPhone?: string;
  verifiedAt?: string;
  method?: 'WHATSAPP_OTP';
  verificationId?: string;
  remainingAttempts?: number;
}

/**
 * Validates and normalizes Indian mobile numbers (+91 / 10-digit starting with 6-9).
 */
export function normalizeIndianMobile(rawInput: string): NormalizedIndianMobile {
  const cleaned = String(rawInput || '').replace(/[\s\-().]/g, '');
  let national10 = cleaned;

  if (national10.startsWith('+91')) {
    national10 = national10.slice(3);
  } else if (national10.startsWith('91') && national10.length === 12) {
    national10 = national10.slice(2);
  } else if (national10.startsWith('0') && national10.length === 11) {
    national10 = national10.slice(1);
  }

  if (!/^[6-9]\d{9}$/.test(national10)) {
    return {
      valid: false,
      national10: '',
      e164: '',
      waId: '',
      masked: '',
      formattedDisplay: '',
      error: 'Enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.',
    };
  }

  return {
    valid: true,
    national10,
    e164: `+91${national10}`,
    waId: `91${national10}`,
    masked: `+91 ••••••${national10.slice(-4)}`,
    formattedDisplay: `+91 ${national10.slice(0, 5)} ${national10.slice(5)}`,
  };
}

/**
 * Official Meta WhatsApp Business Platform Cloud API adapter.
 * Remains strictly disabled unless WHATSAPP_LIVE_SENDING_ENABLED="true" AND credentials are present on the backend.
 */
export class MetaWhatsAppCloudGateway implements WhatsAppOtpGateway {
  private getConfig() {
    const accessToken = (process.env.WHATSAPP_ACCESS_TOKEN || '').trim();
    const phoneNumberId = (process.env.WHATSAPP_PHONE_NUMBER_ID || '').trim();
    const templateName = (process.env.WHATSAPP_OTP_TEMPLATE_NAME || '').trim();
    const templateLanguage = (process.env.WHATSAPP_OTP_TEMPLATE_LANGUAGE || 'en').trim();
    const apiVersion = (process.env.WHATSAPP_API_VERSION || 'v21.0').trim();
    const liveFlag = (process.env.WHATSAPP_LIVE_SENDING_ENABLED || 'false').trim().toLowerCase() === 'true';

    const hasValidToken = Boolean(accessToken && !accessToken.startsWith('REPLACE_WITH'));
    const hasValidPhoneId = Boolean(phoneNumberId && !phoneNumberId.startsWith('REPLACE_WITH'));
    const hasValidTemplate = Boolean(templateName && !templateName.startsWith('REPLACE_WITH'));

    return {
      accessToken,
      phoneNumberId,
      templateName,
      templateLanguage,
      apiVersion,
      liveFlag,
      credentialsConfigured: hasValidToken && hasValidPhoneId && hasValidTemplate,
    };
  }

  areCredentialsConfigured(): boolean {
    return this.getConfig().credentialsConfigured;
  }

  isLiveSendingEnabled(): boolean {
    const cfg = this.getConfig();
    return cfg.liveFlag && cfg.credentialsConfigured;
  }

  async sendAuthenticationOtp({
    toWaId,
    otpCode,
  }: {
    toWaId: string;
    otpCode: string;
  }): Promise<WhatsAppGatewayDispatchResult> {
    const cfg = this.getConfig();
    if (!cfg.liveFlag || !cfg.credentialsConfigured) {
      return {
        dispatched: false,
        code: 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED',
        errorMessage:
          'Live WhatsApp OTP sending is disabled until official WhatsApp Business Platform credentials are configured securely on the backend.',
      };
    }

    const endpoint = `https://graph.facebook.com/${cfg.apiVersion}/${cfg.phoneNumberId}/messages`;

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${cfg.accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: toWaId,
          type: 'template',
          template: {
            name: cfg.templateName,
            language: { code: cfg.templateLanguage },
            components: [
              {
                type: 'body',
                parameters: [{ type: 'text', text: otpCode }],
              },
              {
                type: 'button',
                sub_type: 'url',
                index: '0',
                parameters: [{ type: 'text', text: otpCode }],
              },
            ],
          },
        }),
      });

      const payload = (await response.json().catch(() => ({}))) as {
        messages?: Array<{ id?: string }>;
        error?: { message?: string };
      };

      if (!response.ok) {
        return {
          dispatched: false,
          code: 'WHATSAPP_GATEWAY_ERROR',
          errorMessage: payload.error?.message || `WhatsApp Business Platform returned HTTP ${response.status}.`,
        };
      }

      return {
        dispatched: true,
        code: 'SENT',
        messageId: payload.messages?.[0]?.id,
      };
    } catch {
      return {
        dispatched: false,
        code: 'WHATSAPP_GATEWAY_ERROR',
        errorMessage: 'Unable to reach WhatsApp Business Platform API.',
      };
    }
  }
}

interface StoredOtpSession {
  salt: string;
  otpHash: Buffer;
  createdAt: number;
  expiresAt: number;
  cooldownUntil: number;
  attempts: number;
  maxAttempts: number;
}

/**
 * Backend-only OTP session manager.
 * - Generates CSPRNG 6-digit OTPs
 * - Stores only salted HMAC-SHA256 digests in memory (never plaintext OTP)
 * - Enforces 5-minute TTL, 60-second resend cooldown, and max 5 verification attempts
 * - Never exposes OTPs in API responses
 */
export class WhatsAppOtpManager {
  private readonly sessions = new Map<string, StoredOtpSession>();
  private readonly sendHistory = new Map<string, number[]>();
  private readonly pepper: string;

  constructor(private readonly gateway: WhatsAppOtpGateway) {
    this.pepper = (process.env.OTP_HMAC_SECRET || '').trim() || crypto.randomBytes(32).toString('hex');
  }

  private hashOtp(salt: string, e164: string, otpCode: string): Buffer {
    return crypto.createHmac('sha256', this.pepper).update(`${salt}:${e164}:${otpCode}`).digest();
  }

  private pruneExpired(): void {
    const now = Date.now();
    for (const [key, session] of this.sessions.entries()) {
      if (now > session.expiresAt) {
        this.sessions.delete(key);
      }
    }
    for (const [key, timestamps] of this.sendHistory.entries()) {
      const recent = timestamps.filter((t) => now - t < RESEND_WINDOW_MS);
      if (recent.length === 0) {
        this.sendHistory.delete(key);
      } else {
        this.sendHistory.set(key, recent);
      }
    }
  }

  getPlatformStatus(): WhatsAppPlatformStatusResponse {
    const credentialsConfigured = this.gateway.areCredentialsConfigured();
    const liveSendingEnabled = this.gateway.isLiveSendingEnabled();

    let statusMessage =
      'Live WhatsApp OTP sending is disabled because official WhatsApp Business Platform credentials are not yet configured on the backend.';
    if (credentialsConfigured && !liveSendingEnabled) {
      statusMessage =
        'WhatsApp credentials are present, but live sending is disabled (set WHATSAPP_LIVE_SENDING_ENABLED=true on backend to enable).';
    } else if (liveSendingEnabled) {
      statusMessage = 'Official WhatsApp Business Platform OTP verification is active.';
    }

    return {
      provider: 'Meta WhatsApp Business Platform',
      defaultMethod: 'WHATSAPP_OTP',
      smsFallbackEnabled: false,
      liveSendingEnabled,
      credentialsConfigured,
      otpLength: 6,
      otpExpirySeconds: OTP_EXPIRY_SECONDS,
      resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
      maxAttempts: MAX_VERIFY_ATTEMPTS,
      maxSendsPerWindow: MAX_SENDS_PER_WINDOW,
      statusMessage,
    };
  }

  async sendOtp(rawPhone: string): Promise<SendOtpOutcome> {
    this.pruneExpired();
    const normalized = normalizeIndianMobile(rawPhone);
    const liveSendingEnabled = this.gateway.isLiveSendingEnabled();
    const credentialsConfigured = this.gateway.areCredentialsConfigured();

    if (!normalized.valid) {
      return {
        httpStatus: 400,
        sent: false,
        code: 'INVALID_MOBILE_NUMBER',
        message: normalized.error || 'Invalid Indian mobile number.',
        liveSendingEnabled,
        credentialsConfigured,
      };
    }

    // Do NOT fake sending when live WhatsApp sending is disabled
    if (!liveSendingEnabled) {
      return {
        httpStatus: 503,
        sent: false,
        code: 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED',
        message:
          'Live WhatsApp OTP sending is disabled until official WhatsApp Business Platform credentials are configured on the backend. No OTP was sent.',
        liveSendingEnabled,
        credentialsConfigured,
        maskedPhone: normalized.masked,
        e164: normalized.e164,
        expiresInSeconds: OTP_EXPIRY_SECONDS,
        resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
        maxAttempts: MAX_VERIFY_ATTEMPTS,
      };
    }

    const now = Date.now();
    const history = (this.sendHistory.get(normalized.e164) || []).filter((t) => now - t < RESEND_WINDOW_MS);
    if (history.length >= MAX_SENDS_PER_WINDOW) {
      const oldest = history[0];
      const retryAfterSeconds = Math.max(1, Math.ceil((oldest + RESEND_WINDOW_MS - now) / 1000));
      return {
        httpStatus: 429,
        sent: false,
        code: 'RATE_LIMIT_EXCEEDED',
        message: `Too many WhatsApp OTP requests. Please wait ${Math.ceil(retryAfterSeconds / 60)} minute(s) before trying again.`,
        liveSendingEnabled,
        credentialsConfigured,
        retryAfterSeconds,
      };
    }

    const existing = this.sessions.get(normalized.e164);
    if (existing && now < existing.cooldownUntil) {
      const retryAfterSeconds = Math.max(1, Math.ceil((existing.cooldownUntil - now) / 1000));
      return {
        httpStatus: 429,
        sent: false,
        code: 'RESEND_COOLDOWN_ACTIVE',
        message: `Please wait ${retryAfterSeconds}s before requesting another WhatsApp OTP.`,
        liveSendingEnabled,
        credentialsConfigured,
        retryAfterSeconds,
      };
    }

    // Generate cryptographically random 6-digit OTP strictly on backend
    const otpCode = String(crypto.randomInt(100000, 1000000));
    const dispatchResult = await this.gateway.sendAuthenticationOtp({
      toWaId: normalized.waId,
      otpCode,
    });

    if (!dispatchResult.dispatched) {
      return {
        httpStatus: dispatchResult.code === 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED' ? 503 : 502,
        sent: false,
        code:
          dispatchResult.code === 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED'
            ? 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED'
            : 'WHATSAPP_GATEWAY_ERROR',
        message:
          dispatchResult.errorMessage ||
          'Failed to dispatch OTP via WhatsApp Business Platform. Please try again shortly.',
        liveSendingEnabled,
        credentialsConfigured,
      };
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const otpHash = this.hashOtp(salt, normalized.e164, otpCode);
    const expiresAtMs = now + OTP_EXPIRY_MS;

    this.sessions.set(normalized.e164, {
      salt,
      otpHash,
      createdAt: now,
      expiresAt: expiresAtMs,
      cooldownUntil: now + RESEND_COOLDOWN_MS,
      attempts: 0,
      maxAttempts: MAX_VERIFY_ATTEMPTS,
    });
    this.sendHistory.set(normalized.e164, [...history, now]);

    return {
      httpStatus: 200,
      sent: true,
      code: 'OTP_SENT',
      message: `A 6-digit verification OTP has been sent to ${normalized.masked} via WhatsApp.`,
      liveSendingEnabled,
      credentialsConfigured,
      maskedPhone: normalized.masked,
      e164: normalized.e164,
      expiresInSeconds: OTP_EXPIRY_SECONDS,
      expiresAt: new Date(expiresAtMs).toISOString(),
      resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
      maxAttempts: MAX_VERIFY_ATTEMPTS,
    };
  }

  verifyOtp(rawPhone: string, rawOtp: string): VerifyOtpOutcome {
    const normalized = normalizeIndianMobile(rawPhone);
    if (!normalized.valid) {
      return {
        httpStatus: 400,
        verified: false,
        code: 'INVALID_MOBILE_NUMBER',
        message: normalized.error || 'Invalid Indian mobile number.',
      };
    }

    const cleanOtp = String(rawOtp || '').trim();
    if (!/^\d{6}$/.test(cleanOtp)) {
      return {
        httpStatus: 400,
        verified: false,
        code: 'INVALID_OTP_FORMAT',
        message: 'Please enter the 6-digit numeric OTP sent to your WhatsApp.',
      };
    }

    const session = this.sessions.get(normalized.e164);
    if (!session) {
      if (!this.gateway.isLiveSendingEnabled()) {
        return {
          httpStatus: 503,
          verified: false,
          code: 'WHATSAPP_CREDENTIALS_NOT_CONFIGURED',
          message:
            'WhatsApp verification is unavailable because live WhatsApp Business Platform credentials are not configured on the backend.',
        };
      }
      return {
        httpStatus: 400,
        verified: false,
        code: 'OTP_NOT_FOUND',
        message: 'No active WhatsApp OTP found for this mobile number. Please request a new OTP.',
      };
    }

    const now = Date.now();
    if (now > session.expiresAt) {
      this.sessions.delete(normalized.e164);
      return {
        httpStatus: 410,
        verified: false,
        code: 'OTP_EXPIRED',
        message: 'Your WhatsApp OTP expired after 5 minutes. Please request a new OTP.',
      };
    }

    if (session.attempts >= session.maxAttempts) {
      this.sessions.delete(normalized.e164);
      return {
        httpStatus: 429,
        verified: false,
        code: 'MAX_ATTEMPTS_EXCEEDED',
        message: 'Maximum verification attempts exceeded. This OTP has been locked—please request a new OTP.',
        remainingAttempts: 0,
      };
    }

    const candidateHash = this.hashOtp(session.salt, normalized.e164, cleanOtp);
    const matches =
      candidateHash.length === session.otpHash.length &&
      crypto.timingSafeEqual(candidateHash, session.otpHash);

    if (!matches) {
      session.attempts += 1;
      const remainingAttempts = Math.max(0, session.maxAttempts - session.attempts);
      if (remainingAttempts === 0) {
        this.sessions.delete(normalized.e164);
        return {
          httpStatus: 429,
          verified: false,
          code: 'MAX_ATTEMPTS_EXCEEDED',
          message: 'Maximum 5 incorrect OTP attempts reached. Please request a new WhatsApp OTP.',
          remainingAttempts: 0,
        };
      }

      return {
        httpStatus: 401,
        verified: false,
        code: 'INVALID_OTP',
        message: `Incorrect WhatsApp OTP. ${remainingAttempts} attempt${remainingAttempts === 1 ? '' : 's'} remaining.`,
        remainingAttempts,
      };
    }

    // Consume OTP on successful verification so it cannot be replayed
    this.sessions.delete(normalized.e164);
    const verifiedAt = new Date(now).toISOString();
    const verificationId = `wa_ver_${crypto.randomBytes(12).toString('hex')}`;

    return {
      httpStatus: 200,
      verified: true,
      code: 'VERIFIED',
      message: 'Mobile number verified successfully via WhatsApp.',
      e164: normalized.e164,
      national10: normalized.national10,
      formattedDisplay: normalized.formattedDisplay,
      maskedPhone: normalized.masked,
      verifiedAt,
      method: 'WHATSAPP_OTP',
      verificationId,
    };
  }
}

export const defaultWhatsAppOtpManager = new WhatsAppOtpManager(new MetaWhatsAppCloudGateway());
