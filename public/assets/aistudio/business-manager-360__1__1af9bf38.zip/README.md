# Business Manager 360 — Shopping Super App (Version 4.0)

Full-stack responsive e-commerce Super App built with **React 19, TypeScript, Tailwind CSS v4, Vite PWA, Express, Firebase Auth & Firestore**, and **Gemini AI (`@google/genai`)**.

## Key Implemented Capabilities
- **Dedicated Desktop & Mobile Responsive Interfaces**:
  - Desktop/Laptop (`>= 1024px`): `DesktopHeader` with location selector, smart autocomplete search, `DesktopNavigation` mega menu, 5/4/3-column `ResponsiveProductGrid`, `DesktopProductFilters` sidebar, 2-column `ProductDetailsView` with image zoom, and 2-column `ResponsiveCart` / `ResponsiveCheckout`.
  - Mobile/Tablet (`320px–1023px`): `MobileHeader` with voice-search-ready search bar, horizontally scrollable pastel circular `CategoryStrip`, swipeable `HeroCarousel`, 2-column product grid, `MobileProductFilters` bottom sheet, fixed `MobileBottomNavigation`, and sticky mobile buy/checkout bars.
- **Shared Firebase Backend & Security**:
  - Provisioned Firebase project (`gen-lang-client-0780890254`, database `ai-studio-c17f2b27-e080-4b6c-89fc-80bf65d3483c`).
  - Hardened `firestore.rules` audited with `@firebase/eslint-plugin-security-rules`, enforcing split PII isolation (`/users/{uid}/private/info`), immutable reward balances, atomic order + line-item creation, and admin-only catalog/invoice/order-progression controls.
- **Server-Side Validation & AI Shopping Assistant (`server.ts`)**:
  - Firebase ID token verification via `jose` (`securetoken.google.com` JWKS).
  - `/api/pincodes/check`: Pincode serviceability validation.
  - `/api/checkout/validate`: Authoritative server-side subtotal, GST extraction, coupon eligibility, reward point cap, and delivery fee calculation.
  - `/api/assistant/chat`: Grounded Gemini (`gemini-4-hydrogen`) shopping assistant using verified live catalog, offers, coupons, and customer orders.
  - `/api/sync/admin/status` & `/api/sync/admin/webhook`: Admin Billing App sync bridge (`X-Admin-Sync-Secret` or verified admin Firebase token).
- **Installable PWA**:
  - `vite-plugin-pwa` manifest, Workbox runtime caching, `PWAInstallButton` (Chromium + iOS guide), `OfflineIndicator`, and PNG icons (`192x192`, `512x512`, maskable `512x512`, `180x180` Apple touch icon).

## Deployment & Configuration
1. **Secrets / Environment Variables** (configure in AI Studio Secrets or `.env`):
   - `GEMINI_API_KEY`: Server-side key for the AI Shopping Assistant.
   - `ADMIN_SYNC_SECRET`: Shared secret for server-to-server webhooks from the Business Manager 360 Admin Billing App.
2. **Build & Run**:
   - Development: `npm run dev` (Express + Vite middleware on port 3000)
   - Production build: `npm run build` followed by `npm start`
3. **Connecting Existing Account 1 / Account 2 Shared Firebase Project**:
   - The app is currently provisioned and deployed against Firebase project `gen-lang-client-0780890254` (`ai-studio-c17f2b27-e080-4b6c-89fc-80bf65d3483c`).
   - Sign in as the bootstrapped admin (`karanvermapp08@gmail.com`) and open **Account → Admin Sync Console → Sync Starter Catalog to Firestore** to populate initial categories, products, offers, coupons, and store settings into Firestore.
   - To connect your separate Admin Billing App, configure it to use the same Firebase project ID (`gen-lang-client-0780890254`) and database ID (`ai-studio-c17f2b27-e080-4b6c-89fc-80bf65d3483c`), or re-provision with your specific existing Firebase Project ID.
