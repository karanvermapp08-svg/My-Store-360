/**
 * Security Rule Verification Suite — Business Manager 360
 * Validates the Dirty Dozen payloads against Firestore Security Rules logic.
 */

export interface DirtyPayloadTest {
  id: number;
  name: string;
  collectionPath: string;
  operation: 'get' | 'list' | 'create' | 'update';
  expected: 'PERMISSION_DENIED';
  description: string;
}

export const DIRTY_DOZEN_TESTS: DirtyPayloadTest[] = [
  {
    id: 1,
    name: 'Self-Assigned Admin Escalation',
    collectionPath: '/admins/attacker_uid',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    description: 'Non-admin attempts to create an admin marker document.',
  },
  {
    id: 2,
    name: 'Self-Minting Reward Points',
    collectionPath: '/users/customer_uid',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    description: 'Customer attempts to increment rewardPoints on /users/{uid}.',
  },
  {
    id: 3,
    name: 'Self-Upgrading Membership Tier',
    collectionPath: '/users/customer_uid',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    description: 'Customer attempts to set membershipTier to Premium.',
  },
  {
    id: 4,
    name: 'Cross-User PII Read',
    collectionPath: '/users/victim_uid/private/info',
    operation: 'get',
    expected: 'PERMISSION_DENIED',
    description: 'Authenticated non-owner attempts to read isolated PII.',
  },
  {
    id: 5,
    name: 'Order Status Tampering',
    collectionPath: '/orders/order_123',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    description: 'Customer attempts to mark own order as Delivered.',
  },
  {
    id: 6,
    name: 'Shadow Field Injection on Address',
    collectionPath: '/users/customer_uid/addresses/addr_1',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    description: 'Payload includes unauthorized shadow key isAdminVerified.',
  },
  {
    id: 7,
    name: 'Product Price Tampering',
    collectionPath: '/products/prod_apples',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    description: 'Customer attempts to mutate product selling price.',
  },
  {
    id: 8,
    name: 'Fake Timestamp Injection',
    collectionPath: '/orders/order_new',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    description: 'Client submits backdated createdAt != request.time.',
  },
  {
    id: 9,
    name: 'ID Poisoning Resource Exhaustion',
    collectionPath: `/users/customer_uid/addresses/${'x'.repeat(200)}`,
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    description: 'Document ID exceeds 128 character boundary.',
  },
  {
    id: 10,
    name: 'Unverified Email Admin Spoof',
    collectionPath: '/products/prod_new',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    description: 'Token claims admin email with email_verified == false.',
  },
  {
    id: 11,
    name: 'Unfiltered Orders Collection Scraping',
    collectionPath: '/orders',
    operation: 'list',
    expected: 'PERMISSION_DENIED',
    description: 'Non-admin lists /orders without userId == request.auth.uid filter.',
  },
  {
    id: 12,
    name: 'Orphaned Order Item Creation',
    collectionPath: '/orders/missing_order/items/item_1',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    description: 'Order line item created without atomic parent order.',
  },
];
