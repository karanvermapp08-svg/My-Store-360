# Security Specification — Business Manager 360 (Version 4.0)

## 1. Data Invariants
1. **Admin Authority**: Only verified admins (`exists(/databases/$(database)/documents/admins/$(request.auth.uid))` or verified bootstrapped admin email `karanvermapp08@gmail.com`) may mutate `products` catalog metadata/prices, `categories`, `offers`, `coupons`, `settings`, `invoices`, `admins`, `auditLogs`, or advance order statuses beyond customer cancellation/return request.
2. **PII Isolation**: Customer PII (`email`, `phone`, `gstin`) lives in `/users/{uid}/private/info` and `/users/{uid}/addresses/{addressId}` and `/customers/{uid}`, strictly readable/writable only by `isOwner(uid)` or `isAdmin()`. No blanket `isSignedIn()` reads exist anywhere on user or order data.
3. **Immutable Financial & Reward Balances**: A customer creating `/users/{uid}` must initialize `rewardPoints == 0` and `membershipTier == 'Basic'`. Customers cannot self-increment `rewardPoints`, change `membershipTier`, or write `/users/{uid}/rewardTransactions/{txId}`.
4. **Order Integrity & State Machine**: A customer can only create `/orders/{orderId}` with `userId == request.auth.uid`, `status == 'Order Placed'`, `createdAt == request.time`, and `updatedAt == request.time`. Customers may only transition an order to `'Cancelled'` if existing status is `'Order Placed'` or `'Accepted'`, or to `'Return Requested'` if existing status is `'Delivered'`. Terminal states (`Cancelled`) cannot be mutated by customers.
5. **Relational Master Gate**: `/orders/{orderId}/items/{itemId}` strictly reads the parent `/orders/{orderId}` (`get()` or `getAfter()` during atomic batch creation) to verify `userId == request.auth.uid`.
6. **Temporal Integrity & Path Hardening**: All `createdAt`/`updatedAt` timestamps must match `request.time`. All document ID path variables are validated with `isValidId()` (`^[a-zA-Z0-9_\-]+$`, max 128 chars).

## 2. The "Dirty Dozen" Attack Payloads
1. **Self-Assigned Admin**: `setDoc('/admins/attacker1', { uid: 'attacker1', email: 'a@b.com', role: 'super_admin' })` -> `PERMISSION_DENIED`.
2. **Self-Minting Reward Points**: `updateDoc('/users/user1', { rewardPoints: 999999 })` -> `PERMISSION_DENIED`.
3. **Self-Upgrading Membership**: `updateDoc('/users/user1', { membershipTier: 'Premium' })` -> `PERMISSION_DENIED`.
4. **Cross-User PII Read**: `getDoc('/users/victim/private/info')` as `attacker` -> `PERMISSION_DENIED`.
5. **Order Status Tampering**: `updateDoc('/orders/ord1', { status: 'Delivered' })` as customer -> `PERMISSION_DENIED`.
6. **Shadow Field Injection on Address**: `setDoc('/users/user1/addresses/addr1', { ..., isAdminVerified: true })` -> `PERMISSION_DENIED`.
7. **Product Price Tampering**: `updateDoc('/products/prod1', { price: 1 })` as customer -> `PERMISSION_DENIED`.
8. **Fake Timestamp Injection**: `setDoc('/orders/ord1', { ..., createdAt: Timestamp.fromDate(new Date('2020-01-01')) })` -> `PERMISSION_DENIED`.
9. **ID Poisoning**: `setDoc('/users/user1/addresses/' + 'a'.repeat(200), { ... })` -> `PERMISSION_DENIED`.
10. **Unverified Email Spoofing**: Admin email claim with `email_verified: false` -> `PERMISSION_DENIED`.
11. **Order Scraping (`list` without filter)**: `getDocs(collection(db, 'orders'))` as non-admin -> `PERMISSION_DENIED`.
12. **Orphaned Order Item Creation**: `setDoc('/orders/nonexistent/items/item1', { ... })` -> `PERMISSION_DENIED`.
